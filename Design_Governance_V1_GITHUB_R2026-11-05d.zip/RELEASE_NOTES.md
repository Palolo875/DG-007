# Notes de version — Design Governance V1.0.0

Cette page présente la révision livrée : ce qu’elle permet, comment l’installer, comment la contrôler et ce que ces contrôles attestent.

**Révision livrée :** `R2026-11-05d`, 5 novembre 2026.  
**Statut :** expérimentation maintenue ; usage recommandé en pilote, avec revue humaine.  
**Efficacité : `NOT-VERIFIED`.** Aucune mesure comparative n’établit de gain ; ce qui est vérifié, et ce qui ne l’est pas, est décrit dans [la fiche de version](maintenance/versions.md#ce-qui-est-vérifié-ce-qui-ne-lest-pas).

## Ce que permet la V1

Transformer une demande en proposition de design composée, crédible et observable, puis l’améliorer à partir du rendu réel ; ou juger et analyser un existant. Le système relie direction, typographie, couleur, structure, contenu, interaction et qualité du produit. Les techniques de mouvement et de mobile se choisissent selon le travail ; une interface Web mobile ne prouve pas un fonctionnement natif.

L’agent lit un noyau commun (la skill, sous un budget contrôlé de 46 000 octets UTF-8), classe le travail, lit le tronc de son mode puis charge les détails nécessaires au moment utile. Les sections propriétaires font foi à leur emplacement actuel ; guides et cartes les rendent plus faciles à trouver. La gouvernance sert le risque, la preuve, la décision et la reprise. Le langage visuel des documents n’impose aucun style aux productions des agents.

Les capacités du système, ses sections à l’essai et leurs limites sont décrites dans [la fiche de version](maintenance/versions.md).

## Installer et utiliser

Suivre [l’installation de la skill](README.md#installer-la-skill-dans-un-agent), puis entrer par le niveau utile : [utiliser](guides/1-utiliser.md), [comprendre](guides/2-comprendre.md), [maîtriser](guides/3-maitriser.md), ou [faire évoluer le système](maintenance/README.md). L’agent garde accès au paquet entier ; les dépendances de chaque outil sont listées dans [la validation](maintenance/README.md#validation).

## Contrôles inclus

Une commande exécute l’ensemble des contrôles du paquet ; leur couverture est décrite dans [la fiche de version](maintenance/versions.md#ce-qui-est-vérifié-ce-qui-ne-lest-pas).

```sh
python3 scripts/validate_all.py --require-browser
```

Sans navigateur, les tests de pages restent non vérifiés ; l’option ci-dessus les exige. Dans le dépôt GitHub, le workflow exécute ces contrôles avec les tests navigateur sur chaque commit ; son résultat se lit sur le commit livré. <!-- références:github -->

## Ce que le validateur atteste

Une `RUN_CARD` validée atteste la forme de la projection et les invariants de la liste close. Elle ne prouve ni la réalité des observations, ni la justesse des jugements, ni les droits et données, ni la qualité perceptuelle. La frontière exacte est définie dans `ACTION/RUN_CARD`.
