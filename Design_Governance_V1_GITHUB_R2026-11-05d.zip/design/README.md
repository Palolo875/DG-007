# Design — le cœur du système

Tout ce qui sert à décider, savoir, construire et finir un design qui vise une qualité professionnelle. La [gouvernance](../gouvernance/README.md) s’adapte au risque, à la décision et aux besoins de reprise : trace légère pour explorer, formalisation nécessaire pour un travail persistant, partagé, audité ou soumis à acceptation. Chaque élément ajouté doit être utile ; les preuves applicables restent dues.

| Dossier | Ce qu’on y trouve |
|---|---|
| [`direction/`](direction/README.md) | Décider ce que la page doit être : [cadrer](direction/cadrer.md), [diriger](direction/diriger.md), [premier objet](direction/premier-objet.md), [la boucle](direction/boucle.md), [le standard](direction/standard.md) |
| [`savoir/`](savoir/README.md) | Le savoir de référence : [fondements](savoir/fondements.md), [qualité créative](savoir/qualite-creative.md), [typographie](savoir/typographie.md), [composition](savoir/composition.md), [images et sources](savoir/images-et-sources.md), [styles](savoir/styles.md), [contexte](savoir/contexte.md), [techniques](savoir/techniques.md), [goût et tendances](savoir/gout-et-tendances.md), [système de design](savoir/systeme-de-design.md), [connexions](savoir/connexions.md) |
| [`formes/`](formes/README.md) | Les structures : [choisir une structure](formes/choisir.md), [catalogue des formes](formes/catalogue.md) |
| [`produit/`](produit/README.md) | Ce qui fait un vrai produit : [premier rendu](produit/premier-rendu.md), [plancher](produit/plancher.md), [finition](produit/finition.md), [preuve visuelle](produit/preuve-visuelle.md), [interface](produit/interface.md) |

Chaque section se lit par son adresse lisible (`savoir/typographie`) ou par son code stable (`SAVOIR/TYPE`) ; les deux désignent la même section.

## Créer puis apprendre

Le système fait travailler deux boucles qui se répondent : l’une crée, l’autre observe et corrige.

<a href="../supports/boucle.md">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="../supports/boucle-sombre.svg">
    <img src="../supports/boucle-clair.svg" alt="Créer puis apprendre : observer, corriger, comparer et décider">
  </picture>
</a>

[Lire le parcours](../supports/boucle.md) · [Tous les supports](../supports/README.md).

| Créer | Observer et corriger |
|---|---|
| Comprendre le produit et son public. | Mesurer ce qui est en jeu et choisir le chemin de travail. |
| Calibrer le niveau sur des références réelles, et essayer les moyens disponibles avant de déclarer une limite. | Dire ce qui est concerné et ce qu’il faudra vérifier. |
| Ouvrir plusieurs pistes, puis choisir une direction adaptée au projet. | Protéger les contraintes qui ne se négocient pas. |
| Composer et construire un ensemble complet, avec les images, ressources et composants utiles. | Regarder le rendu réel et ses limites. |
| Polir sans confondre finition et décoration. | Nommer le défaut principal, corriger, regarder de nouveau, décider. |

La seconde boucle ne se résume pas à une critique écrite. Quand une décision créative est en jeu, elle suit la boucle d’édition : observer le rendu, nommer le défaut principal, modifier l’artefact, comparer, décider (voir [la boucle](direction/boucle.md)).

Pour les défauts de finesse, la route `savoir/composition#jugement-visuel`, activée par la skill, relie chaque symptôme à un geste possible (bord éclairé, alignement optique, chiffres stables, recadrage, regroupement) et à ce qu’il faut regarder de nouveau. Ces gestes se déclenchent selon le cas ; ils ne s’appliquent pas à tous les rendus. Les [formes](formes/README.md) relient de même une intention à un levier de construction et à son effet attendu : proportions, distances, typographie, cadrage, états. Ce n’est ni un catalogue de styles, ni une bibliothèque de composants prêts à l’emploi.

La trace dit ce qui a changé, ce qui n’a pas été vérifié et ce qui vient ensuite. Une preuve technique ne vaut pas jugement esthétique ; une intention créative ne cache pas une preuve d’usage ou d’accessibilité manquante.

Suite : la [direction](direction/README.md), puis la [gouvernance](../gouvernance/README.md). Retour au [README](../README.md).
