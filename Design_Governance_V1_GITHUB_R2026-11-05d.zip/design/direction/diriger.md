# Direction — diriger

Rendre la direction pilotable : cible visuelle, atelier de direction, direction divergente.

<!-- origine:DIRECTION.md -->
## DIRECTION/CREATIVE-BOOT — activer la boucle avant le premier pixel

Pour une décision visuelle ouverte, active avant le build un **Creative Boot** court.

Le boot est un sous-ensemble de la cible (`DIRECTION/VISUAL_TARGET`, « Correspondance des cadres ») ; il tient au maximum les décisions suivantes :

```text
DECISION: décision que le premier rendu doit permettre de prendre
PROMISE: promesse à rendre perceptible
PROOF-OBJECT: objet, état, donnée ou relation qui rend la promesse crédible
GESTURE: premier geste ou action attendu
MODAL: ce que n’importe quelle IA produirait ici (structure, palette, typo, assets) ; se nomme avec les marqueurs de vague datés de `SAVOIR/TOOLS`, que `regard.py` relève sur le rendu
PARTI: garder ou s’écarter — où et pourquoi au regard de la thèse ; projeté dans `direction.parti` (le modal dans `direction.modal`)
STRUCTURAL-TENSION: axe(s) de tension selon BIBLIOTHEQUE (un ou deux, `BIBLIOTHEQUE/TENSION`)
STRUCTURAL-SIGNATURE: relation que cette structure rend possible au-delà de l’héritage
CFT-TARGETS: jusqu’à trois qualités créatives prioritaires pour la construction
FABRICATION: moyens réels (assets, marque, polices, composants, génération, sources, contenu) → essai de la route disponible pour chaque couche qui porte la thèse → plafond par couche (structure, typo, couleur, assets, contenu) → construire, construire avec plafond déclaré, demander X ou changer de route ; inclut la base de l’ancre et ce qu’elle ne permet pas d’affirmer
FIRST-OBJECT: artefact complet construit pour rendre les choix jugeables
DOMINANT-DEFECT: défaut perceptuel ou structurel recherché en premier
```

`DIRECTION` possède la promesse, l’objet, le geste, `MODAL`/`PARTI` et `FABRICATION` ; `BIBLIOTHEQUE` possède la tension et la signature structurelles ; `SAVOIR/CRAFT` possède le jugement des qualités de présence et de fabrication ; `ACTION` possède l’observation, la preuve, la correction et la clôture. Les `CFT-TARGETS` sont un foyer de construction, pas un score : les autres dimensions restent applicables lorsqu’un risque ou une décision les active et ne deviennent `N/A-JUSTIFIED` que si elles sont réellement hors périmètre.

<!-- noyau:début MOY-PLAFOND -->
<!-- concept:HON-03 -->
Avant le premier rendu, le boot doit conduire à un artefact complet, crédible et observable — jamais à un wireframe volontairement creux lorsque les capacités sont disponibles ; lorsqu’elles manquent, `FABRICATION` déclare le plafond avant le build et le rendu sort avec la meilleure route de `DIRECTION/VISUAL_TARGET`. Après observation, la boucle d’édition et la trace prennent le relais : **un défaut dominant**, la modification réelle ou la raison de l’arrêt (`DIRECTION/DOUBLE-LOOP`, one-shot).

**Atteindre avant de déclarer.** Sur une décision visuelle ouverte, le niveau visé est haut ; il se déduit de la destination et ne se demande pas. Une demande simple garde un rendu simple : le niveau porte sur la justesse et la finition, pas sur la quantité. Un plafond sous ce niveau ne se déclare qu’après un essai : pour chaque couche qui porte la thèse (typographie, surface, asset principal, objet de preuve, données), essaie la route que l’environnement offre — carte des moyens (`SAVOIR/TOOLS/MOYENS` ; polices ouvertes : `python3 scripts/parcours.py polices "Famille:400,700i"`), connecteur, recherche, génération dirigée si la destination la permet (prompt et exploitation : `SAVOIR/SOURCE`, « Diriger une génération ») — et écris dans la trace l’essai et son issue : atteinte, échec ou interdite. Pour l’asset principal, cherche aussi ce qui manque à la scène (un geste, un lieu, une silhouette non reconnaissable), pas seulement l’objet ; une collection qui refuse se remplace par une autre, jamais par un contournement. Un essai par couche qui porte la thèse ; les autres gardent l’héritage. Une technique qu’aucune mémoire sûre ne porte se cherche avant d’être codée (`SAVOIR/TECH`, « Chercher une méthode »). La génération pour un vrai produit attend l’autorisation de la personne (prise de brief) ; pour une démonstration, elle est permise et marquée.

**Pas de figuratif de mémoire.** Ce qui est codable par nature (interface, données, typographie, géométrie, motif) se code. Au niveau haut, la planéité se choisit : une matière codée (grain, trame, papier, lumière, fond perdu) s’essaie contre l’aplat, et l’aplat n’est gardé que s’il gagne. Un marqueur de vague employé ainsi, une fois et sur l’idée, est un moyen (`SAVOIR/TOOLS/CONVERGENCE`). Un sujet figuratif (objet, lieu, personne, animal, plante) vient d’un asset fourni, d’une source ouverte, d’une génération dirigée marquée ou d’un emplacement marqué ; il ne se dessine que si la direction choisit un registre dessiné et le dit. Sans photo, une atmosphère construite (flou, lumière, matière : `SAVOIR/SOURCE`, « Construire une atmosphère ») vaut mieux qu’un aplat ou qu’un dessin.
<!-- noyau:fin MOY-PLAFOND -->

Sa valeur se juge à sa conséquence sur le premier objet, non à la complétude du formulaire ; il peut être omis pour un delta strictement local.

<!-- origine:DIRECTION.md -->
## DIRECTION/VISUAL_TARGET — rendre la direction pilotable

Sur une surface `DIRECTION`, la cible visuelle rassemble les décisions nécessaires avant le build. Elle ne remplace ni la spec détaillée ni les preuves d’ACTION. Elle empêche de commencer avec un adjectif, une palette ou une liste de composants.

| Champ | Décision à déclarer avant le build |
|---|---|
| **Thèse** | Quel monde, quel public et quelle promesse la surface doit-elle rendre crédibles ? |
| **Conséquence observable** | Ce que l’utilisateur doit percevoir, comprendre ou pouvoir faire dans la première scène si la thèse est tenue. |
| **Ancre** | `ANCHOR-GENERATED`, `ANCHOR-OBSERVED` ou `ANCHOR-PROVIDED` ; ce qui a été observé ; attributs retenus, rejetés et limites de transfert. |
| **Silhouette** | Rapport vide/masses, foyer, axe, cadre ou circulation reconnaissable sans le contenu fin. |
| **Relations de plans** | Relation entre premier plan, contexte, asset, preuve et action ; ne pas confondre profondeur décorative et hiérarchie de lecture. |
| **Opération visuelle dominante** | Relation par laquelle un contenu, une preuve ou une donnée rend la promesse perceptible. |
| **Matière / asset** | Rôle dans la promesse, route de production initiale, cadrage, zone sûre, contraste, mobile, fallback et condition de retrait. Une matière native au code — règle, trame d’impression, masque, gradient, typographie, SVG ou composition procédurale — est un choix complet lorsqu’elle porte mieux la relation qu’un asset externe. |
| **Typographie** | Rôle du display, du corps, des données et de l’action ; mesure, cadence et contre-indication. |
| **Objet de preuve** | Objet, média, état ou fenêtre produit qui répond directement à la promesse. |
| **Modal / parti** | Le modal nommé (ce que n’importe quelle IA produirait ici) et le parti : garder ou s’écarter, où et pourquoi, avec raison produit ou perceptuelle. |
| **Résolution initiale** | Quel niveau de contenu réel, d’état, de responsive, d’asset et de détail doit déjà tenir au premier rendu ? |

Cette table est la seule représentation canonique de la cible. L’opération dominante peut être discrète : retenue, vide, séquence, contraste de densité ou émergence d’un signal critique. Elle ne prescrit ni texture, ni type géant, ni masque, ni palette, ni composant.

### Correspondance des cadres

Le Creative Boot, l’atelier, le cadrage du noyau, la trace légère et la `RUN_CARD` sont des vues de cette cible. Une même notion y porte le nom suivant ; elle est écrite une fois, dans la vue qui la rend décisionnelle (règle de réconciliation du noyau).

| Notion | Cible | Cadrage du noyau | Creative Boot | Atelier | Trace légère | `RUN_CARD` |
|---|---|---|---|---|---|---|
| Promesse | Thèse ; conséquence observable | situation ; promesse | `PROMISE` | moment humain | thèse | `direction.thesis` |
| Objet de preuve | Objet de preuve | objet de preuve | `PROOF-OBJECT` | — | thèse (objet de preuve) | — |
| Geste | Opération visuelle dominante | geste produit | `GESTURE` | geste produit | thèse (geste) | — |
| Tension | Compilation (tension) | tension | `STRUCTURAL-TENSION` (`BIBLIOTHEQUE/TENSION`) | tension | — | — |
| Modal et parti | Modal / parti | position/exclusion | `MODAL`, `PARTI` | position et exclusion | modal, trame et parti | `direction.modal`, `direction.parti` |
| Alternative écartée | — | contre-choix situé | — | contre-choix situé | proposition (alternative écartée) | — |
| Trame modale | — (test de trame, `BIBLIOTHEQUE/SELECT`) | test de trame | — | — | modal, trame et parti | `direction.trame` (facultatif) |
| Ancre et moyens | Ancre ; matière / asset | ancre ; plafond | `FABRICATION` | — | plafond atteint, essais par couche et contenus marqués | `direction.calibration` |
| Vérité | — | marquage de vérité | — | vérité de la scène | contenus marqués | — |
| Premier objet | Résolution initiale | premier objet | `FIRST-OBJECT` | — | — | `direction.first_object` |
| Signature | Silhouette | — | `STRUCTURAL-SIGNATURE` | — | — | `creative_close.signature` |
| Défaut dominant | — | — | `DOMINANT-DEFECT` | — | défaut dominant restant | `creative_close.dominant_defect` |

Le boot et l’atelier n’ajoutent que ce que la cible ne porte pas : la décision du rendu (`DECISION`, la décision dominante de la ligne `RUN`), les qualités visées (`CFT-TARGETS`) et le défaut recherché pour le boot ; le moment humain et le contre-choix pour l’atelier.

### Compilation de la première proposition

Pour une surface visuelle ouverte, ne traite pas les champs de `VISUAL_TARGET` comme une liste indépendante. Compile-les dans cet ordre : **contexte réel → promesse → tension → relation perceptible → objet de preuve → geste → composition → matière, typographie et asset → états et contraintes → premier rendu jugeable**. La sortie attendue est une relation visible dans l’artefact, pas un dossier complet autour d’un artefact générique. Cet ordre décide quoi construire ; la séquence de composition du noyau (intention → … → retenue) dit comment le construire, à partir de la relation compilée.

Les décisions de compilation se lisent dans la table : promesse = thèse + conséquence observable ; relation = opération dominante + relations de plans ; composition = silhouette + relations de plans ; résolution initiale = ligne du même nom.

La qualité ne vient pas d’une police, d’une image ou d’une texture ajoutées séparément, mais du renforcement mutuel de la composition, du contenu, du type, de l’objet de preuve, de la matière, des états et du comportement ; un élément sans relation visible est retiré ou sa limite nommée.

Un registre naturel, organique, éditorial, architectural, tactile ou technique est une hypothèse située, non un preset. Il peut modifier la matière, la respiration, la profondeur, la typographie, la donnée ou le geste lorsque cette relation appartient au produit. Dans une surface de qualité, l’agent peut aussi composer un composant authored : un objet visible dont la silhouette, le contenu, la hiérarchie, la matière et le comportement sont pensés pour le contexte, sans rendre les primitives critiques inhabituelles par principe.

**Qualifier la direction.** Une direction artistique est située lorsqu’elle relie un point de vue, un produit, un public, un contenu, un médium et une contrainte à un premier objet observable. Sa créativité se juge par la pertinence de l’écart ou de la relation produite, pas par la nouveauté seule ; son goût se lit dans la sélection, la proportion et la retenue des choix, pas dans une préférence universelle. Le craft et le polish du rendu construit restent jugés dans `SAVOIR` et vérifiés dans `ACTION` ; ils ne sont pas promis par la seule force de la thèse ou de la référence.

### Test d’utilité de l’ancre

Une ancre visuelle est suffisante seulement si elle apporte au moins :

1. une décision qui change réellement la structure, la hiérarchie, la matière ou le rapport texte/preuve ;
2. une contre-indication identifiable, c’est-à-dire un choix à ne pas transférer ;
3. une liste d’attributs retenus, rejetés et non transférables.

Une image jolie mais sans conséquence de décision est décorative et ne suffit pas comme ancre. Une référence ne prouve ni l’efficacité produit, ni le droit de réemploi, ni l’adéquation au public ; elle documente une relation observée ou une résolution de craft.

### DIRECTION/ASSET-ROUTE — décider la route de production

Lorsqu’un asset ou son absence porte une décision perceptible, nomme **une route de production initiale** avant le build. Cette route peut être révisée sur preuve si la décision de direction reste stable et si la révision réduit un risque de droits, de performance, de fidélité, de maintenance ou d’intégration.

Ce n’est ni un statut, ni une préférence d’outil : c’est une réponse située au rôle de l’asset, aux droits, au délai et à la **destination**. En produit réel, un asset manquant devient une route `CODE-NATIVE` ou `SANS-ASSET` ou un emplacement marqué, jamais un faux asset ; en démo, une approximation marquée illustrative ; un contenu absent, un emplacement illustratif.

| Route | À retenir lorsque | À déclarer honnêtement |
|---|---|---|
| `CODE-NATIVE` | La relation utile est mieux portée par type, données, matière, SVG, mise en page ou mouvement produit. | Ce qui ne sera pas simulé comme image, photo ou illustration authentique. |
| `FOURNI` | Un asset réel transmis ou déjà autorisé porte la promesse. | Disponibilité, droit connu ou inconnu, zones de crop et contraintes d’usage. |
| `CURATÉ` | Une source externe autorisée apporte une matière, une preuve ou une spécificité qu’il serait faible de simuler. | Provenance, droit, transformation prévue et raison de ce choix plutôt qu’un voisin facile. |
| `GÉNÉRÉ-DIRIGÉ` | Une image originale sert réellement la direction et aucune source autorisée observée dans le scope, le délai et les droits du run ne résout mieux le besoin. | Direction de composition, référence(s) de calibration, modèle/outil si connu, itérations observées et limites de fidélité. |
| `HYBRIDE` | La valeur vient de la rencontre entre asset, composition, traitement, donnée, type ou code. | Quelle part porte le sens, ce qui est transformé et le fallback si l’asset est retiré. |
| `SANS-ASSET` | La retenue porte mieux la relation que tout asset. | Ce qui porte la promesse à la place et la condition qui ferait revenir sur ce choix. |

La génération ne reçoit ni le rôle de défaut, ni celui de rattrapage décoratif. Une image générée est une **hypothèse visuelle comparable**, non une autorité esthétique. Une référence observée est un calibrateur, non un modèle à reproduire. La recherche ne vaut pas accumulation : elle explore seulement lorsqu’une source, un médium ou un registre peut modifier la direction.

Une route est insuffisante si elle n’explique pas pourquoi l’asset, à son crop réel et dans son contexte réel, augmente la preuve, la compréhension ou la singularité de la surface. Sources par couche : carte des moyens (`SAVOIR/TOOLS`, `[VEILLE]`) ; un asset moyen reçoit le traitement que justifie la thèse (`SAVOIR`, section `DESIGN-ATLAS`), jamais un dessin de remplacement.

### DIRECTION/ANCHOR-RESERVE — réserve `ANCHOR-GENERATED` en enjeu identitaire élevé

Lorsque l’enjeu identitaire est élevé et que seule la voie `ANCHOR-GENERATED` — hypothèse visuelle générée — est utilisée, la `RUN_CARD` porte une réserve explicite : « Direction calibrée uniquement sur hypothèse générée, sans référence observée ni contrainte réelle. » Le statut de direction ne peut pas être `HELD` sans cette réserve ou sans calibration complémentaire par `ANCHOR-OBSERVED`, `ANCHOR-PROVIDED` ou contrainte réelle. Cette réserve décrit une limite de calibration ; elle ne déclare ni l’image fausse, ni la direction invalide par principe. Dans une `RUN_CARD`, cette base est `direction.calibration.basis` : `real_constraint` lorsqu’une contrainte réelle calibre la direction, sinon `generated_only_reserved`, qui interdit `ACCEPTED` (`ACTION/PIPELINE-DIRECTION`).

### Prête à construire

> **Passage à `SPECCED`.** Dans `ACTION/STATUS`, `SPECCED` signifie que la direction, la hiérarchie, le contrat ou l’ancre nécessaires sont disponibles ; cela ne signifie ni construit, ni observé, ni accepté. Une surface `DIRECTION` est prête à construire lorsque chaque champ de la table de `VISUAL_TARGET` est renseigné ou `N/A-JUSTIFIED` ; la route d’asset (`DIRECTION/ASSET-ROUTE`) seulement si nécessaire.

La cible peut vivre dans la `RUN_CARD`, le ticket ou le manifeste local. Après le build, `ACTION/VISUAL_PROOF` vérifie le rendu réel contre cette cible.

---

<!-- origine:DIRECTION.md -->
## DIRECTION/DIRECTION-ATELIER — module officiel de direction située

<!-- noyau:début RECONCILIATION -->
`CREATIVE-BOOT`, `VISUAL_TARGET` et `DIRECTION-ATELIER` ne demandent pas trois descriptions concurrentes : la table « Correspondance des cadres » de `DIRECTION/VISUAL_TARGET` dit quelle notion correspond à quelle autre. Lorsque la même information apparaît sous plusieurs noms, conserve-la dans la vue qui la rend décisionnelle et renvoie les autres vues à cette sortie : la promesse devient la thèse si elle est transformée en position, le parti devient une exclusion s’il gouverne la scène, et l’ancre devient une preuve de calibration si elle modifie la composition. Les champs non transformés ne sont pas recopiés.
<!-- noyau:fin RECONCILIATION -->


`DIRECTION-ATELIER` est un module de craft officiel de V1. Il est **activable**, jamais automatique : utilise-le pour une surface `DIRECTION` lorsque la première scène, l’identité, la confiance culturelle ou la relation entre promesse et preuve demandent une position située. Ne l’active pas si son contrat ne peut modifier ni la structure, ni l’objet de preuve, ni le choix de direction. Il ne doit jamais devenir un questionnaire imposé à la personne. La direction reste le propriétaire du cadrage créatif ; la preuve exécutée, les gates, les verdicts et la clôture restent ceux d’`ACTION`.

> **Règle de portée.** Une fois le module activé, son noyau s’applique dans la même trace locale que `DIRECTION/VISUAL_TARGET`. `ACTION` reste le propriétaire de la preuve, de la capture, de `CAPABILITY-BASIS`, des verdicts et de la clôture.

### Noyau du contrat

Le contrat utilise la cible visuelle existante ; il ne la remplace pas par un formulaire parallèle (voir « Correspondance des cadres » dans `DIRECTION/VISUAL_TARGET`). Il rend explicites les décisions qui risquent autrement de se réduire à un adjectif, une palette ou une tendance.

| Élément | Décision à rendre retrouvable | Limite à conserver |
|---|---|---|
| **Moment humain** | Dans quelle situation concrète la personne rencontre-t-elle la promesse ? | Ce n’est pas un portrait de public ni une donnée utilisateur validée. |
| **Tension** | Quelle polarité organise la direction : hésitation/élan, densité/respiration, mémoire/disparition, contrôle/transmission ou équivalent situé ? | La tension ne suffit pas si elle ne change aucune décision visible. |
| **Geste produit** | Quelle action, relation ou transformation l’artefact rend-il perceptible ? | Un geste de démonstration ne prouve pas un résultat produit réel. |
| **Position et exclusion** | Quelle lecture est retenue, et quel gabarit, effet ou relation est refusé avec une raison produit ou perceptuelle ? | L’exclusion n’impose ni nouveauté ni opposition artificielle. |

Lorsque le choix est ouvert, formule des familles internes réellement distinctes, puis conserve la position retenue et un **contre-choix situé** : le choix plausible qui serait meilleur sous une autre contrainte. Ces familles restent internes ; la personne reçoit une proposition principale, sauf arbitrage stratégique ou demande explicite. Si aucun choix plausible ne peut modifier la décision, l’absence de contre-choix est `N/A-JUSTIFIED` dans la trace existante. Aucun quota de familles, de variantes ou de builds n’est créé.

### Vérité de la scène et clôture de craft

<!-- noyau:début VER-SCENE -->
<!-- concept:HON-01 -->
Place un **marquage local de vérité** à proximité du claim ou de l’objet concerné. Ce marquage n’est ni un statut ACTION, ni une voie d’ancrage, ni un verdict. Il a deux axes : la **factualité**, `OBSERVED` ou `ILLUSTRATIVE`, obligatoire et exclusive ; la **nature**, `MECHANISM`, qui se cumule avec la factualité. La fiction l’emporte : un élément illustratif rend le tout `ILLUSTRATIVE`.
<!-- noyau:fin VER-SCENE -->

| Label local | Signification exacte |
|---|---|
| `TRUTH/OBSERVED` | L’affirmation se limite à l’artefact, la capture, le test ou la source réellement observés ; sa base et son scope restent déclarés selon ACTION. |
| `TRUTH/ILLUSTRATIVE` | L’objet, le contenu ou l’exemple sert à rendre une hypothèse visible ; il ne représente ni une personne, ni une donnée, ni un résultat réels. |
| `TRUTH/MECHANISM` | Le rendu matérialise une relation produit, une action ou une transformation ; il ne prouve pas à lui seul un effet externe, une préférence ou une tâche réussie. |

<!-- noyau:début VER-AUDIENCE -->
**Audience.** Les labels `TRUTH/*` sont internes : spec, trace, annotations. Ils n’apparaissent jamais dans l’interface produit. Quand le public doit savoir, la divulgation se fait en langage produit (« données d’exemple », « taux illustratifs »).
<!-- noyau:fin VER-AUDIENCE -->

Après le build, utilise la capture et les preuves applicables d’ACTION. La critique de craft, consignée dans la revue créative unique, emploie des verbes et leurs effets — par exemple **isole**, **déplace**, **matérialise**, **ralentit**, **efface** — puis nomme le défaut ou la réserve qui reste. « Premium », « beau » ou « créatif » ne constituent pas une preuve de clôture.

Le module est terminé lorsqu’il a changé, confirmé ou abandonné une décision visible, ou documenté honnêtement qu’il ne pouvait pas le faire : `N/A-JUSTIFIED` si aucune conséquence n’était applicable, `NOT-OBSERVED` si la conséquence attendue n’a pas été observée (`ACTION/STATUS`). Il reste un conseil de craft instrumenté : il ne garantit ni goût universel, ni préférence, ni compréhension utilisateur, ni conformité, ni qualité de sortie par simple invocation.

<!-- origine:DIRECTION.md -->
## DIRECTION/DIVERGENCE — direction divergente, déclenchement

Le mode `DIRECTION` exige une comparaison de positions réellement distinctes lorsque la décision est ouverte. Il ne demande pas un catalogue de variantes et n’impose aucun quota de nouveauté.

Avant de diverger, situe la première idée sur les axes de position de `SAVOIR/CRAFT/CFT-02`, leur seul propriétaire : structure, matière, voix, temporalité, densité, rapport texte/image.

<!-- concept:ALT-01 -->
En `DIRECTION`, considère une **alternative située** lorsque la décision est ouverte et qu’une position différente peut raisonnablement modifier le choix. Elle doit répondre à un public, un JTBD, une contrainte ou une opportunité distincte. Ses leviers sont les axes de `SAVOIR/CRAFT/CFT-02` ; sa matérialisation, sa trace selon le niveau retenu et sa comparaison suivent `ACTION/PIPELINE-DIRECTION` (étapes 3 et 7).

<!-- noyau:début DIR-LEVIERS -->
**Diverger sur image.** [REQUIS PAR LE MODULE — premier écran, identité ou scène d’une surface `DIRECTION` dont la décision visuelle est ouverte ; pas pour un correctif local] Avant le premier build :

1. **Échantillonner.** Écris cinq directions de premier écran, chacune avec la probabilité estimée qu’un modèle la produise pour ce brief. La plus probable est le `MODAL` de `DIRECTION/CREATIVE-BOOT`. Garde trois directions moins probables, chacune tirée d’une piste différente du sujet : ce qu’il produit, montré tel quel ; sa forme ou un attribut qui le signe, agrandi, recadré ou devenu la structure ; son nom, dont les lettres contiennent une image ou se découpent ; son lieu ; son rituel ; l’objet imprimé de son monde ; son opposé ; une donnée qui lui est propre. Chacune passe le test du lien : le procédé dit une idée du sujet, il ne décore pas. Chacune nomme aussi son registre (voir `REGISTRE` ci-dessous) ; les trois gardées diffèrent de la modale et entre elles sur au moins deux dimensions du registre (composition, matière, représentation, époque et culture, densité, interaction, voix), pas seulement par l’idée. Un sujet ancré dans un lieu se calibre par des références de ce lieu (artisans, archives, lettrages, images locales), pas par un registre « luxe » importé (`SAVOIR/SOURCE`, « Calibration culturelle »). Une donnée calculée devenue image est une piste parmi d’autres, pas le défaut (inventaire et phrase d’idée : `SAVOIR/CRAFT/CFT-01`).
2. **Esquisser au bureau, puis choisir sur la planche.** Rends les trois en premier écran complet, même contenu, à 1440 px ; corrige sur capture les défauts de mise en page avant de juger. Assemble la planche avec la modale en référence (l’existant s’il y en a un, sinon une esquisse rapide de la modale) : `python3 scripts/planche.py planche.png modale.html a.html b.html c.html --bureau-seul`. Une esquisse ne l’emporte que si elle bat la modale à la vue ; sinon garde la modale et dis pourquoi. Ce choix est celui de l’agent : il choisit une branche, il ne prouve rien ; l’atelier éprouve ensuite la branche gardée. Nomme ce que la retenue perd. La recomposition à 390 px se construit ensuite sur la seule direction gardée ; si son idée ne tient pas en mobile, reviens à la planche.
3. **Éprouver dans les deux sens.** Fais le tour d’atelier (`ACTION/ATELIER-EDITION`) sur la retenue : une variante qui retire, une qui intensifie, comparées à l’original.
4. **Mesurer avant de montrer.** Le parcours par défaut, `python3 scripts/parcours.py verifier page.html --foyer SÉLECTEUR --action SÉLECTEUR` sur la version gardée : recette à toutes ses largeurs, regard (attention, foyer, contraste sur le fond réel, marqueurs de vague), captures @2x, signaux de finition et planche de mouvement (l’entrée image par image, le défilement, le survol), en une fiche ; `--refs DOSSIER` la met à côté des références.

**Décision étroite.** Si la marque, la structure ou l’asset principal sont imposés et ne laissent ouvert qu’un axe de position (`SAVOIR/CRAFT/CFT-02`), écris trois directions (la modale et deux autres), esquisse la plus forte des deux et compare-la à la modale sur la planche ; les étapes 3 et 4 restent dues. Un brief court ou vague n’est pas une décision étroite.

La suite de la page se construit dans la direction gardée. Cette procédure tient lieu d’alternative située et de premier tour d’atelier. En trace légère, la ligne « modal, trame et parti » nomme les directions et leurs probabilités, les marqueurs relevés, la planche, le choix et sa raison, la branche gardée ; en décision étroite, l’élément imposé et l’axe resté ouvert.
<!-- noyau:fin DIR-LEVIERS -->

<!-- noyau:début DIR-DECLARATION -->
**Déclarer la direction.** [REQUIS PAR LE MODULE — surface `DIRECTION`, ou surface `STANDARD` ou `ITER` dont la décision visuelle est ouverte] Avant de construire la suite (après la planche ; sans divergence, avant le premier build), nomme ce que tu vas faire :

```text
DIRECTION — un nom court tiré du sujet (« Piste de relais »), pas un adjectif.
VISION — la thèse en une phrase : ce que la personne doit voir, comprendre ou ressentir, et grâce à quoi.
REGISTRE — la manière d’exprimer, en forme composée : une base et un modificateur pris dans deux dimensions de `SAVOIR/STYLE` (« éditorial industriel » : composition éditoriale, matière de fiche technique), et deux marqueurs qui se verront sur la capture ; jamais un adjectif seul.
NIVEAU — le niveau visé, en un test vérifiable sur capture (« qu’on la prenne pour la capture réelle d’une marque soignée »).
ASSET — l’image principale et son traitement ; si elle manque, comment la construire.
COMPOSANT — les composants ordinaires et leurs conventions exactes, celles que l’œil attend.
FINITION — ce qui ne doit rien laisser par défaut : rayons, filets, icônes, gris, espacements.
MOUVEMENT — le moment orchestré (une entrée, une révélation) et ce qui répond au geste, ou « aucun » avec sa raison ; jamais un fondu sur chaque section ni un survol sur chaque carte.
MOBILE — ce que devient l’idée à 390 px.
```

Les six dernières lignes forment la cible concrète : écris-les comme pour un autre designer, avec des mots qui se vérifient sur la capture, jamais un adjectif seul. La capture se juge ensuite contre elles.

Quand le run reprend un rendu précédent, l’antécédent se compare dans `REUSE-CHALLENGE` (`DIRECTION/FIRST-OBJECT`, « Où lire l’antécédent ») ; quand un profil de `SAVOIR/STYLE` est retenu, il se décide dans `PROFILE-DECISION`. Ni l’un ni l’autre ne s’annonce.

La déclaration est une intention (`DECISION-INTENT`), non un verdict : la capture dit ensuite si la direction tient. Un nom ou une vision qu’un concurrent pourrait signer se reprend. Avant le premier build, relis la déclaration contre la page que tu produirais pour n’importe quel brief semblable : une ligne qui s’y retrouverait telle quelle se révise, habillage de gabarit compris (capitales espacées au-dessus des titres, points médians entre des mots, flèche ajoutée aux boutons) ; la trace dit ce qui a changé. Montre la déclaration à la personne dès qu’elle est fixée si elle suit le run ; sinon, elle ouvre la réponse, en une ligne. En trace complète, la vision va dans `direction.thesis` ; en trace légère, elle tient dans la ligne « direction déclarée ».
<!-- noyau:fin DIR-DECLARATION -->

La direction retenue ne l’emporte que si son avantage est formulé en une phrase vérifiable reliant la position à un effet attendu sur la tâche, la compréhension, la preuve, la singularité ou la contrainte. Une palette seule, un adjectif ou une variation cosmétique ne constituent pas une direction distincte.

L’axe matière doit toujours être **déclaré**, y compris lorsqu’il est hérité, plat, absent ou inchangé. Il n’impose jamais une texture. Une surface peut être plate, photographique, illustrée, spatiale ou retenue si cette position sert mieux le contenu, la tâche, la preuve ou la contrainte.

Le checkpoint suit `ACTION/PIPELINE-DIRECTION` : la première proposition en tient lieu, sauf action irréversible ou coûteuse ; elle présente la position retenue, l’alternative considérée, la raison du choix et la preuve attendue. Si le regard requis n’est pas disponible, le run indique `BLOCKED`, `EXPLORATORY` ou le statut prévu par `ACTION` ; l’absence ne devient jamais une validation implicite.

---
