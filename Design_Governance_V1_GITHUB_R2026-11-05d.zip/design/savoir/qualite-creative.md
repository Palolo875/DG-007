# Savoir — qualité créative

Ambition, forme située, registres, composition, émotion, premier contact, couleur, écriture et contenu.

<!-- origine:SAVOIR.md -->
# SAVOIR/CRAFT — anti-slop, composition et expression

Dans V1, le **polish structurel** concerne les proportions, la hiérarchie, la densité, la lisibilité, les états et le comportement.

### Qualité du premier rendu, one-shot et preuve

Lorsque la direction visuelle est ouverte, le premier rendu doit déjà être **composé, spécifique, crédible, désirable et suffisamment résolu** dans le périmètre du mode. Il ne peut pas être seulement un moodboard, une structure vide, un assemblage de primitives ou une surface nominalement conforme lorsque la décision exige une scène réelle.

Distingue trois moments de la qualité : **qualité intrinsèque visée** — ce que l’objet doit déjà posséder avant toute prétention de réussite ; **qualité construite observée** — ce que le rendu réel permet d’inspecter dans son contexte ; **qualité prouvée** — ce qu’ACTION établit sur l’usage, l’accessibilité, la robustesse, la performance ou la conformité. Un rendu peut être visuellement fort mais encore non prouvé en utilisabilité ; un rendu peut être conforme et propre mais rester générique. À chaque moment, la résolution atteinte se lit avec un seul modèle de niveaux : `Correction`, `Précision` et `Intention` (« Jugement visuel situé »).

Le `one-shot` suit la branche one-shot d’`ACTION/PIPELINE-DIRECTION` : une exécution raccourcie de la boucle, jamais sa suppression ; un premier objet faible se corrige ou se retourne.

La boucle de jugement est la boucle d’édition de `DIRECTION/DOUBLE-LOOP`, copiée dans le noyau de la skill.

Le **polish expressif** concerne la matière, la typographie, la couleur, l’image, la silhouette, le rythme et la singularité située. Le polish décoratif ajoute une impression de finition sans conséquence utile ou perceptuelle défendable ; il doit être réduit, même s’il est séduisant.

## CFT-00 — qualité créative et niveau d’ambition

[DURABLE] Lorsqu’une surface, une identité ou une scène engage directement la perception, la qualité attendue ne se limite pas à l’absence de slop ou à la conformité d’une structure. La proposition doit viser, dans la mesure du possible, une **présence**, un **point de vue**, une **spécificité**, une **culture visuelle transformée**, une **composition maîtrisée**, une **expression cohérente**, une **désirabilité située** et une **résolution proportionnée à l’ambition**.

Ces qualités ne constituent ni un score, ni un verdict automatique, ni une promesse universelle. Elles forment une grille de regard qui aide à choisir, comparer, retirer et polir. Une proposition peut être fonctionnelle sans être expressive, soignée sans être spécifique, créative sans être compréhensible ou premium dans son intention sans atteindre encore le niveau de résolution attendu. Décris alors l’écart observable au lieu de le masquer derrière un adjectif.

| Dimension | Question de critique | Signal observable attendu |
|---|---|---|
| **Présence** | Le premier contact possède-t-il une force perceptuelle juste ? | Un foyer, une silhouette ou une relation retient le regard sans effet gratuit. |
| **Point de vue** | Sent-on une position plutôt qu’une application de composants ? | Des choix de composition, de rythme, de type, de matière ou de contenu sont assumés. |
| **Culture visuelle** | Les références ont-elles été comprises et transformées ? | Une relation extraite d’un autre domaine devient un choix propre au produit. |
| **Spécificité** | Qu’est-ce qui appartiendrait moins à un autre produit ? | Contenu, donnée, voix, interaction, structure ou matière portent le contexte réel. |
| **Composition** | Les masses, vides, axes, échelles et tensions sont-ils maîtrisés ? | Le regard circule avec une hiérarchie et un rythme perceptibles. |
| **Désirabilité** | Le rendu donne-t-il envie d’entrer, de comprendre ou de continuer ? | La valeur, la confiance ou la curiosité sont soutenues sans manipulation décorative. |
| **Résolution** | Les détails sont-ils au niveau de l’idée ? | États, responsive, microcopie, transitions, assets et composants tiennent la direction. |
| **Retenue** | Le design sait-il s’arrêter ? | Les effets, variantes et détails faibles ont été retirés lorsqu’ils n’ajoutent rien. |

Une **proposition premium** se juge avec l’heuristique [« Premium perçu »](fondements.md#premium-perçu-comme-heuristique-de-jugement) (`SAVOIR/FRAME`), sa seule définition ; elle n’est pas définie par une palette sombre, une grande typographie, un espace vide, une matière riche ou un nom de style, et doit survivre au contenu réel, aux états, au mobile, aux contraintes du produit et au geste principal.

**Substance.** La retenue n’est pas le vide. Signaux d’enquête, sans seuil ni score : un écran presque vide qui n’est pas un repos voulu ; une section demandée livrée en quelques mots ; un texte courant petit ou grisé sur toute la page ; une page qui a perdu ses motifs sans rien gagner à la place. Réponse possible : agrandir ce qui compte, livrer le contenu complet à taille lisible (`CNT-01`), mettre une image ou un champ de couleur faits pour ce sujet, ou couper la section ; ne comble pas par un ornement (`FND-01`, retenue avant accumulation). Un vide placé qui porte une relation reste valable (`SAVOIR/CRAFT/CFT-03`, échelle et champ calme).

**Mouvement.** Question de revue, sans quota : qu’est-ce qui bouge sur cette surface, et pourquoi ? Une page faite pour se montrer (lancement, récit, présentation d’une activité) où rien ne répond au regard ni au geste appelle l’enquête ; une page d’outil ou de lecture qui reste fixe n’a rien à justifier. La réponse peut être une apparition, un changement d’état, un défilement qui révèle, ou rien, avec sa raison. Aucun nombre d’éléments animés n’est attendu. Durées et courbes de départ : `SAVOIR/CONTEXT`, « Durées et courbes, points de départ » ; l’alternative sous mouvement réduit reste due (`ACTION/GATE-A`).

### Creative Quality Review

<!-- noyau:début BOUCLE-REVUE -->
[MÉTHODE] Pour une décision où la qualité visuelle est dominante, conduis une revue courte après la première scène et après la repasse de craft : **ce qui est présent**, **ce qui est spécifique**, **ce qui est culturellement transformé**, **ce qui est encore générique**, **ce qui manque de résolution** et **l’intervention au gain attendu le plus utile**. Relie le défaut à un geste du vocabulaire perceptuel de `SAVOIR/STATE`, avec sa condition et l’effet à réinspecter. Les gestes proposés sont des points de départ, pas une liste fermée ; un autre geste reste recevable s’il traite le défaut et rend son effet observable. Nomme l’objet, le terme et la modification. Une incohérence de direction appelle une réouverture, pas une accumulation de détails. Si aucun geste ne promet de gain utile, justifie la conservation. La revue produit une prochaine action, sans score esthétique ni substitution aux preuves d’ACTION.
<!-- noyau:fin BOUCLE-REVUE -->

**Rattachement des grilles.** La revue créative est la grille de lecture du rendu. Les autres grilles en sont des vues détaillées, à ouvrir quand leur moment ou leur scope l’exige :

| Question de la revue | `CFT-00` | Contrat du premier objet (`DIRECTION/FIRST-OBJECT`) | Gate C (`ACTION/GATE-C`) | Creative close (`ACTION/CLOSE-PACKAGE`) |
|---|---|---|---|---|
| Ce qui est présent | Présence ; composition ; désirabilité | Présence ; foyer ; désirabilité située | C3 ; C4 | `presence` |
| Ce qui est spécifique | Spécificité ; point de vue | Signature ; intégration | C1 ; C2 | `signature` |
| Ce qui est culturellement transformé | Culture visuelle | — | — | — |
| Ce qui est encore générique | Point de vue et spécificité, en négatif | Signature (« retour si ») | C1 à C3 (« retour si ») | `dominant_defect` |
| Ce qui manque de résolution | Résolution | Résolution ; vérité de scène ; résilience visible | C5 ; C6 | `craft_detail` |
| L’intervention au gain le plus utile | Retenue | — | — | `next_polish_action` |

Le jugement visuel situé (composition et détails) et le premium perçu (fondements) sont des lentilles de lecture, pas des grilles de verdict ; l’absolu 1 de `DIRECTION/STANDARD` reste un plancher, pas une grille.

Un rendu n’est pas considéré comme suffisamment travaillé parce qu’il contient davantage de détails. Il l’est lorsque chaque détail important renforce la hiérarchie, le sens, la relation au produit ou la qualité de présence. La beauté pertinente peut venir de l’intensité comme de la retenue ; elle peut être éditoriale, technique, tactile, chaleureuse, colorée, ludique ou silencieuse selon le contexte.

Un **composant authored** est un objet visible conçu pour le produit : sa silhouette, son contenu, sa hiérarchie, sa matière et son comportement forment une unité. Il peut être construit à partir de primitives robustes ; authored ne signifie ni inédit dans le code, ni inhabituel par obligation. Les primitives critiques restent sémantiques, accessibles et fiables.

L’**AI slop** désigne ici une production à faible soin par rapport à son but, souvent favorisée par la vitesse et le faible coût de génération, qui peut être générique, répétitive, trompeuse, incomplète ou coûteuse à vérifier et à maintenir. L’origine IA seule ne suffit pas à établir le slop. Une sortie n’est pas améliorée par une étiquette : elle doit rendre une décision, un artefact, une preuve, une limite ou une prochaine action plus clairs.

Une référence, une ancre, un profil, un choix de style ou une présélection de `DESIGN-ATLAS` calibre une possibilité et peut soutenir un jugement de direction. Aucun ne constitue une preuve indépendante. `DECISION-MODIFIED` et `WHEN-USEFUL` sont des hypothèses de sélection ; seule une observation dans le scope déclaré peut alimenter `DECISION-CHANGE` dans `ACTION`.

## CFT-01 — motivation, construction et forme située

[DURABLE] Une liste de motifs n’est pas un verdict. Évalue un élément par motivation et construction.

| Motivation | Construction | Décision |
|---|---|---|
| Oui | Oui | Légitime, sous réserve des gates d’usage, craft et cohérence. |
| Oui | Non | Justifié, mais à améliorer, simplifier ou expliquer. |
| Non | Oui | Forme construite ; expliciter son intention produit ou retirer. |
| Non | Non | Slop signalé. |

Cette matrice est une heuristique de jugement interne, pas une classification scientifique universelle du slop.

> **Source canonique.** Cette matrice appartient à `SAVOIR/CRAFT/CFT-01`. `ACTION/ANTI-SLOP` en contrôle la conséquence de gate sans la reproduire ; toute évolution de ses cas ou de son vocabulaire se fait ici.

Un principe générateur remplace un interdit sans devenir une recette. La structure peut suivre l’action critique, la profondeur porter une hiérarchie, un accent révéler un statut, une matière contribuer au produit et des panneaux partager une fonction distincte.

Un principe récité sans conséquence visible est du théâtre procédural.

**Idée par rapprochement.** Une forme peut naître du rapprochement de deux registres qui ne vont pas ensemble (deux époques, deux matières, deux usages) ou d’un contresens assumé entre le mot et l’image. Elle vaut si le rapprochement dit quelque chose du produit et se comprend en une seconde ; sinon, c’est un clin d’œil gratuit. **Signal de cumul** : plus de deux registres sur une même surface, ou deux registres sans lien avec le produit, donnent un collage, pas une idée ; garde le rapprochement qui porte la thèse et retire les autres.

### Inventaire du sujet et phrase d’idée

[MÉTHODE] Statut de route : `PILOT` (`maintenance/evolution.md`), avec le contrat réduit en fin de sous-section. Lorsque le sujet est un client, un lieu ou un objet réel et que l’idée est ouverte, dresse avant de choisir la forme l’**inventaire** de ce qui appartient à ce sujet et à aucun voisin : son nom et ce qu’il veut dire ; son adresse, sa rue, son quartier et ce que le lieu donne à voir (carreaux, enseignes, lumière, saisons) ; les nombres du brief (places, chambres, minutes, prix, année) ; la contrainte avec laquelle il vit (une seule fournée par mois, fermé l’hiver, sur rendez-vous) ; ses matières et ses couleurs ; ses rituels et ses horaires ; les objets imprimés de son monde (carte, ticket, étiquette, horaire, enseigne). Huit à douze éléments suffisent. Un élément que le brief ne donne pas reste inconnu : il n’est pas inventé (`CNT-01`, `TRUTH`).

**Phrase d’idée.** Avant le build, complète : « Sur cette page, [un élément de l’inventaire] devient [le dispositif que la composition appelle]. » Le dispositif est une scène, un geste ou un objet de preuve (`DIRECTION/FIRST-OBJECT`), non un effet. Pour le premier blanc, cherche du côté de ce que le sujet produit (montré tel quel), de sa forme (agrandie, recadrée, devenue cadre ou motif), de son nom (des lettres qui contiennent une photographie, se découpent ou s’empilent), de son lieu, de son rituel (une séquence que la page rejoue en défilant), de l’objet imprimé de son monde, ou de son opposé (la catégorie voisine qui possède le sentiment qui lui manque). Ces pistes s’essaient sur l’inventaire ; elles ne forment pas un menu de styles, et le `MODAL` nommé reste à écarter.

**Test du concurrent.** Remplace le sujet de la phrase par son voisin le plus proche (la boulangerie d’à côté, un autre atelier). Si la phrase tient encore, l’idée appartient à la catégorie : reprends l’inventaire. « Propre et moderne » n’est pas une idée. La phrase se juge avec le test de singularité (`COMP-SINGULARITE`), sans le remplacer.

**Une chose vivante.** Une seule, si elle sert la promesse : un geste ou un état qui change d’une visite à l’autre, fait avec le contenu réel du sujet (choisir un bois et voir la chaise ; régler un prêt et lire la mensualité). Elle se lit au pouce sur téléphone, garde un repli sans script et ne bloque pas la lecture. C’est le geste produit de `DIRECTION/DIRECTION-ATELIER`, codé.

**Même liste, autre usage.** Chaque lieu, matière ou objet imprimé de l’inventaire est aussi une requête possible pour chercher des images (`SAVOIR/SOURCE`).

| Champ du contrat réduit | Contenu |
|---|---|
| Décision | L’idée de la scène et le contenu du premier objet. |
| Contre-indication | Brief sans particularité fournie (ne rien inventer, marquer l’exemple, `CNT-01`) ; surface fonctionnelle où l’idée retarderait la tâche, ou risque critique, dont la protection prévaut (`DIRECTION/START`) ; identité de marque existante qui fixe déjà la direction. |
| Preuve attendue | Inventaire de huit à douze éléments, phrase d’idée et résultat du test du concurrent dans la trace ; capture du premier objet où l’élément du sujet est visible. Preuve de type perceptuel et expert. |
| Limite | Une idée tirée du sujet n’est ni une garantie de qualité ni une préférence mesurée ; l’inventaire ne vaut que pour les faits du brief. |
| Revue | Méthode du système, à éprouver : aucun gain n’est encore observé. À revoir avant 2027-04 ; passage en `ADOPTED` seulement avec un gain observé (`BIBLIOTHEQUE/EVOLUTION`, contrat de gain réel). |

### Dérivation bornée d’une forme située

[MÉTHODE] Les objets, matières et références du système sont des démonstrateurs de relation, jamais un catalogue à reproduire.

<!-- noyau:début COMP-FORME -->
> **Forme située = tâche + donnée ou objet métier + état et conséquence + densité de lecture + phénomène ou métaphore justifiable + preuve attendue.**

Le phénomène ou la métaphore est facultatif. Il peut rendre perceptible un seuil, une trace, une séquence, une origine, un volume ou une relation matérielle. Il n’est jamais ajouté pour éviter un rectangle ou paraître créatif.
<!-- noyau:fin COMP-FORME -->

| Test | Question |
|---|---|
| **Tâche** | Quel geste, choix ou compréhension la forme rend-elle plus directe ? |
| **Donnée** | Quel attribut réel — seuil, comparaison, trace, séquence, provenance ou volume — rend-elle perceptible ? |
| **État** | Comment loading, erreur, indisponibilité, succès et contenu extrême survivent-ils ? |
| **Preuve** | Quelle information, interaction, capture ou test montre qu’elle aide réellement ? |
| **Retrait** | Si matière, métaphore ou profondeur disparaît, qu’est-ce qui devient moins clair ou moins juste ? |

Une appréciation perceptuelle montre une impression ou un jugement situé. Elle ne devient une preuve d’utilisabilité que lorsqu’elle est reliée à une tâche, un contexte, un comportement ou une mesure adaptée.

Ne crée ni quota de variantes ni obligation de nouveauté. Une variation est recevable seulement si une différence de tâche, donnée, contexte, preuve ou registre la rend nécessaire. Toute forme dérivée reste soumise à `FND-01`, `SAVOIR/STATE`, accessibilité et gates ACTION.

## CFT-02 — registres et alternative située

[MÉTHODE] Une direction n’est pas un nom de style. C’est une position relative sur plusieurs axes.

| Axe | Pôles possibles | Question utile |
|---|---|---|
| Structure | Grille stricte ↔ tension sur grille ↔ hors grille | Où la lecture est-elle stabilisée puis décalée ? |
| Matière | Plat ↔ texturé ↔ photographique ↔ illustré/peint/spatial | Quelle matérialité transmet une information ou un registre ? |
| Voix, dont la voix typographique | Neutre ↔ expressif ↔ bruyant | Quelle intensité aide la tâche et le public, et survit-elle à la locale, au contenu long et au reflow ? |
| Temporalité | Intemporel ↔ contemporain ↔ nostalgique ↔ prospectif | Quelle relation au temps est justifiée ? |
| Densité | Respiration focalisée ↔ information concentrée | Quelle densité sert la décision ? |
| Texte / image | Texte souverain ↔ preuve souveraine ↔ relation équilibrée | Quel élément porte la crédibilité ? |
| Rythme | Régulier ↔ cadencé ↔ rompu | Comment le regard, la lecture ou la révélation progressent-ils ? |
| Contraste | Différence contenue, hiérarchie calme ↔ seuils nets, signal prioritaire | Le contraste clarifie-t-il sans écraser les états ou la lecture ? |
| Mouvement | Continuité minimale, feedback discret ↔ expressivité au service du repérage, de la causalité ou de la matière | Le mouvement améliore-t-il la compréhension ? |
| Formalité | Proximité, adresse directe ↔ institution, précision, distance maîtrisée | Le registre correspond-il au contexte de confiance et au public ? |
| Intensité émotionnelle | Retenue, calme ↔ énergie, chaleur, impact immédiat | L’intensité sert-elle la relation sans masquer la tâche ? |
| Convention ↔ écart | Repères familiers, prévisibilité ↔ surprise, écart structurel ou expressif défendu | L’écart produit-il une compréhension, une mémoire ou une valeur située ? |

Ces axes servent à produire une **alternative située**, jamais un menu de styles ni une obligation de marginalité. C’est la seule liste d’axes d’expression : les dials de `SAVOIR/STYLE` et les positions du pipeline de direction y renvoient. Les axes de tension (`BIBLIOTHEQUE/TENSION`) décrivent la structure, et l’axe de variation de la boucle (ci-dessous) choisit ce que l’on fait varier, produit compris (public, JTBD, promesse, geste).

> **Alternative située :** position différente parce qu’elle répond à une contrainte, un public, un JTBD ou une opportunité distincte.

<!-- noyau:début BOUCLE-AXE -->
Pour produire du beau varié sans produire du bruit, fais varier **un axe situé à la fois** : public, JTBD, promesse, geste, ou un axe d’expression de `SAVOIR/CRAFT/CFT-02` (structure, densité, matière, ton…). Pour chaque alternative, précise en trace complète (en trace légère, la première proposition nomme l’alternative écartée) :

- la décision qu’elle peut changer ;
- le public, le contexte, le risque ou le JTBD qui la justifie ;
- le niveau de matérialisation nécessaire ;
- la comparaison ou la preuve prévue ;
- la condition de retrait.
<!-- noyau:fin BOUCLE-AXE -->

Une alternative n’a pas à être matérialisée si elle ne peut modifier aucune décision. Lorsque le choix est ouvert et qu’une position différente peut réellement changer le résultat, développe-la au niveau nécessaire pour comparer : phrase, schéma, cible ou rendu.

**Comparer des choix plausibles.** Les positions comparées répondent à la demande et aux mêmes contraintes connues. Un contre-choix qui suppose un autre produit ou des capacités absentes éclaire une limite, mais ne départage pas deux solutions viables. Lorsque le doute porte sur une relation visible — accès au geste, densité, séquence ou place du résultat — matérialise cette relation au niveau utile : esquisse, fragment ou état construit. Conserve contenu et scope comparables ; note ce qui devient plus clair, ce qui perd en présence ou en confort et pourquoi tu retiens l’un des choix. Un changement de couleur seul ne teste pas la structure ; davantage de données n’améliore pas nécessairement la compréhension. Cette méthode précise la comparaison existante, sans quota de variantes ni second produit complet.

Les axes survivent aux tendances ; les étiquettes culturelles et les exemples doivent être révisés dans `SAVOIR/TOOLS`.

## CFT-03 — composition, densité et harmonie

[REQUIS PAR LE MODULE — surface identitaire, hiérarchie complexe ou revue perceptuelle] La composition rend l’action et le contenu lisibles avant la couleur. Choisis grille, échelle, densité et hiérarchie selon le contenu ; une valeur de départ n’est jamais une validation universelle.

Colonnes, tailles, espacements et breakpoints sont des diagnostics de cohérence. Adapte-les lorsque contenu, plateforme ou direction produisent une relation plus juste.

<!-- noyau:début COMP-CONTROLES -->
Les contrôles principaux sont : alignements nets, compensation optique, proximité qui révèle les groupes, priorités lisibles, et responsive pensé comme recomposition. Une grille desktop peut devenir liste ; un panneau peut devenir écran ; un bloc dense peut devenir séquence progressive. En mobile, l’idée survit à son arrangement : change d’axe, recadre sur le détail qui porte la preuve, garde ses repères et l’action à portée (`BIBLIOTHEQUE/SEQUENCE`).
<!-- noyau:fin COMP-CONTROLES -->

Une vue peut avoir une priorité dominante ou un groupe de priorités liées. Ne force pas une dominante unique dans une surface de comparaison ou de supervision lorsque plusieurs décisions doivent rester simultanément visibles.

<!-- noyau:début COMP-TEXTE-IMAGE -->
<!-- concept:TXI-01 -->
**Texte sur image.** Quand un texte est posé sur une photo, une illustration ou une texture, place-le dans la zone calme de l’image ou recadre pour en créer une ; sinon, ajoute un voile ou un dégradé localisé, ou sors le texte de l’image. Mesure le contraste aux points les plus défavorables, à chaque largeur où le recadrage change. Une image sans zone calme demande un autre recadrage ou un autre placement. Le mot peut aussi partager le plan de l’image (`SAVOIR/CRAFT/CFT-03`).
<!-- noyau:fin COMP-TEXTE-IMAGE -->

**Mot et image dans le même plan.** Le titre peut former un seul objet avec l’image : un sujet passe devant le mot, l’image remplit les lettres, ou le mot devient la ligne d’horizon de la scène. Choisis-le quand cette relation dit la thèse mieux que le mot et l’image séparés ; écarte-le pour un texte qu’il faut lire vite ou longtemps. Garde le mot reconnaissable en entier, mesure le contraste là où l’image traverse les lettres et recompose la relation sur mobile au lieu de la réduire.

**Échelle et champ calme.** Une seule opération poussée loin, par exemple un objet très petit face à un titre très grand, se lit dans un champ calme qui occupe la plus grande part de la surface. Ce champ n’est pas un vide à remplir : retire ce qui dispute le foyer avant d’ajouter.

**Franchissement et ancrage.** Un élément qui chevauche deux zones, comme le bord d’une image ou la limite entre deux sections, relie ce que les boîtes séparent ; de petits repères placés aux coins peuvent tenir un grand champ sans cadre ni carte. Ces gestes demandent un ordre de plans explicite, un contraste mesuré à l’endroit du chevauchement et une recomposition mobile qui ne coupe ni texte ni objet. Les repères de coin figurent parmi les marqueurs de vague datés (`SAVOIR/TOOLS/CONVERGENCE`) : ils restent permis lorsqu’ils tiennent un champ réel. Test de retrait : sans eux, le champ tient-il encore et la composition perd-elle un point d’ancrage ? Sinon ils sont décoratifs (`DÉCORATIF-SANS-CONSEQUENCE`).

### Cohérence et harmonie

La cohérence vérifie si les éléments suivent les mêmes règles. L’harmonie vérifie si les éléments entretiennent une relation juste. Une interface peut être cohérente et monotone ; elle peut contenir tension, asymétrie ou variation tout en restant harmonieuse si ces écarts sont tenus en relation.

Inspecte sur capture : typographie ↔ espace, image ou matière code-native ↔ hiérarchie, motion ↔ personnalité, densité ↔ usage, détail ↔ ambition. Une direction ambitieuse tenue par un craft faible se lit comme un potentiel non résolu ; une direction calme mais précisément exécutée peut être plus convaincante.

Une matière créée par code — trame d’impression, règle, masque, gradient, SVG, découpe ou composition procédurale — doit expliquer la relation qu’elle porte avant d’être préférée à un asset externe.

Une observation de clarté, d’harmonie ou d’unité est perceptuelle. Pour la nommer utilisabilité, ajoute une tâche, un contexte et une preuve d’usage lorsque le risque U est dominant.

## CFT-04 — design émotionnel

[MÉTHODE] Choisis l’émotion seulement lorsqu’elle aide la tâche ou la direction. Elle n’est pas une couche décorative ajoutée après la structure.

Sépare :

- **Viscéral :** impact immédiat ;
- **Comportemental :** ressenti pendant l’usage ;
- **Réflexif :** ce que le produit dit à l’utilisateur après l’interaction.

Ces trois niveaux viennent de Donald Norman (*Emotional Design*, 2004) ; ils aident à situer l’émotion visée, sans en mesurer aucune.

Les intentions ci-dessous sont des hypothèses de travail, non des effets garantis :

| Intention | Leviers à explorer | Contre-indication à vérifier |
|---|---|---|
| Calme | Rythme régulier, vide utile, contraste lisible, faible surcharge. | Contexte où densité et vitesse de décision priment. |
| Énergie | Accent net, rythme serré, échelle ou mouvement ciblé. | Contexte critique, surcharge sensorielle ou action essentielle masquée. |
| Confiance | Alignements, états, confirmations, données lisibles et prédictibilité. | Décision où le design semble plus certain que la preuve réelle. |
| Luxe | Proportion, matériau maîtrisé, palette restreinte, détail rare et retenu. | Public, prix, accessibilité ou tâche qui exigent un registre plus direct. |
| Sérieux | Hiérarchie stable, copie directe, saturation contrôlée et récupération claire. | Contexte où froideur, distance ou opacité empêchent la compréhension. |

Ces associations sont culturelles et contextuelles. Pour conserver une intention émotionnelle dans une direction, nomme le public, la tâche ou la relation produit visée, la contre-indication et la preuve perceptuelle ou comportementale attendue.

Aucune couleur, typographie, motion ou matière ne produit universellement une émotion. N’infère jamais qu’un effet doit être présent parce qu’une émotion a été nommée.

### CFT-04a — premier contact, preuve et rapport de personne

[À ADAPTER] Le premier contact peut mettre au premier plan soit un **geste ou une promesse**, soit un **objet de preuve concret**. Aucun des deux ne gagne par défaut. Privilégie l’objet lorsque l’utilisateur doit comprendre immédiatement un mécanisme actionnable et que cet objet représente honnêtement le produit sans réduire une relation à une démonstration. Privilégie le geste, la promesse ou un seuil plus indirect lorsque le contexte exige d’abord de la retenue, de la confiance, une présence éditoriale ou une distance juste envers un contenu intime.

La décision porte sur la relation, non sur une géométrie de hero. Trois cards égales, un split hero, un feuillet, une image ou un texte souverain peuvent tous être justes si leur place rend la tâche, la crédibilité et le registre plus cohérents. Une preuve placée au hero ne doit ni imiter un faux dashboard, ni utiliser une personne, une histoire ou une donnée sensible comme argument fonctionnel avant que le contexte l’autorise.

| Question de jugement | Signal en faveur d’un objet de preuve tôt | Signal en faveur d’un geste ou d’une promesse d’abord |
|---|---|---|
| Compréhension | Le mécanisme reste abstrait sans exemple visible ; le premier usage est court ou mobile. | Le mécanisme est déjà lisible ; la première décision est relationnelle ou émotionnelle. |
| Nature de l’objet | L’objet est actionnable, représentatif et peut être montré sans dépersonnaliser son contenu. | L’objet expose une personne, une trace intime ou une situation dont la mise en vitrine change le rapport de confiance. |
| Registre | La clarté immédiate est une forme d’honnêteté. | La lenteur, la pause ou la médiation font partie de la promesse. |
| Responsive | L’objet peut rester lisible et léger à petit écran. | L’objet peut apparaître tôt après le hero ou être recontextualisé sans être imposé au premier regard. |

Formule le compromis : ce qui gagne entre compréhension immédiate et juste distance, le coût assumé, et le signal qui ferait revenir sur la décision. `ACTION` reste propriétaire de la preuve ; une revue perceptuelle peut confirmer un effet situé, mais ne prouve ni tâche utilisateur ni vérité émotionnelle universelle.

## CFT-05 — couleur et contraste

<!-- noyau:début COMP-COULEUR -->
[REQUIS PAR LE MODULE — couleur, thème, statut ou surface identitaire] Conçois une palette par rôles : surfaces, textes, actions, états et frontières. La répartition entre neutres et couleurs est une décision de direction, pas un défaut : une structure neutre à accent, une identité multicolore structurelle ou un codage par zones sont recevables si les rôles, les états, le contraste calculé et un indice non chromatique pour toute information critique tiennent. Une couleur sémantique n’est pas une décoration.
<!-- noyau:fin COMP-COULEUR -->

<!-- noyau:début COMP-CONVERGENCE -->
**Question de convergence.** Cette palette et cette police de titre sont-elles celles que le modèle produirait sans brief (palette : neutres et un seul accent, sombre et doré, dégradé froid ; police : la grotesque large ou la serif de caractère prise par réflexe) ? Si oui, nomme ce qui, dans le produit, les justifie ; si rien ne les justifie, reconsidère-les. Pour la police de titre, compare au moins deux voix typographiques distinctes sur le vrai titre avant de choisir (méthode : `SAVOIR/TYPE-VOIX`). La question ne prescrit aucun écart : un choix convergent reste valide s’il tient face aux alternatives sur la planche.
<!-- noyau:fin COMP-CONVERGENCE -->

La palette est conditionnelle : elle est documentée lorsqu’elle peut changer la décision, le thème, le statut ou la direction. Si le système existant est conservé et qu’aucun choix de couleur ne change le run, note cette conservation et sa raison.

**Couleur située.** Une palette peut naître du sujet ou de l’asset principal : prélève les teintes dans l’image ou la matière du produit, puis attribue-leur des rôles. Une couleur partagée entre l’image et le texte relie les deux plans. Le fond aussi est une décision : un blanc chaud, froid ou neutre donne le ton avant le reste ; nomme sa température et sa raison. Deux ou trois couleurs tenues valent souvent mieux qu’une palette complète : la retenue est un levier, pas un manque.

OKLCH peut servir d’espace de conception perceptuel. HEX, HSL ou autre format restent des sorties techniques selon le projet. Le dark mode est recomposé — luminosité, saturation et élévation adaptées — et non inversé naïvement.

Le gamut élargi peut enrichir l’expression, mais ne porte jamais une information indispensable. Le contraste est calculé selon la politique d’ACTION ; aucune relation texte/fond ou état/fond ne reçoit un `PASS` à l’œil.

Une relation de couleur peut exprimer un registre ou une hiérarchie, mais ne doit pas porter seule une information critique. Les impressions de statut, chaleur, sérieux ou premium restent des hypothèses de perception à vérifier dans leur contexte.

Les claims sur chroma, statut perçu ou tendances de palette passent par `SAVOIR/TOOLS` et portent source, date, portée et limite dans la trace locale du run.

### Relations de couleur : construire et critiquer une palette

[MÉTHODE] Statut de route : `PILOT` (`maintenance/evolution.md`). Les relations de couleur servent à fixer un rôle et à nommer ce sur quoi une palette repose ; elles ne fournissent pas de recette.

**La valeur d’abord.** `[À ADAPTER]` Décide la luminosité de chaque rôle avant sa teinte : en OKLCH, fixe L, puis choisis la chroma C et la teinte H ; le contraste se lit alors dans l’écart de L. Pour des neutres, un écart de L d’environ 0,3 à 0,33 donne 3:1 et d’environ 0,37 à 0,43 donne 4,5:1 (sur un noir pur : environ 0,47 et 0,56 ; sur un fond sombre de thème, L entre 0,10 et 0,15 : environ 0,33 à 0,37 et 0,43 à 0,46). Une teinte saturée s’écarte de ces repères, surtout dans les bleus et les jaunes : le calcul d’`ACTION/GATE-A` tranche toujours. Un accent se règle sur ses trois usages, texte sur le fond, fond portant son texte, contour ou anneau de focus à 3:1 ; une seule valeur les tient rarement tous sur un fond clair comme sur un fond sombre, d’où souvent deux valeurs d’accent.

**Nommer la relation.** Une palette repose sur un écart de valeur, de teinte, de chaleur (chaud contre froid), de saturation ou de surface (une couleur étendue, une autre rare) : dis lequel. Test en niveaux de gris : si les rôles ne se distinguent plus, la palette ne tenait que par la teinte et risque de vibrer ou de se confondre.

**Fonds voisins.** Deux fonds de section voisins diffèrent par la luminosité, pas par la seule teinte ; l’écart se vérifie sur la capture réduite passée en niveaux de gris.

**Neutres.** Teinter les neutres (fond, surface, texte atténué) d’une chroma faible, d’environ 0,005 à 0,02, vers la teinte dominante les met dans une même famille. Le noir et le blanc purs restent possibles quand la direction les veut.

**Accent de marque et accent de foyer.** La couleur de marque n’est pas forcément celle qui désigne le foyer d’un écran : si la marque est partout, le foyer prend un autre écart (valeur, surface, matière) ou la marque se raréfie ailleurs. Un accent qui marque tout ne désigne plus rien.

**Fond sombre.** Remonte la luminosité de l’accent, baisse un peu sa chroma, et fais l’élévation par pas de luminosité des surfaces plutôt que par des lueurs.

**Roue chromatique.** Complémentaire, analogue ou triade décrivent une palette ; elles n’en justifient pas une. Une palette tirée de la roue sans raison propre au sujet relève du réflexe que la question ci-dessus fait nommer. Les effets de la couleur sur l’émotion ou la confiance restent des hypothèses de perception.

Contre-indications : palette ou marque fournie (la conserver et noter les écarts) ; palette née d’un asset (« Couleur située ») ; contraste de teinte seule assumé par la direction (le déclarer et vérifier le contraste calculé). Preuve : contraste calculé par rôle et par fond, capture en niveaux de gris, relevé de palette, vrai contenu. Limite : repères perceptuels approchés, établis sur des neutres ; WCAG reste le critère de contraste et APCA un complément (`ACTION/GATE-A`) ; aucun gain démontré. Références : OKLab (Ottosson, 2020), WCAG 2.2 (1.4.3 et 1.4.11), contrastes de couleur de Johannes Itten. À revoir avant 2027-04 ; passage en `ADOPTED` seulement avec un gain observé (`BIBLIOTHEQUE/EVOLUTION`).

### Variable visuelle et nature de la donnée

[MÉTHODE] Statut de route : `PILOT` (`maintenance/evolution.md`). Des chiffres justes ne suffisent pas : la variable visuelle doit dire la même chose que la donnée.

- **Polarité.** Une mauvaise nouvelle (dépense, risque, retard) ne se remplit pas dans la couleur de marque comme une réussite ; une baisse qui est une bonne nouvelle ne prend pas la couleur d’alerte. Nomme le sens de chaque mesure avant de choisir sa couleur.
- **Grandeur.** L’accent (hachure, couleur pleine, étiquette) va à la plus grande part, ou à la part que la thèse désigne, et cette raison se dit ; une petite part accentuée seule se lit comme la plus importante.
- **Ordre.** Des catégories sans ordre (services, pays, équipes) prennent une palette catégorielle de teintes distinctes à luminosité voisine ; une grandeur ordonnée (niveau, intensité, âge) prend une rampe séquentielle d’une teinte ; un écart autour d’une référence prend une rampe divergente. Une rampe rouge, orange, jaune sur des catégories sans ordre invente un ordre.

Contre-indications : code couleur imposé par le métier (feux de signalisation, normes), à conserver et à doubler d’un indice non chromatique. Preuve : la légende et le calcul de chaque encodage, recoupés avec `--assert` quand le rendu affiche une valeur.

## CFT-06 — écriture et contenu

[MÉTHODE] La rédaction (copywriting, titres, microcopie, nom des actions) est une décision de design : un titre qui demande quatre lignes ne se rattrape pas par la typographie, et une page de slogans ne se rattrape pas par la mise en page. Statut de route : `PILOT` (`maintenance/evolution.md`), avec le contrat réduit en fin de section. Charge cette route lorsque le contenu, le titre, l’ordre des sections ou le nom des actions sont une décision du run ; pour une retouche locale, relis seulement le texte touché.

**L’argument avant la page.** Réponds en une ligne chacune : qui lit et que sait-il déjà ; ce qu’est la chose, dite comme son auteur la dirait à un ami ; ce que la personne doit croire après un écran ; ce qui le lui fait croire (un objet, un chiffre, un nom, une démonstration) ; ce qu’elle fait ensuite. Écris ensuite la page comme des affirmations, chacune avec sa preuve. Une section sans affirmation est du remplissage ; l’ordre des affirmations devient l’ordre de la page, ce qui évite la trame modale (`BIBLIOTHEQUE/SELECT`, test de trame).

**Budget d’un titre.** `[À ADAPTER]` Un titre se lit en un regard. Avant de t’attacher à une phrase, mesure sur la police livrée combien de caractères tient une ligne à la largeur et au corps prévus, puis écris dans ce budget ; un titre d’accueil vise deux lignes au plus sur téléphone. Fixe la coupe sur le vrai texte et vérifie-la sur capture mobile (`TIT-01`, `SAVOIR/TYPE`). Réduire seulement le corps d’un titre trop long affaiblit la hiérarchie : coupe d’abord des mots, puis place le détail dans la ligne d’appui.

**Formes de titre.** Un titre fort dit une chose vraie que seul ce sujet peut dire : son nom, ce qu’il est, ce qu’il permet, une affirmation qu’un concurrent ne pourrait pas signer, un lieu ou un moment. Choisis la forme la plus simple qui reste vraie. Signaux d’enquête, dans la logique de `SAVOIR/TOOLS/CONVERGENCE` et jamais des interdits : la formule « la plateforme X pour équipes modernes », le tricolon (« Rapide. Simple. Sûr. »), la correction (« pas seulement un outil, un… »), « Bienvenue » ou « Découvrez » sans objet, la question que personne ne se posait, un nom suivi de deux-points que la navigation porte déjà.

**Ligne d’appui, corps et actions.** La ligne d’appui est une phrase concrète qui dit ce que c’est et pour qui ; elle reçoit le détail retiré du titre et ne le répète pas. Préfère le nom précis et le chiffre réel (« livré en une semaine », « 38 places ») au générique (« livraison rapide », « intime ») : une autre entreprise pourrait-elle imprimer la phrase telle quelle ? Si oui, précise-la ou coupe-la. Un bouton nomme l’action ou l’objet (« Réserver une table », « Voir les tarifs ») ; l’action principale garde le même nom sur la page, et un « Commencer » ou « En savoir plus » sans objet est un signal d’enquête.

**Preuve sans l’inventer.** Sans preuve fournie, montre la chose elle-même (objet de preuve, `DIRECTION/FIRST-OBJECT`), dis comment elle fonctionne, utilise les faits du brief. Un témoignage, un logo, une note ou un chiffre d’usage inventé n’est jamais un décor (`CNT-01`). Des détails d’exemple (noms de plats, tarifs, chambres) sont attendus pour juger la page à sa vraie densité ; ils sont marqués dans l’interface et listés dans la réponse (`CNT-01`, `EXD-01`).

**Formules du genre.** Verbes et adjectifs de la production générique (« libérez », « propulsez », « fluide », « sans effort », « tout-en-un »), étiquettes éditoriales de pure forme (« notes de terrain »), texte de mobilier (« Scroll », heure locale, coordonnées sans fonction), tiret cadratin en cadence (`SAVOIR/STYLE`), trois éléments parallèles partout. Ce sont des signaux d’enquête : un mot du genre reste valide s’il dit exactement ce que fait le produit, et cette liste vieillit avec les modèles.

**Micro-typographie en français.** Guillemets typographiques « ainsi », apostrophe courbe, points de suspension en un seul caractère, demi-cadratin pour les plages (9–17 h), espace insécable avant « : ; ! ? », à l’intérieur des guillemets, entre un nombre et son unité (« 12 € », « 38 places ») et avant le dernier mot court d’un titre s’il resterait seul ; `font-variant-numeric: tabular-nums` pour les colonnes de chiffres, `text-wrap: balance` sur les titres et `text-wrap: pretty` sur les paragraphes. Pour une autre langue, suis les usages de cette langue.

| Champ du contrat réduit | Contenu |
|---|---|
| Décision | Longueur et forme du titre, ordre des sections, nom des actions, texte d’appui. |
| Contre-indication | Texte fourni ou validé par un tiers (mentions légales, santé, finance) ; voix de marque existante ; langue dont le calcul de longueur ne tient pas (écritures sans espaces, par exemple) ; sujet intime où la concision ferait perdre la juste distance. |
| Preuve attendue | Capture du premier écran à 390 et 1440 px (lignes du titre, coupe) ; relecture « une autre entreprise pourrait-elle imprimer cette phrase ? » sur les titres et la ligne d’appui. Preuve de type perceptuel et expert. |
| Limite | Juge la forme et la spécificité du texte, non sa justesse commerciale, sa conformité légale ni son effet sur la conversion ou la compréhension, qui demandent une tâche et un lecteur (`ACTION/GATE-B`). |
| Revue | Méthode du système ; formules du genre alignées sur `SAVOIR/TOOLS/CONVERGENCE`. À revoir avant 2027-04 ; passage en `ADOPTED` seulement avec un gain observé (`BIBLIOTHEQUE/EVOLUTION`, contrat de gain réel). |

---
