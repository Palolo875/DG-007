# Produit — plancher

Ce qui doit tenir sur tout rendu réel : contrôles applicables, contraste, inspection.

<!-- origine:ACTION.md -->
## ACTION/GATE-A — plancher objectivable

Gate A vérifie les fautes mesurables ou observables. Exécute uniquement les contrôles applicables au composant, à l’appareil et au contexte.

### Contrat de portée

Lorsque l’accessibilité ou la conformité est dans le périmètre, déclare avant le contrôle :

```text
MEDIUM — médium réel de la surface et périmètre effectivement observé ; déclare le support applicable. Pour le Web, le médium peut rester implicite seulement si le périmètre est sans ambiguïté ; pour tout autre médium, il est explicite.
SCOPE — vues, composants, états ou chemins couverts.
CONFORMANCE-TARGET — référentiel et niveau visé, adapté au médium déclaré.
SAMPLE — échantillon représentatif ou raison de l’exhaustivité.
METHOD — AUTOMATED, MANUAL, EXPERT, USER ou combinaison, adaptée au médium.
BUDGET-UNIT — unité de budget pertinente : load/INP, lancement/frame rate/mémoire, confort motion, encre/contraste ou équivalent déclaré.
COVERAGE-LIMIT — éléments hors couverture, incluant toute preuve web indisponible.
NEXT-PROOF — preuve suivante attendue.
```

Pour le web, utilise WCAG 2.2 comme base normative actuelle lorsque le projet n’impose pas un autre référentiel applicable. Pour un autre médium, déclare le référentiel applicable dans `CONFORMANCE-TARGET` : guideline de plateforme, référentiel légal, standard émergent ou critère de lisibilité pertinent. WCAG 3.0 reste une `[VEILLE]` tant que sa recommandation et son modèle de conformance ne sont pas stabilisés. Les critères de conformité ne valident ni la direction visuelle, ni l’utilisabilité globale, ni l’adéquation du positionnement.

### Familles de méthodes

| Méthode | Couvre prioritairement | Limite |
|---|---|---|
| `AUTOMATED` | Défauts détectables par outil et règles codées. | Ne couvre pas tous les problèmes d’usage, de contexte ou d’interprétation. |
| `MANUAL` | Structure, clavier, focus, états et situations que l’outil ne comprend pas. | Dépend de la méthode et de l’expertise de l’inspecteur. |
| `EXPERT` | Interprétation, risque, cohérence et problèmes contextuels. | Ne remplace pas une tâche utilisateur. |
| `USER` | Expérience réelle et difficultés de personnes concernées. | Échantillon, tâche et contexte doivent être déclarés. |

Un `PASS` décrit la preuve obtenue par la méthode, le médium et le périmètre déclarés. Il ne devient pas un `PASS` global par glissement. Ce qui n’existe pas dans le médium est `N/A-JUSTIFIED` ; ce qui le remplace est testé. Une preuve web indisponible n’est jamais simulée : elle devient `NOT-VERIFIED` avec `NEXT-PROOF`, ou est traduite en équivalent du médium.

Pour un verdict global `ACCEPTED` ou `ACCEPTED-WITH-RESERVATION`, la `RUN_CARD` doit rattacher la preuve observée à une provenance minimale : `artifact_locator`, `artifact_version`, `method` et `observed_at`. Cette provenance établit où, sur quelle version, par quelle méthode et à quel moment l’observation a été obtenue ; elle ne prouve pas à elle seule la véracité de l’artefact, la qualité du design ou la réussite d’usage. Si la provenance ne peut pas être établie, le verdict reste non accepté.

### Adéquation des preuves

| Question | Preuve adaptée | Limite |
|---|---|---|
| Ratio, taille, token, régression mesurable | Script ou test exécuté. | Ne prouve pas l’intention visuelle. |
| Hiérarchie, composition, densité, matière | Capture, détail et comparaison. | Ne crée pas seul un juge indépendant. |
| Préférence, clarté, fidélité au contexte | Regard humain, expert ou utilisateur selon le risque. | N’est pas une mesure technique par défaut. |
| Utilisabilité réelle | Utilisateur représentatif, tâche représentative, observation et résultat. | Ne se déduit pas d’une capture ou d’un avis expert seul. |
| Hypothèse sans runtime ou observateur | Déclaration structurée. | Reste `NOT-VERIFIED` si la preuve est requise. |

### Contrôles applicables

| Contrôle | `PASS` si… | Retour ou réserve si… |
|---|---|---|
| Contraste | Les cas représentatifs sont calculés selon la politique WCAG 2.2 AA du projet lorsqu’elle s’applique. | Estimé à l’œil, sous seuil ou non calculé lorsque requis. |
| Sémantique et nom accessible | Interactifs et contenus essentiels ont une sémantique et un nom adaptés. | Rôle, nom, structure ou alternative absents. |
| Focus clavier | Interactifs atteignables avec focus visible et testé. | Navigation ou focus indisponible. |
| États pertinents | Interaction, sélection, contenu et erreurs sont vérifiés ; événement, conséquence et action suivante sont explicites. | État critique absent, implicite ou dépendant de la couleur seule. |
| Contenu honnête | Pas de faux contenu, lorem ou promesse non étayée présenté comme réel. | Contenu de remplissage trompeur. |
| Stabilité média | Dimensions, fallback et chargement évitent les déplacements pertinents. | Instabilité visible ou espace non réservé. |
| Motion réduite | L’alternative sans mouvement est implémentée et vérifiée préférence activée, dans le runtime déclaré. Sans motion : `N/A-JUSTIFIED`. | Motion imposée ou alternative absente ; alternative seulement dessinée ou annoncée : `NOT-VERIFIED`. |
| Cibles d’interaction | Taille adaptée au device et au contexte selon la politique du projet. | Cible trop petite sans alternative ni justification. |
| Information non chromatique | L’information essentielle ne dépend pas de la couleur seule. | Statut ou action incompréhensible sans couleur. |
| Focus non masqué | Le composant recevant le focus reste visible selon le contexte applicable. | Focus masqué par contenu ou interface auteur. |
| Mouvement de glisser | Une alternative existe lorsque l’action de glisser n’est pas essentielle. | Action impossible autrement sans justification. |
| Aide cohérente | L’aide répétée apparaît de façon cohérente lorsque le produit en fournit. | Aide déplacée ou incohérente dans le périmètre. |
| Saisie redondante | L’utilisateur ne doit pas ressaisir inutilement une information déjà fournie dans le même processus. | Répétition évitable sans raison. |
| Authentification accessible | Le processus n’impose pas une charge cognitive ou sensorielle évitable. | Mémoire, perception ou interaction imposée sans alternative. |

<!-- concept:GTA-01 -->
**Profils de surface.** Commence par les contrôles d’office du profil ; un contrôle hors profil devient applicable dès que la surface porte l’élément concerné (formulaire, glisser, motion, connexion). Ce que le médium ne porte pas est `N/A-JUSTIFIED`.

| Profil | Contrôles d’office | Selon le contenu |
|---|---|---|
| Page vitrine, éditoriale ou portfolio | Contraste, sémantique et nom accessible, focus clavier, information non chromatique, cibles d’interaction, contenu honnête, stabilité média. | États (formulaire, commande), motion réduite, mouvement de glisser, focus non masqué. |
| Application, formulaire ou flow | Tous les contrôles d’interface : contraste, sémantique, focus clavier et non masqué, états, cibles, information non chromatique, saisie redondante, aide cohérente, contenu honnête. | Authentification accessible (connexion), motion réduite, mouvement de glisser, stabilité média. |
| Scène, motion ou 3D | Motion réduite, contraste, information non chromatique, stabilité média, contenu honnête. | Focus clavier et cibles si la scène est interactive. |
| Hors Web (imprimé, affiche, écran fixe) | Contraste ou lisibilité d’encre, information non chromatique, contenu honnête. | Référentiel du médium, déclaré dans `CONFORMANCE-TARGET`. |

**Recette automatisée.** Les scripts et recettes sont des ressources versionnées. Une recette exécutée ne suffit pas à valider un résultat visuel, produit ou utilisateur : elle attrape des fautes mécaniques et ne juge ni la direction, ni le goût, ni l’usage. Pour un rendu HTML, la recette `AUTOMATED` du paquet est `scripts/check_render.py` ; son périmètre, ses statuts, ses options et ses limites sont dans `ACTION/RECETTE-RENDU`, à lire avant de l’exécuter ou d’en citer un résultat. Un `PASS` de la recette ne vaut que pour le contrôle qu’elle mesure ; ces limites n’allègent pas les contrôles applicables du gate.

---

<!-- origine:ACTION.md -->
## ACTION/RECETTE-RENDU — recette de rendu `check_render.py`

Mode d’emploi de la recette `AUTOMATED` citée par `ACTION/GATE-A`. Elle se lit quand la recette est exécutée ou qu’un de ses résultats est cité ; elle ne fait pas partie du tronc. Les statuts qu’elle rend (`RETURN`, réserve, `NOT-VERIFIED`) s’appliquent aux contrôles qu’elle mesure, jamais à la direction, au goût ou à l’usage.

La recette `AUTOMATED` du paquet pour un rendu HTML est `scripts/check_render.py` (optionnelle, navigateur requis). Elle produit la provenance minimale ci-dessus. Sous chaque contrôle en réserve ou en `RETURN`, elle propose la route qui traite le défaut (« → savoir : … », aussi dans `--json` et le journal) ; elle ne la lit pas et ne change aucun statut. Sans navigateur, elle rend `NOT-VERIFIED`. Ses comportements sont testés par `scripts/test_check_render.py` ; `--require-browser` exige les tests de pages et fait échouer leur contrôle si le navigateur est indisponible.

**Ce qu’elle contrôle.**
- Le débordement, de la page et des feuilles ouvertes.
- Les erreurs de script.
- Le contraste sur fond uni opaque.
- Les candidats de nom tirés du DOM.
- La taille des cibles, exception d’espacement comprise ; une bande de données continue (au moins huit petites cibles serrées sous un même parent : calendrier, frise, carte de chaleur) est rendue en une seule ligne, avec l’exception « équivalent » ou « essentiel » à établir.
- Les arrêts clavier observés et leur changement de style au focus.
- La structure du document.
- Le chargement des images visibles.
- Le contraste de l’indicateur de focus, dans les cas lisibles.
- Le mouvement réduit, observé sous la préférence activée : la recette enregistre dès le début du chargement les animations et transitions démarrées, même terminées à la mesure.
- Le chevauchement et la troncature de texte (contrôle « Chevauchement et troncature de texte »), sur les rectangles de lignes ramenés à l’interligne et hors calques fixes ou collants.

Avant de mesurer, la recette fait défiler toute la page : le contenu révélé au défilement est ainsi mesuré et capturé. La mesure se prend à l’état laissé par les clics, avant les captures. Par défaut, seules la page et son origine se chargent : une police ou une image hébergée ailleurs est bloquée et la mesure utilise les polices de repli ; `--allow-external` les charge, à déclarer dans la méthode de la preuve.

**Ce que rend chaque cas.**
- Images : une image visible sans source, ou dont le chargement s’est terminé sans pixel (fichier introuvable ou illisible), est un `RETURN` : aucune intention de design ne l’explique. Une image visible encore en chargement à la mesure n’est pas vérifiée : réserve. Si elle vient d’une autre origine que la page et que la mesure a bloqué les requêtes externes, elle n’est pas vérifiée : réserve, et `--allow-external` la charge ; avec `--allow-external`, une image externe qui échoue est un `RETURN`.
- Mouvement réduit : une animation infinie est un `RETURN`, une animation finie une réserve qui nomme ses cibles et dit si elle déplace quelque chose ; une animation finie d’au plus 10 ms (réinitialisation habituelle du mouvement réduit) n’est pas comptée.
- Contraste : un texte posé sur un fond en image ou en dégradé est mesuré sur une capture où le texte est rendu transparent : le rapport retenu est le pire des 5e et 95e centiles du fond sous chaque ligne (quartiles pour un texte tourné, dont la boîte droite déborde sur le fond voisin), dans le contrôle « Contraste du texte sur fond en image ou en dégradé (capture) » ; un texte rogné à plus de moitié par son conteneur n’y est pas évalué. Un échec mesuré sur le fond déclaré par les ancêtres est repris sur la même capture : si le fond réellement peint le dément (texte positionné hors de la boîte qui le porte), il sort des échecs avec une note. Une opacité de groupe, une couleur non convertible, un texte rempli par son fond (`background-clip: text`), un texte SVG ou une capture impossible deviennent une réserve, jamais `PASS`. Le ratio d’un texte qui passe n’est pas rapporté : une trace qui cite un ratio le mesure à part.
- Indicateur de focus : sous 3:1 (WCAG 1.4.11), le contrôle « Contraste de l’indicateur de focus » rend une réserve qui nomme l’arrêt, les couleurs et le ratio, et signale un autre changement de style (fond, couleur, bordure) qui l’accompagne sans être mesuré.
- Noms : la présence d’un candidat DOM ne prouve pas le nom accessible calculé et conserve une réserve ; un cas de nom non couvert conserve également une réserve. Un SVG réduit à des formes, sans titre ni nom ARIA, ne nomme rien : un contrôle qui n’a pas d’autre nom est un `RETURN` ; un SVG qui contient du texte, une référence (`use`, `image`, `foreignObject`) ou un nom ARIA interne reste un cas non couvert.
- Clavier : le parcours indique le périmètre actif, les candidats non atteints et la raison d’arrêt ; la borne atteinte ou une couverture inconnue conserve une réserve.
- Texte : les textes qui se recouvrent sont un `RETURN` ; ceux qui sont tronqués, sur une ligne ou coupés à quelques lignes (`line-clamp`), ou dont une ligne est coupée en partie par un ancêtre qui rogne (un libellé positionné dans une barre ; une ligne entièrement hors du conteneur, comme la diapositive suivante d’un carrousel, est ignorée), et le texte décoratif superposé à un autre, masqué aux lecteurs d’écran, presque transparent ou en simple contour, comme un filigrane, sont une réserve, à juger. Le contenu d’un `<details>` fermé et le texte réservé aux lecteurs d’écran (boîte d’un pixel, découpe nulle) ne sont ni chevauchants ni tronqués.

**Options.**
- `--widths` : largeurs, par défaut 390, 768 et 1440 px.
- `--proof SÉLECTEUR` : objet de preuve (voir plus bas).
- `--click SÉLECTEUR` : état à observer, répétable ; `--wait-after-ms MS` attend après les clics pour atteindre l’état qui compte.
- `--assert EXPRESSION` (répétable) : recoupe un texte dérivé avec ses valeurs et échoue si l’expression JavaScript n’est pas vraie. Exemple, un total affiché qui doit être la somme des lignes : `--assert "[...document.querySelectorAll('.ligne .prix')].reduce((s, e) => s + parseFloat(e.textContent.replace(',', '.')), 0).toFixed(2) === document.querySelector('.total').textContent.replace(',', '.').replace(/[^0-9.]/g, '')"`.
- `--in-frame SÉLECTEUR@CADRE` (répétable) : échoue si un élément de l’état clé a son centre hors du cadre (la fenêtre si `@CADRE` est omis).
- `--captures DOSSIER` : une capture pleine page par largeur, à l’état observé. Chaque version va dans son propre dossier : la recette n’écrase jamais une capture existante, ce qui garde la paire avant/après de B1b. Vues de détail et de masses restent à produire autrement.
- `--json CHEMIN` : résultats et provenance.
- `--baseline JSON` : pour une non-régression, enregistrez la mesure de la version d’avant avec `--json`, puis mesurez la nouvelle avec `--baseline` suivi de ce fichier, aux mêmes largeurs, état et réglages. Chaque contrôle est dit inchangé, amélioré, dégradé, introduit ou disparu, sans changer les statuts ; un défaut préexistant reste un défaut. Les réglages de preuve d’état n’entrent dans la comparaison que s’ils sont employés.
- `--allow-external` : charge les polices et images hébergées ailleurs (voir plus haut).

**Limites.**
- Les animations pilotées par script sans API d’animation du navigateur ne sont pas observées.
- Le contraste non textuel des bordures et des icônes n’est pas mesuré. Celui de l’indicateur de focus l’est seulement pour un contour ou un anneau d’ombre net (sans flou ni décalage) sur fond uni ; un changement de fond, de couleur ou de bordure, une ombre floue ou intérieure ou un fond en image ne sont pas mesurés, et le contour du navigateur, à deux tons, n’est pas signalé.
- Le candidat DOM exclut le contenu masqué ordinaire et peut utiliser les labels explicitement référencés.
- Un changement de style ne prouve ni visibilité, ni contraste, ni absence de masquage du focus.
- Ces limites n’allègent pas les contrôles applicables du gate : approfondis la preuve si nécessaire.

**Résoudre un contraste non évalué.** Pour le texte SVG, relève dans l’état et aux largeurs concernés la couleur peinte (`fill` ou `stroke`), les opacités et le fond réellement placé derrière les glyphes ; la propriété CSS `color` et le fond d’un ancêtre ne suffisent pas. Calcule le rapport sur les couleurs effectives selon les seuils de cette gate et `SAVOIR/CRAFT/CFT-05`. Sur des formes SVG superposées, identifie les positions les plus défavorables dans le rendu ; une capture regardée à l’œil ne mesure pas le rapport. Pour un fond en image ou en dégradé, la recette mesure elle-même sur capture ; `python3 scripts/regard.py` mesure aussi le texte SVG, en signal. Relie le relevé, le calcul, la méthode, l’artefact, l’état, le viewport et la limite dans la preuve existante. L’agent peut produire cette mesure avec un outil adapté ; si les couleurs effectives ne sont pas établies, conserve la réserve et nomme la mesure suivante. Une preuve complémentaire résout la réserve dans le run sans modifier rétroactivement le résultat de la recette.

**Couverture de la recette.** Le contraste enregistre candidats, évaluations, exclusions et textes détectés hors couverture dans `contrast_coverage`. Valeur courante, placeholder affiché, texte natif et contenu pseudo détectés mais non calculés conservent une réserve ; une absence de mesure ne devient pas une preuve de conformité. Vérifie séparément leur couleur réellement peinte, leur fond et leur état, notamment `::placeholder`, sans publier les valeurs sensibles. Un défaut calculé ailleurs conserve `RETURN`. Ces données appartiennent à la recette, pas au schéma RUN_CARD.

Avec `--proof`, `proof_observations` sépare présence, surface, opacité CSS cumulée et intersection du rectangle avec les deux axes du viewport initial. Introuvable, masqué ou transparent : `RETURN`. Une intersection insuffisante — moins de `min(40 % de la dimension, 320 px)` sur un axe — ou une découpe non évaluée conserve une réserve : la recomposition reste à juger. Un `PASS` porte uniquement sur ces observations CSS et géométriques ; pixels, occlusion et pertinence de l’objet restent à inspecter. Une ancienne mesure sans couverture ne suffit pas.

---

<!-- origine:ACTION.md -->
## ACTION/POLICIES — contraste et inspection

### Politique de contraste

Calcule le contraste selon WCAG 2.2 et le référentiel applicable lorsque ce référentiel s’applique au projet. Ne valide jamais le contraste à l’œil.

APCA peut être documenté comme mesure complémentaire de lisibilité ou d’exploration lorsque son contexte, sa version et sa limite sont connus. APCA ne remplace pas un critère WCAG applicable et ne crée pas seul un verdict réglementaire.

Les seuils, outils, projections réglementaires et sources évolutives sont qualifiés dans `SAVOIR/TOOLS` et la trace locale du run. ACTION porte la politique de livraison ; un fait ne mérite une décision de gouvernance que lorsqu’il devient une règle partagée.

### Inspection et ressources techniques

Une inspection externe peut compléter le jugement sur l’accessibilité, la régression visuelle, les tokens et les motifs. Choisis l’outil selon l’environnement, sa documentation, sa version et son owner. Une commande, un package ou une intégration cités dans une ressource ne sont jamais exécutés aveuglément. Trois cas :

- **script local sans dépendance nouvelle** : la trace conserve la méthode, la commande ou la version, et le résultat ;
- **outil déjà autorisé** : la trace cite la référence de l’autorisation ;
- **nouvelle dépendance** : approbation requise, et la ressource indique les sept champs ci-dessous.

Toute ressource technique maintenue indique :

- stack et version ;
- date de vérification ;
- capacité résolue ;
- fallback ;
- limites ;
- owner ;
- prochaine revue.

L’automatisation détecte une partie des défauts mesurables. Elle ne remplace ni l’inspection de rendu, ni la capture, ni le jugement contextuel, ni l’observation utilisateur lorsque le risque la requiert.

Pour les composants critiques, maintiens une baseline d’états pertinents : variant, thème, viewport, données longues, loading, empty, error et focus lorsque nécessaires. Une capture versionnée et une revue explicite peuvent fournir une preuve proportionnée lorsqu’un pipeline de stories ou de tests visuels n’existe pas.

---
