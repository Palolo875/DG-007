# Produit — finition

Le craft jugé sur le rendu réel, et ce qui sépare un produit fini d’un rendu générique.

<!-- origine:ACTION.md -->
## ACTION/GATE-C — craft sur rendu réel

Gate C évalue la présence de décisions perceptibles et la qualité de leur résolution. Il est obligatoire en `DIRECTION`, ciblé au risque craft en `STANDARD`, limité à la zone touchée en `ITER` et `N/A-JUSTIFIED` en `LITE` lorsque le craft n’est pas concerné.

Une capture réelle est nécessaire pour un jugement C. Sans runtime ou capture, le craft reste `NOT-VERIFIED`.

Gate C décide sur le rendu à partir des observations de la revue créative et, si elle est déclenchée, de la paire B1b (`ACTION/GATE-B — B1b`) pour la décision mise à l’épreuve ; il ne refait pas une seconde revue, ni une seconde procédure de comparaison.

Chaque verdict C précise le périmètre : viewport, état, scène, contenu et élément observé. Pour une finesse insuffisante, utilise les gestes conditionnels de `SAVOIR/STATE`, puis compare les versions au même scope ; une cohérence déclarée ou un geste seulement prévu ne prouve pas la résolution. Lorsque la structure est ouverte, applique sur la même capture les tests perceptifs de `BIBLIOTHEQUE/GATE` (non-généricité, silhouette, grille) ; ils nourrissent C3 et C4 sans verdict propre.

| Critère | Présent si… | Retour ou réserve si… | Geste si absent (route à charger) |
|---|---|---|---|
| **C1 — Stratégie de surface** | Photo, donnée, lumière, illustration, surface, trame d’impression, profondeur ou planéité choisie découle du produit. | Traitement par défaut sans relation observable ; sur une surface `DIRECTION`, aplat gardé sans essai de matière. | Choisis la surface d’après ce que le produit montre (carte des moyens : `SAVOIR/TOOLS/MOYENS`) ; un traitement justifié par la thèse pour les assets moyens ; retire le traitement sans rôle. |
| **C2 — Typographie choisie** | Famille, système existant ou alternative est justifié ; rôles, échelle et fallback servent le contexte. | Choix par défaut non interrogé ou non calibré. | Choisis la famille pour la voix et la donnée à porter (`SAVOIR/TYPE`) ; fixe deux ou trois rôles et une échelle contrastée ; vérifie le fallback au rendu. |
| **C3 — Composition intentionnelle** | Structure de lecture identifiable sert l’action et le rythme. | Empilement uniforme sans décision spatiale. | Recompose dans l’ordre intention → foyer → masse → rythme (`SAVOIR/FRAME/COMPOSITION`) ; nomme le foyer et l’ordre de lecture ; romps la trame modale si elle ne sert pas la tâche (test de trame : `BIBLIOTHEQUE/SELECT`). |
| **C4 — Densité optique** | Espace, masses et regroupements suivent la priorité et l’usage. | Espacement uniforme qui masque les relations. | Regroupe par proximité ; redistribue masses et vides selon la priorité (`SAVOIR/STATE` : masse visuelle, gestion du vide) ; contrôle la silhouette à faible détail. |
| **C5 — Stratégie de profondeur applicable** | Profondeur, lumière ou planéité est cohérente avec le registre et lisible au rendu. | Ombres, bordures ou flous par défaut sans logique. `N/A-JUSTIFIED` si la planéité est intentionnelle et suffisante. | Tiens une seule logique, lumière, élévation ou planéité, sur toute la surface ; retire ombres, bordures et flous sans rôle (`SAVOIR/STATE` : surface). |
| **C6 — Résolution située** | Une difficulté réelle est résolue par microcopie, état, donnée, interaction, asset ou transition pertinente. | Assemblage de composants sans adaptation au cas. | Trouve la difficulté réelle du cas (attente, erreur, donnée, choix) et résous-la par microcopie, état, donnée ou interaction (`SAVOIR/CRAFT/CFT-01` : forme située) ; une erreur se résout jusqu’à la reprise (`SAVOIR/STATE`). |

Chaque verdict C cite l’élément concret observé. Un critère bloquant absent, ou plusieurs signaux faibles convergeant sur le même risque, déclenchent un retour. La correction revient à la direction, à la spec ou au build ; elle n’ajoute pas un effet décoratif terminal.

En trace légère, Gate C sert de contrôle de craft sur la capture, dans la boucle d’édition : un critère absent déclenche son geste, puis une nouvelle capture ; aucun verdict n’est écrit.

---

<!-- origine:ACTION.md -->
## ACTION/ANTI-SLOP — conséquence de gate

La matrice canonique motivation/construction appartient à `SAVOIR/CRAFT/CFT-01`. ACTION ne la reproduit pas : il vérifie sa conséquence sur l’artefact. Lorsqu’un motif manque de motivation, de construction ou des deux, la trace nomme l’élément observé, la relation produit/lecture manquante et la sortie : correction, retrait, réserve ou `RETURN`.

Une couleur de marque, une contrainte de contenu ou une construction technique soignée n’immunisent pas un choix contre les autres gates. Les watchlists et tendances restent des aides de jugement dans `SAVOIR/CRAFT` ou la veille ; elles ne deviennent pas des interdits universels.

---

<!-- origine:ACTION.md -->
## ACTION/ATELIER-EDITION — opération observable

<!-- noyau:début BOUCLE-ATELIER -->
**Atelier sur capture (`ACTION/ATELIER-EDITION`).** Sur une surface `DIRECTION`, après la première capture, fais au moins un tour d’atelier, même en trace légère : lecture légère, édition d’une décision principale, nouvelle capture comparée ; la paire n’est pas exigée en trace. Dans le scope de B1b (surface `DIRECTION` qui accepte avec l’axe V (caractère visuel, `ACTION/STATUS`) positif, en trace complète : `ACTION/GATE-B/B1b`), cet atelier est requis, sauf deux motifs `N/A-JUSTIFIED` : aucune décision principale éditable, ou une paire équivalente encore valide qui couvre la même décision.

Après la première capture, avant de relire la direction déclarée, fais une lecture légère sur l’image sans le texte (`regard.py` la produit) : nomme en une phrase la catégorie, la marque et le niveau de preuve que la surface semble raconter, puis l’idée qui s’y lit en une seconde. Compare ensuite ce nom à la direction déclarée ; s’ils ne concordent pas, c’est l’idée qui se reprend, pas le nom. Si l’idée a besoin d’une consigne ou d’une légende pour se comprendre, c’est un diagramme : la décision à éprouver est celle-là. Nomme ensuite la décision principale à mettre à l’épreuve et éprouve-la dans les deux sens : une variante qui la **retire, la réduit ou la transforme**, une variante qui l’**intensifie** (la même décision poussée plus loin : échelle, contraste, position, recouvrement, fond perdu, matière). Avant de les construire, écris pour chacune la règle qui la ferait gagner : ce qu’elle doit montrer mieux que l’original, et sur quelle capture. Construis-les au même niveau de finition que l’original ; une variante faite pour perdre ne prouve rien. Compare les captures et les mesures des deux variantes avec l’original, selon ces règles. Une décision peut coordonner plusieurs diffs, mais l’unité de compte n’est pas le nombre de changements. N’ajoute rien pour compenser : intensifier pousse la décision éprouvée, sans en ajouter une autre.

Conserve et compare la capture suivante. La trace nomme le changement, sa direction, son effet et la décision qu’il confirme, modifie ou abandonne. Garder l’original lorsqu’il résout mieux la décision est un résultat valide : la variante a alors confirmé une décision par comparaison plutôt que par déclaration. L’issue s’écrit dans la trace, original confirmé ou décision changée ; si les ateliers d’un même projet confirment toujours l’original, la manière de construire les variantes se revoit.

**Garder se décide à l’atelier.** Un signal ou un marqueur relevé au premier écran (`parcours.py`, `regard.py`) qui n’est pas corrigé se garde par comparaison, pas par une phrase : construis la variante qui le retire et compare-la à la vue. Les signaux gardés passent ensemble dans un seul atelier ; dès deux marqueurs gardés, palette et typographie s’éprouvent comme un ensemble. Pour un marqueur typographique, la variante essaie une autre voix qui a du caractère, pas une voix neutre facile à battre.

**Regard séparé.** Si l’environnement permet un second agent, fais critiquer la version gardée sur images seules par un agent qui ne lit ni la direction ni la trace : `python3 scripts/parcours.py critique page.html --brief "…"` prépare les images et la consigne (idée lue sans texte, point le plus faible, trois changements vérifiables sur capture). Juge la critique sur capture : applique ce qu’elle confirme, écarte avec sa raison ce qu’elle contredit. Sans second agent, les questions de critique de la réponse en tiennent lieu.

**Passe de finition.** Sur une surface `DIRECTION`, avant de livrer la version gardée, fais une passe sur le premier écran et l’objet de preuve, même sans symptôme : parcours les gestes de finition de `SAVOIR/STATE` (alignement optique, chiffres, filets et rayons d’une même logique, icônes d’une seule famille, états, recadrage, texte final, parties ordinaires : navigation, bouton, pied, une propriété de la direction, pas un motif) et corrige ce que la capture agrandie montre. Une passe, pas une boucle ; elle n’ajoute aucune décision.
<!-- noyau:fin BOUCLE-ATELIER -->
