# Maintenance — faire évoluer le système

Pour qui fait évoluer le système : d’où vient chaque distribution, comment la préparer et la valider. Ce module se charge quand une règle ou une route doit évoluer, être promue ou dépréciée ; il ne fait pas partie du chargement ordinaire d’une proposition.

| Fichier | Contenu |
|---|---|
| [`evolution.md`](evolution.md) | Recette d’une modification, promotion et dépréciation des routes, cycle de vie, anciens alias |
| [`versions.md`](versions.md) | Fiche de version : ce que contient le système, ses capacités, sa compatibilité, ses sections à l’essai et ce qui en est vérifié |

<!-- origine:README.md -->
## Source de vérité et distributions

Le dépôt GitHub est la **source de vérité**. La distribution Local est un export dérivé : même arborescence, sans les outils de préparation ni l’intégration continue ; son README remplace les passages balisés `github:` (installation par dépôt, CI, outils de construction) par leur variante locale, définie dans `scripts/build_distributions.sh`. Elle ne doit pas être modifiée à la main. <!-- références:github -->

Depuis la distribution GitHub, préparez la livraison :

```bash
python3 scripts/preparer_livraison.py
```

Cette commande compile le noyau, exécute les contrôles du package et construit les deux distributions reproductibles, sans envoi ni déploiement.

| Option | Résultat |
|---|---|
| `--empreintes` | Affiche les empreintes SHA256 des archives. |
| `--log CHEMIN` ou `--journal CHEMIN` | Conserve la sortie détaillée des contrôles dans un fichier `.log` ; les deux options sont équivalentes. Par défaut : `.logs/preparer_livraison.log`. Dans le paquet, le journal doit rester sous `.logs/` ; ailleurs, choisir un chemin hors du paquet. |
| `--require-browser` | Exige l’exécution des tests de pages et fait échouer la préparation si le navigateur est indisponible. |

Sans navigateur, les tests de pages restent `NOT-VERIFIED`. Les limites des contrôles restent visibles même lorsque la préparation réussit.

Dans l’export Local, utilisez `python3 scripts/validate_all.py`, avec `--require-browser` si ces essais sont exigés. Cet export ne contient pas la commande de préparation.

Le budget décrit dans `maintenance/evolution.md` (contrats de maintenance) concerne le fichier `SKILL.md` complet, mesuré en octets UTF-8. Le même contrôle est exécuté lors de la compilation et de la validation des distributions. Il borne la taille chargée ; il ne mesure ni la charge cognitive ni le coût complet d’un run.

### Noyau commun et détails

Le compilateur tient la table de tous les blocs protégés : communs, ou disponibles dans une route propriétaire avec leur activation. Le lecteur ne replie que les textes complets effectivement présents dans la skill. Installer une ancienne skill avec un paquet récent ne prouve donc pas que les détails récents sont déjà chargés ; après mise à jour, recompiler et recopier la skill.

La commande `python3 scripts/read_route.py --mode MODE` affiche uniquement la ligne du mode déjà classé, sans créer de classification ni de table concurrente. Les détails se lisent selon la décision et le périmètre ; le nombre de contrôles et la taille du fichier ne remplacent pas la preuve de leur utilité.

### Reprendre une préparation interrompue

Un verrou `.distribution.lock` bloque un second build. Le fichier owner.txt est produit pendant le build dans ce verrou, et ne fait pas partie des fichiers distribués. Lorsqu’il existe, il indique PID, début UTC et dossier ; ces indices peuvent être absents sur un ancien verrou et ne suffisent pas à prouver qu’un processus est arrêté. Dans le même environnement, inspectez le PID et sa commande (`ps -p PID -o pid,ppid,lstart,args`), les builds de ce dossier et le job ou la session qui les lance. Un PID peut être réutilisé. Tant que l’absence de build actif n’est pas établie, conservez le verrou ; son ancienneté ne justifie aucune suppression.

Avant toute reprise, conservez à part les archives, `dist`, `.dist.previous`, `.archives.previous` et le journal s’ils existent. Si `.archives.previous` existe, ou si `dist` et `.dist.previous` coexistent, le script s’arrête : comparez les inventaires et empreintes, identifiez la dernière livraison complète à l’aide du journal, puis conservez cette livraison et les autres exemplaires dans des dossiers distincts. Ne promouvez pas un mélange de versions et ne supprimez pas une sauvegarde pour forcer le build. Une sauvegarde `.dist.previous` seule est restaurée par le script ; elle ne prouve pas à elle seule l’état des archives.

Dans la distribution GitHub, lorsque le build est confirmé inactif et les sauvegardes identifiées, retirez uniquement le fichier owner.txt produit par le build, puis le dossier de verrou vide (`rmdir` refuse un contenu inattendu). Relancez `python3 scripts/preparer_livraison.py` ; le succès exige les contrôles et les exports complets. Si la situation reste ambiguë, conservez les fichiers et le diagnostic pour le mainteneur. Aucun verrou ni backup n’est effacé automatiquement selon son âge. <!-- références:github -->

Pour produire seulement les deux archives, exécutez :

```bash
bash scripts/build_distributions.sh
```

Le build régénère les distributions de travail dans `dist/` et écrit les archives déterministes suivantes à la racine du dépôt :

```text
Design_Governance_V1_GITHUB.zip
Design_Governance_V1_LOCAL.zip
```

Les modifications doivent être apportées aux sources du dépôt, puis vérifiées par les contrôles et le build. Les archives et exports ne sont pas des sources normatives indépendantes.

<!-- origine:README.md -->
## Validation

Utilisez Python **3.10 ou plus récent**. Les contrôles documentaires et machine utilisent la bibliothèque standard Python. La recette de rendu et les tests qui ouvrent des pages nécessitent en plus **Playwright et son navigateur Chromium** ; sans eux, ces tests restent `NOT-VERIFIED`. La planche (à l’essai) demande **Pillow** ; la commande de regard (à l’essai), **numpy, SciPy et Pillow** ; le parcours par défaut (à l’essai), les mêmes, l’accès au registre npm ou à Google Fonts pour `polices`, et aux sites et collections demandés pour `references` ; sans ces dépendances, leurs tests restent `NOT-VERIFIED`. La construction des archives de la distribution GitHub nécessite Bash, `zip` et les outils Unix utilisés par `scripts/build_distributions.sh` ; elle est contrôlée sous Linux. <!-- références:github -->

Un Chromium déjà installé peut être choisi explicitement avec `--browser-executable CHEMIN` dans la recette de rendu, ou `DG_BROWSER_EXECUTABLE` pour elle et ses tests ; elle bloque aussi par défaut les ressources hébergées ailleurs (`--allow-external` pour les laisser passer), afin de mesurer la même page. Sa version et son exécutable sont conservés dans la provenance ; ce choix ne remplace pas silencieusement le navigateur Playwright. Si la politique du navigateur interdit les fichiers locaux, `--serve-local` (ou `DG_RENDER_SERVE_LOCAL=1`) sert temporairement le dossier du fichier sur 127.0.0.1, puis ferme le serveur. Les autres origines restent bloquées par défaut.

Exemple pour un environnement où Chromium est déjà installé à cet emplacement :

```bash
DG_BROWSER_EXECUTABLE=/usr/bin/chromium DG_RENDER_SERVE_LOCAL=1 python3 scripts/validate_all.py --require-browser
```

Une règle écrite dans une source normative (DIRECTION, ACTION, SAVOIR, BIBLIOTHEQUE) doit être servie par une route ou compilée dans le noyau : `validate_structure.py` refuse toute autre ligne (garde ATT-01). Un texte destiné aux personnes s’y place entre `<!-- orientation:début -->` et `<!-- orientation:fin -->`. Les chemins d’exemple entre accents graves portent le préfixe `exemple:` ; les chemins opérationnels doivent se résoudre vers un fichier livré ou une route. Une référence destinée à une seule distribution se marque sur sa ligne par le commentaire HTML « références:github » ou « références:local » : son chemin doit être déclaré dans le manifeste de cette distribution. Les contrôles ignorent les blocs d’exemple, mais vérifient les liens Markdown.

Les tests JavaScript sur DOM simulés utilisent un runtime Node déjà disponible ; son absence laisse cette partie `NOT-VERIFIED`. `python3 scripts/test_check_render.py --skip-browser` exécute seulement les tests synthétiques et les DOM simulés, sans ouvrir de page ni installer de dépendance.

La projection machine comprend aussi les contrats de production : `DOMAIN_FRAME`, `RESEARCH_BRIEF` et les contrats de direction créative, de réalité UI/UX et d’évaluation. Ils sont illustrés dans `gouvernance/schemas/examples/` et contrôlés par `gouvernance/outils/validate_contracts.py`.

| Commande | Fonction |
|---|---|
| `python3 scripts/validate_design_governance.py` | Contrôle l’inventaire, les liens Markdown relatifs, le vocabulaire structuré et les conventions du package. |
| `python3 gouvernance/outils/validate_run_card.py` | Exécute la suite intégrée de validation des projections et des fixtures `RUN_CARD`. |
| `python3 gouvernance/outils/validate_run_card.py chemin/run.json` | Valide un fichier JSON ciblé et échoue s’il est absent, malformé ou sémantiquement invalide. |
| `python3 gouvernance/outils/validate_contracts.py --type production_contracts chemin/contrat.json` | Valide un contrat ciblé, y compris hors du package ; sans `--type`, la famille est détectée par les clés racines. |
| `python3 scripts/validate_reading_map.py` | Vérifie la carte de lecture, ses propriétaires, ses locators et sa frontière non normative. |
| `python3 scripts/read_route.py --tronc MODE` | Affiche le tronc de la ligne d’un mode (routes lues à chaque run de ce mode), sa taille, sa marge et le respect du budget de 35 000 caractères ; signale une marge sous 10 % et rend le code 1 si le budget est dépassé. |
| `DG_JOURNAL=run.jsonl python3 scripts/read_route.py …`, puis `python3 scripts/journal_mobilisation.py run.jsonl` | Journal de mobilisation, à l’essai : la variable `DG_JOURNAL` fait noter au lecteur de routes, à `check_render.py`, à `planche.py`, à `regard.py` et à `parcours.py` ce qu’ils ont servi ; le second script en tire une fiche de mobilisation (lectures, appels, résultats, tronc non consulté, run DIRECTION sans planche ni regard, rendu sans ligne de mode). Une route servie puis coupée ou filtrée (« … \| head ») n’est pas comptée comme consultée. Sans la variable, rien n’est écrit ; un journal impossible à écrire ne bloque aucun outil. Le journal observe des lectures et des appels, pas l’attention de l’agent. |
| `python3 scripts/parcours.py verifier page.html --foyer SÉL --action SÉL [--refs DOSSIER]` | Parcours par défaut, à l’essai : recette, regard, captures, signaux de finition et planche de mouvement en une fiche `parcours.md`, à côté de la page ; `mouvement page.html --action SÉL` produit la planche seule. `python3 scripts/parcours.py polices "Famille:400,700i"` télécharge des polices ouvertes et écrit leur feuille ; `captures page.html --version v2` capture une version de la boucle ; `critique page.html --brief "…"` prépare un regard séparé ; `references --url ADRESSE --commons "requête"` rassemble des références avec leur provenance. |
| `python3 scripts/read_route.py --connexions` | Affiche le sommaire des connexions situées ; ajouter un identifiant comme `C03` pour lire condition, contributions, limites et sources résolues. |
| `python3 scripts/test_audit_regressions.py` | Exécute les régressions de navigation, de capacités et de conditions de façade ; ne mesure ni la compréhension utilisateur ni la qualité esthétique. |
| `python3 scripts/validate_all.py` | Exécute les contrôles documentaires, machine, CLI, fixtures négatives, compilation et reproductibilité des distributions. |
| `python3 scripts/validate_all.py --lecture-seule` | Exécute les mêmes contrôles sans construire ni remplacer les distributions : `dist/`, `.build/` et les archives ne sont pas touchés (le runner le vérifie). Des caches Python et des copies temporaires de test peuvent être écrits ailleurs. Build et reproductibilité restent `NOT-VERIFIED`. |
| `python3 scripts/validate_all.py --skip-browser` | Exécute les mêmes contrôles sans lancer les tests de pages, déclarés `NOT-VERIFIED`. Le build l’emploie pour valider l’export Local, dont le code vient d’être testé dans le navigateur ; incompatible avec `--require-browser`. |

Les chemins `exemple: chemin/run.json` et `exemple: chemin/contrat.json` sont des exemples à remplacer par ceux de vos fichiers. Pour exécuter les contrôles intégrés du package :

```bash
python3 scripts/validate_design_governance.py
python3 gouvernance/outils/validate_run_card.py
python3 scripts/validate_all.py
```

Ces contrôles vérifient la forme du package, de ses projections et de ses distributions, ainsi que la liste close des conditions de façade ; une divergence hors de cette liste n’est pas détectée. Ce qu’ils ne prouvent pas est décrit dans [la fiche de version](versions.md#ce-qui-est-vérifié-ce-qui-ne-lest-pas) ; ce qu’une `RUN_CARD` validée atteste, dans la frontière de validation d’`ACTION/RUN_CARD`.

<!-- origine:READING_MAP.md -->
## Résolution des routes

Les noms de route sont des locators documentaires. Les résoudre avec `python3 scripts/read_route.py LOCATOR` : le lecteur retrouve la section propriétaire à son emplacement actuel via la table `LIEUX`. En lecture manuelle, suivre le [sommaire des sources](../sections/README.md), puis le titre exact. Un renvoi qui ne résout pas doit être déclaré obsolète, conceptuel ou `NOT-VERIFIED`; il ne doit jamais être traité comme une instruction active par supposition.

| Code ou adresse | Propriétaire actuel |
|---|---|
| `DIRECTION/*` | Section DIRECTION retrouvée par le lecteur, dans l’un des emplacements déclarés. |
| `ACTION/*` | Section ACTION retrouvée par le lecteur, dans l’un des emplacements déclarés. |
| `SAVOIR/*` | Section SAVOIR retrouvée par le lecteur, dans l’un des emplacements déclarés. |
| `BIBLIOTHEQUE/*` | Section BIBLIOTHEQUE retrouvée par le lecteur, dans l’un des emplacements déclarés. |
| `maintenance/versions` ou `CHANGELOG` | Fiche `maintenance/versions.md` (état courant) ; les règles de cycle de vie sont dans `maintenance/evolution.md`. |
| `RUN_CARD` | `gouvernance/schemas/run_card.schema.json`, exemple et validateur |

`RUN_CARD` est un **adaptateur machine**, pas un locator Markdown résolvable par `scripts/read_route.py`. Pour l’inspecter ou le valider, utiliser le schéma, l’exemple et `gouvernance/outils/validate_run_card.py` ; ne pas l’invoquer comme une route documentaire.

Suite : [ce que contient la version](versions.md) et [l’évolution du système](evolution.md). Retour au [README](../README.md).
