#!/usr/bin/env python3
"""Cas connus de `scripts/parcours.py` : chaque sous-commande retrouve la réponse attendue.

Sans navigateur : lecture des graisses, plus grand rectangle vide, coupe des détails, seuils des signaux, feuille de
polices écrite à partir de fichiers simulés (aucun accès réseau), et présence de chaque geste nommé par un signal
dans `SAVOIR/STATE`. Avec navigateur : une page piège déclenche chaque signal, une page propre n'en déclenche aucun,
les faux positifs connus restent muets (chiffres en chasse fixe ou en SVG, marge étroite), l'habillage de gabarit est
relevé, la planche de mouvement distingue un moment orchestré d'un effet répété (fondu sur chaque bloc, survol sur
chaque carte, boucle sans fin, mouvement réduit ignoré, texte jamais révélé), les captures existent à la bonne
échelle et `verifier` écrit sa fiche et rend le bon code.

Pages pièges écrites dans un dossier temporaire ; aucune ressource externe. Il faut Playwright, Chromium, NumPy,
SciPy et Pillow : s'il en manque un, les cas navigateur sont NOT-VERIFIED, jamais réussis ; `--require-browser`
en fait un échec. Ce fichier ne valide aucun rendu : il vérifie que l'outil dit vrai sur des cas connus.
"""
from __future__ import annotations

import sys
sys.dont_write_bytecode = True
import argparse
import contextlib
import importlib.util
import io
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent

SALE = """<!doctype html><html lang="fr"><meta charset="utf-8"><title>Piège</title>
<style>body{margin:0;background:#eee;font-family:Arial,sans-serif}
.carte{position:absolute;left:120px;top:80px;width:1100px;height:700px;background:#fff;display:grid;grid-template-columns:1fr 1fr;
 border-radius:14px;box-shadow:0 2px 4px rgba(0,0,0,.2)}
.g{padding:30px}.d{background:#fafafa;padding:30px}
.b1{border-radius:4px;background:#ddd;width:80px;height:40px;box-shadow:0 8px 20px rgba(0,0,0,.3)}
.b2{border-radius:9px;background:#ccc;width:80px;height:40px;margin-top:8px;box-shadow:0 1px 1px #000}
h1{font-size:44px;width:520px;margin:0 0 10px;font-family:Georgia,serif}
.mono{font-family:"Courier New",monospace;font-size:15px}
.mini{font-size:9px}.vert{color:#0a0}.rouge{color:#d00}.bleu{color:#00c}
.prix{width:200px}.prix div{text-align:right;font-size:18px}
.s1{font-size:12px}.s2{font-size:13px}.s3{font-size:14px}.s4{font-size:15px}.s5{font-size:16px}</style>
<div class="carte"><div class="g">
<h1 id="titre">Un&nbsp;titre&nbsp;piège&nbsp;finit vraiment</h1>
<p class="mono">Un paragraphe courant composé en chasse fixe, assez long pour fatiguer la lecture sur plusieurs lignes de texte.</p>
<p class="mini">Mention minuscule illisible</p><p class="vert">vert</p><p class="rouge">rouge</p><p class="bleu">bleu</p>
<div class="b1"></div><div class="b2"></div>
<div class="prix"><div>1 240</div><div>87</div><div>19 990</div></div>
<p class="s1">a b</p><p class="s2">a b</p><p class="s3">a b</p><p class="s4">a b</p><p class="s5">a b</p>
</div><div class="d"><p>Seulement ceci en haut ; le reste de la colonne est vide.</p></div></div>
<button id="action" style="position:absolute;top:1400px;left:40px">Agir</button>
</html>"""

PROPRE = """<!doctype html><html lang="fr"><meta charset="utf-8"><title>Propre</title>
<style>body{margin:0;background:#f4f4f2;font-family:Arial,sans-serif;color:#222}
main{max-width:900px;margin:60px auto;padding:0 24px}
h1{font-size:40px;margin:0 0 16px;text-wrap:balance}p{font-size:16px;line-height:1.5}
.carte{border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,.15);padding:16px;margin:12px 0;background:#fff}
.prix div{text-align:right;font-variant-numeric:tabular-nums;width:160px}
a.cta{display:inline-block;border-radius:8px;background:#1b4dd8;color:#fff;padding:12px 18px;text-decoration:none}</style>
<main><h1>Un titre court</h1><p>Un paragraphe sobre, sur une seule échelle.</p>
<div class="carte"><p>Première carte.</p></div><div class="carte"><p>Seconde carte.</p></div>
<div class="prix"><div>1 240</div><div>87</div><div>19 990</div></div>
<a class="cta" id="action" href="#">Commencer</a></main></html>"""

MUET = """<!doctype html><html lang="fr"><meta charset="utf-8"><title>Muet</title>
<style>body{margin:0;background:#fff;font-family:Arial,sans-serif}
.m div{font-family:"Courier New",monospace;text-align:right;width:160px}
.panneau{position:absolute;left:100px;top:100px;width:900px;height:500px;background:#fff;display:flex}
.panneau .rempli{flex:1;background:repeating-linear-gradient(45deg,#ccc 0 6px,#888 6px 12px)}
.panneau .marge{width:64px;background:#fff}</style>
<div class="m"><div>1 240</div><div>87</div><div>19 990</div></div>
<svg width="200" height="120"><text x="150" y="20" text-anchor="end">1 240</text><text x="150" y="60" text-anchor="end">87</text>
<text x="150" y="100" text-anchor="end">19 990</text></svg>
<div class="panneau"><div class="rempli"></div><div class="marge"></div></div></html>"""

GRAIN = "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120'%3E%3Cfilter id='g'%3E%3CfeTurbulence baseFrequency='.9'/%3E%3C/filter%3E%3Crect width='120' height='120' filter='url(%23g)' opacity='.08'/%3E%3C/svg%3E\")"

BANDES = """<!doctype html><html lang="fr"><meta charset="utf-8"><title>Bandes</title>
<style>body{margin:0;font-family:Arial,sans-serif}
.fond{position:fixed;inset:0;display:flex;flex-direction:column}.fond i{flex:1}
.fond i:nth-child(1){background:#d9c27a}.fond i:nth-child(2){background:#c79a5b}.fond i:nth-child(3){background:#a8703f}
.fond i:nth-child(4){background:#7b4a28}.fond i:nth-child(5){background:#4f2c17}.fond i:nth-child(6){background:#2e190c}
.grain{position:fixed;inset:0;background:GRAIN}
h1{position:relative;margin:24px 20px 8px;font-size:44px}p{position:relative;margin:0 20px;font-size:16px}
button{position:absolute;left:20px;right:20px;bottom:40px;height:56px}
.bulles{position:absolute;top:140px;left:20px;width:350px;height:600px}
.bulles b{position:absolute;width:18px;height:18px;border-radius:50%;background:#f4ead8}</style>
<div class="fond"><i></i><i></i><i></i><i></i><i></i><i></i></div><div class="grain"></div>
<h1>Titre en haut</h1><p>Un chapô court sous le titre, sur deux lignes au plus.</p>BULLES<button>Commander</button></html>"""

GENERIQUE = """<!doctype html><html lang="fr"><meta charset="utf-8"><title>Gabarit</title>
<style>body{margin:0;font:16px/1.5 Arial,sans-serif}section{min-height:600px;padding:80px}
.reveal{opacity:0;transform:translateY(24px);transition:opacity .6s,transform .6s}.reveal.vu{opacity:1;transform:none}
.eyebrow{text-transform:uppercase;letter-spacing:.14em;font-size:12px}
.cartes{display:flex;gap:16px}.carte{width:220px;height:160px;background:#f3f3f3;transition:transform .3s}.carte:hover{transform:translateY(-4px)}
.btn{display:inline-block;padding:14px 22px;background:#111;color:#fff}</style>
<section><p class="eyebrow">Notre studio</p><h1>Un titre de démonstration</h1><p>Design · Code · Stratégie</p><a class="btn" id="cta" href="#">Commencer →</a></section>
<section class="reveal"><p class="eyebrow">Services</p><h2>Ce que nous faisons</h2><div class="cartes"><div class="carte">01</div><div class="carte">02</div><div class="carte">03</div></div><a class="btn" href="#">Voir plus →</a></section>
<section class="reveal"><p class="eyebrow">Méthode</p><h2>Comment</h2><p>Écoute · Esquisse · Livraison</p></section>
<section class="reveal"><h2>Contact</h2><p>Écrivez-nous pour parler de votre projet.</p></section>
<script>const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)e.target.classList.add('vu')}));document.querySelectorAll('.reveal').forEach(x=>io.observe(x));</script></html>"""

ORCHESTRE = """<!doctype html><html lang="fr"><meta charset="utf-8"><title>Orchestré</title>
<style>body{margin:0;font:18px Georgia,serif;background:#f6f6f2}.hero{height:900px;position:relative;overflow:hidden}
.bande{position:absolute;left:0;top:300px;height:200px;width:100%;background:#c33;transform-origin:left;animation:tire 1.2s both}
h1{position:absolute;left:80px;top:340px;margin:0;font-size:96px;color:#fff;animation:monte .8s .6s both}
@keyframes tire{from{transform:scaleX(0)}to{transform:none}}@keyframes monte{from{opacity:0;transform:translateY(30px)}to{opacity:1;transform:none}}
#cta{position:absolute;left:80px;top:560px;padding:14px 20px;background:#111;color:#fff;transition:background .2s}#cta:hover{background:#c33}
@media (prefers-reduced-motion: reduce){.bande,h1{animation:none}}</style>
<div class="hero"><div class="bande"></div><h1>La ligne rouge</h1><a id="cta" href="#">Réserver une place</a></div></html>"""

BOUCLE = """<!doctype html><html lang="fr"><meta charset="utf-8"><title>Boucle</title>
<style>body{margin:0}.flotte{width:200px;height:200px;margin:200px;background:#36c;animation:flotte 3s infinite}
@keyframes flotte{50%{transform:translateY(-20px)}}.cache{opacity:0}</style>
<div class="flotte"></div><p class="cache" style="margin:80px;height:1200px">Un texte qui attend une révélation jamais déclenchée.</p></html>"""

GESTES_ATTENDUS = ["Cohérence de rayon", "Surface", "Texte secondaire", "Masse visuelle", "Accent",
                   "Alignement optique", "Chiffres", "Gestion du vide", "Partie ordinaire", "Mouvement", "Habillage de gabarit"]


def manquants() -> list[str]:
    absents = [m for m in ("numpy", "scipy", "PIL", "playwright") if importlib.util.find_spec(m) is None]
    if not absents:
        try:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as p:
                p.chromium.launch().close()
        except Exception as exc:
            absents.append(f"Chromium ({type(exc).__name__})")
    return absents


def statiques(parcours, attendre) -> None:
    import numpy as np
    rng = np.random.default_rng(1)
    attendre(parcours.plat(128 + rng.normal(0, 2.5, (16, 16))), "vide : le grain d'une matière s'efface au lissage")
    attendre(parcours.plat(np.vstack([np.full((8, 16), 200.0), np.full((8, 16), 90.0)])),
             "vide : la limite nette entre deux bandes de fond reste plate")
    detail = "1440 px : intersection verticale 520.5 px sur 520.5, horizontale 392 px sur 392; 390 px : intersection verticale 0 px sur 446"
    r = parcours.recomposition([{"check": "Objet de preuve au premier écran (.planche)", "detail": detail}])
    attendre(r is not None and r["largeur"] == 390 and r["source"] == "BIBLIOTHEQUE/SEQUENCE",
             "recomposition : preuve vue au bureau, absente en mobile, signal renvoyé à BIBLIOTHEQUE/SEQUENCE")
    attendre(parcours.recomposition([{"check": "Objet de preuve au premier écran (.p)", "detail": detail.replace("0 px sur 446", "12 px sur 446")}]) is None
             and parcours.recomposition([]) is None, "recomposition : preuve présente aux deux largeurs ou absente de la recette, aucun signal")
    damier = np.indices((16, 16)).sum(axis=0) // 4 % 2 * 200.0
    attendre(not parcours.plat(damier), "vide : une forme dessinée n'est pas plate")
    attendre(parcours.analyser_spec("Bodoni Moda:400,700i") == ("Bodoni Moda", [(400, "normal"), (700, "italic")]),
             "polices : « Famille:400,700i » donne deux styles, l'italique compris")
    attendre(parcours.analyser_spec("Inter") == ("Inter", [(400, "normal")]), "polices : sans graisse, 400 normal")
    grille = [[1, 1, 0, 0], [1, 1, 1, 1], [1, 1, 1, 1], [0, 1, 1, 1]]
    attendre(parcours.plus_grand_rectangle(grille)[0] == 9, "vide : plus grand rectangle de cases vides (3 × 3)")
    detail = "premier ; deuxième ; " + "x" * 80
    court = parcours.abreger(detail, 40)
    attendre(court.startswith("premier ; deuxième") and "recette.json" in court and "xxxx" not in court,
             "fiche : un détail long est coupé à la dernière clause entière et renvoie à recette.json")
    G = parcours.gestes()
    absents = [g for g in GESTES_ATTENDUS if g not in G]
    attendre(not absents, f"gestes : chaque geste nommé par un signal se lit dans SAVOIR/STATE (absents : {absents or 'aucun'})")
    attendre(all(t.endswith((".", "?", "!")) for t in G.values()), "gestes : la première phrase de chaque geste finit par un point")
    vide = {"rayons": {}, "ombres": {}, "familles": {"Arial": 10}, "tailles": {"16": 1}, "teintes": {},
            "mono_long": [], "veuves": [], "petits": [], "chiffres": []}
    attendre(parcours.signaux(vide, 1440, G) == [], "signaux : une mesure calme ne pose aucune question")
    une = dict(vide, gabarit={"medians": ["A · B"], "surtitres": [], "fleches": ["Voir →"], "numeros": [], "tirets": []})
    attendre(parcours.signaux(une, 1440, G) == [], "gabarit : une marque isolée, décidée, ne pose pas de question")
    m0 = {"largeur": 1440, "entree": [], "revelations": [], "defile": 0, "script": False, "cartes": [], "reduit": [], "invisibles": [], "action_ms": None}
    attendre([s["mesure"].startswith("rien ne bouge") for s in parcours.mouvement_signaux(m0, G)] == [True],
             "mouvement : rien ne bouge, une seule question, qui laisse la page d'outil sans justification")
    deux = [{"id": "1", "cible": "div.bande", "props": ["transform"], "infinie": False}, {"id": "2", "cible": "h1", "props": ["opacity", "transform"], "infinie": False}]
    attendre(parcours.mouvement_signaux(dict(m0, entree=deux), G) == [], "mouvement : un moment orchestré sur deux éléments ne pose aucune question")
    serre = dict(vide, tailles={str(t): 1 for t in (12, 13, 14, 15, 16)})
    attendre([s["geste"] for s in parcours.signaux(serre, 1440, G)] == ["Masse visuelle"],
             "signaux : quatre paires de tailles voisines suffisent, sous le seuil du nombre de tailles")

    faux = {(400, "normal", "latin"): b"wOF2-faux"}
    orig = parcours.polices_fontsource, parcours.polices_google
    try:
        parcours.polices_fontsource = lambda nom, styles, sous: (faux, "OFL-1.1 (simulé)") if nom == "Connue" else None
        parcours.polices_google = lambda nom, styles, sous: None
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp)
            css, notes = parcours.polices(["Connue:400"], d / "a", False, False)
            attendre(css is not None and "url(fonts/connue-latin-400-normal.woff2)" in css.read_text()
                     and (d / "a" / "fonts" / "connue-latin-400-normal.woff2").is_file() and "OFL-1.1" in notes[0],
                     "polices : fichier écrit, règle @font-face qui le cite, licence rapportée")
            css, _ = parcours.polices(["Connue:400"], d / "b", True, False)
            attendre(css is not None and "data:font/woff2;base64," in css.read_text() and not (d / "b" / "fonts").exists(),
                     "polices --integrer : données dans la feuille, aucun fichier à part")
            css, notes = parcours.polices(["Inconnue:400"], d / "c", False, False)
            attendre(css is None and not (d / "c").exists() and "introuvable" in notes[0],
                     "polices : famille introuvable, aucune feuille écrite, rien de deviné")
    finally:
        parcours.polices_fontsource, parcours.polices_google = orig


COMMONS = {"query": {"pages": {"12": {"index": 2, "title": "File:Atelier B.jpg", "imageinfo": [{"descriptionurl": "https://commons.example/B",
            "thumburl": "https://upload.example/b.jpg", "extmetadata": {"Artist": {"value": "<a href='x'>Ama &amp; Co</a>"},
            "LicenseShortName": {"value": "CC BY-SA 4.0"}, "DateTimeOriginal": {"value": "2019"}}}]},
            "11": {"index": 1, "title": "File:Atelier A.jpg", "imageinfo": [{"descriptionurl": "https://commons.example/A",
            "thumburl": "https://upload.example/a.jpg", "extmetadata": {"LicenseShortName": {"value": "Public domain"}}}]}}}}
OPENVERSE = {"results": [{"title": "Coupe", "foreign_landing_url": "https://flickr.example/1", "thumbnail": "https://ov.example/t1",
              "url": "https://flickr.example/1.jpg", "creator": "Bayo", "license": "by", "license_version": "2.0", "source": "flickr"}]}


def statiques_references(parcours, attendre) -> None:
    import json as _json
    import urllib.error
    from PIL import Image
    tampon = io.BytesIO()
    Image.new("RGB", (64, 40), (120, 60, 30)).save(tampon, "PNG")
    png = tampon.getvalue()
    appels = []

    def faux(url):
        appels.append(url)
        if "commons.wikimedia.org" in url:
            return _json.dumps(COMMONS).encode()
        if "api.openverse.org" in url:
            return _json.dumps(OPENVERSE).encode()
        if url == "https://ov.example/t1":
            raise urllib.error.HTTPError(url, 424, "x", {}, None)
        if url == "https://upload.example/b.jpg":
            raise urllib.error.HTTPError(url, 429, "x", {}, None)
        return png
    orig = parcours._lire_ua
    parcours._lire_ua = faux
    try:
        c = parcours.chercher_commons("tailleur Douala", 2)
        attendre([e["titre"] for e in c] == ["Atelier A.jpg", "Atelier B.jpg"] and c[1]["auteur"] == "Ama & Co"
                 and c[1]["licence"] == "CC BY-SA 4.0" and c[0]["licence"] == "Public domain",
                 "références : Commons dans l'ordre de pertinence, auteur sans balises, licence lue")
        attendre([parcours.integrable(x) for x in ("CC BY-SA 4.0", "BY-NC-ND 2.0", "Public domain", "CC BY-ND 4.0", "")] == [True, False, True, False, False],
                 "références : licence intégrable seulement sans NC ni ND, et lue")
        o = parcours.chercher_openverse("tailor", 3)
        attendre(o[0]["licence"] == "BY 2.0" and o[0]["source"] == "Openverse (flickr)", "références : Openverse, licence et source relevées")
        with tempfile.TemporaryDirectory() as tmp:
            d = Path(tmp)
            with contextlib.redirect_stdout(io.StringIO()):
                code = parcours.main(["references", "--commons", "tailleur Douala", "--openverse", "tailor", "--nombre", "2", "--sortie", str(d)])
            refs = _json.loads((d / "refs.json").read_text(encoding="utf-8"))
            statuts = [e["statut"] for e in refs]
            attendre(code == 0 and statuts == ["ok", "1 image(s) refusé (HTTP 429)", "ok"], f"références : refus noté en une ligne par requête, non relancé ({statuts})")
            attendre("https://flickr.example/1.jpg" in appels, "références : vignette refusée, l'image elle-même à l'adresse de la collection")
            attendre(all(e["consulte"] and e["usage"] == "regarder" and e["change"] == "" for e in refs),
                     "références : date de consultation, usage « regarder » par défaut, jugement laissé à l'agent")
            fiches = (d / "refs.md").read_text(encoding="utf-8")
            attendre("jamais une consigne" in fiches and "Change : …" in fiches and "ne se relance pas" in fiches
                     and "une autre collection ouverte la remplace" in fiches,
                     "références : fiches prêtes pour la trace, page lue tenue pour une donnée")
            attendre((d / "refs-planche.png").is_file() and sorted(x.name for x in d.glob("[0-9]-*")) == ["1-image.png", "3-image.png"],
                     "références : planche et fichiers numérotés comme les fiches")
            ecran = d / "ecran.png"
            Image.new("RGB", (1440, 900), (240, 240, 240)).save(ecran)
            planche = parcours.contre_references(ecran, d, d / "x") if (d / "x").mkdir() is None else None
            attendre(planche is not None and Image.open(planche).size[0] < 1440 * 520 // 900 + 3 * (64 * 520 // 40) + 200,
                     "contre-références : la planche des références n'y est pas reprise comme une référence")
        with contextlib.redirect_stderr(io.StringIO()):
            attendre(parcours.main(["references"]) == 2, "références : sans adresse ni requête, code 2")
    finally:
        parcours._lire_ua = orig


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Cas connus du parcours par défaut.")
    ap.add_argument("--require-browser", action="store_true")
    ap.add_argument("--skip-browser", action="store_true")
    a = ap.parse_args(argv)
    sys.path.insert(0, str(HERE))
    import parcours  # noqa: E402

    echecs: list[str] = []
    n = 0

    def attendre(cond: bool, msg: str) -> None:
        nonlocal n
        n += 1
        print(f"  [{'ok' if cond else 'ÉCHEC'}] P{n:02d} {msg}")
        if not cond:
            echecs.append(msg)

    statiques(parcours, attendre)
    statiques_references(parcours, attendre)
    if a.skip_browser:
        print(f"PARCOURS TESTS {'FAILED' if echecs else 'NOT-VERIFIED'} — {n} cas statiques ; navigateur écarté (--skip-browser)")
        return 1 if echecs else 0
    absents = manquants()
    if absents:
        print(f"PARCOURS TESTS {'FAILED' if echecs else 'NOT-VERIFIED'} — {n} cas statiques ; absents : " + ", ".join(absents))
        return 1 if echecs or a.require_browser else 0

    with tempfile.TemporaryDirectory() as tmp:
        d = Path(tmp)
        for nom, html in (("sale", SALE), ("propre", PROPRE), ("muet", MUET)):
            (d / f"{nom}.html").write_text(html, encoding="utf-8")

        sig = parcours.finition(d / "sale.html", [1440])
        gestes = {s["geste"] for s in sig}
        mesures = " ".join(s["mesure"] for s in sig)
        for g in ("Cohérence de rayon", "Surface", "Accent", "Masse visuelle", "Alignement optique", "Chiffres", "Gestion du vide"):
            attendre(g in gestes, f"finition (page piège) : signal « {g} »")
        attendre("chasse fixe" in mesures, "finition (page piège) : texte courant en chasse fixe")
        attendre("9 px" in mesures, "finition (page piège) : texte sous 11 px")
        attendre("div.d" in mesures, "finition (page piège) : le vide est trouvé dans la colonne qui le porte")
        attendre(all(s["geste_texte"] and "introuvable" not in s["geste_texte"] for s in sig),
                 "finition : chaque signal porte son geste lu dans SAVOIR/STATE")

        sig = parcours.finition(d / "propre.html", [1440, 390])
        attendre(sig == [], f"finition (page propre) : aucun signal ({[s['geste'] for s in sig]})")
        sig = parcours.finition(d / "muet.html", [1440])
        attendre(not any(s["geste"] in ("Chiffres", "Gestion du vide") for s in sig),
                 "finition : chiffres en chasse fixe ou en SVG et marge étroite restent muets")

        bulles = "<div class='bulles'>" + "".join(f"<b style='left:{(k * 53) % 330}px;top:{(k * 37) % 580}px'></b>" for k in range(70)) + "</div>"
        for nom, contenu in (("bandes", ""), ("bulles", bulles)):
            (d / f"{nom}.html").write_text(BANDES.replace("GRAIN", GRAIN).replace("BULLES", contenu), encoding="utf-8")
        sig = parcours.finition(d / "bandes.html", [390])
        attendre(any(s["geste"] == "Gestion du vide" and "premier écran" in s["mesure"] for s in sig),
                 "finition (390 px) : bande sans contenu sous des bandes de fond et un grain")
        sig = parcours.finition(d / "bulles.html", [390])
        attendre(not any(s["geste"] == "Gestion du vide" for s in sig), "finition (390 px) : un dessin fait de formes n'est pas un vide")
        (d / "champs.html").write_text("""<!doctype html><meta charset="utf-8"><style>body{margin:0;background:#eee;font:16px Arial}
form{position:absolute;left:300px;top:120px;width:640px;height:410px;background:#fff;padding:32px;box-sizing:border-box}
input{display:block;width:100%;height:120px;margin:0 0 24px;border:0;background:#fff;font-size:18px}</style>
<form><label>Nom</label><input><label>Adresse</label><input><button>Envoyer</button></form>""", encoding="utf-8")
        (d / "cadre.html").write_text("""<!doctype html><meta charset="utf-8"><style>body{margin:0;background:#e8e8e6;font:16px Arial}
.cadre{position:absolute;left:120px;top:120px;width:1200px;height:420px;background:#17181a;overflow:hidden}
.cadre svg{position:absolute;inset:0}.cadre p{position:absolute;left:0;right:0;bottom:24px;text-align:center;color:#fff;font-size:28px;margin:0}</style>
<div class="cadre"><svg aria-hidden="true" width="100%" height="100%"><filter id="g"><feTurbulence baseFrequency=".9"/></filter>
<rect width="100%" height="100%" filter="url(#g)" opacity=".06"/></svg><p>Un sous-titre en bas du cadre</p></div>""", encoding="utf-8")
        sig = parcours.finition(d / "cadre.html", [1440])
        attendre(any(s["geste"] == "Gestion du vide" and "div.cadre" in s["mesure"] for s in sig),
                 "finition : un cadre vide sous un calque de grain en SVG reste un vide")
        sig = parcours.finition(d / "champs.html", [1440])
        attendre(not any(s["geste"] == "Gestion du vide" for s in sig), "finition : un champ de saisie uni n'est pas un vide")

        for nom, html in (("generique", GENERIQUE), ("orchestre", ORCHESTRE), ("boucle", BOUCLE)):
            (d / f"{nom}.html").write_text(html, encoding="utf-8")
        G = parcours.gestes()
        sig = parcours.finition(d / "generique.html", [1440])
        gab = " ".join(s["mesure"] for s in sig if s["geste"] == "Habillage de gabarit")
        attendre(all(x in gab for x in ("points médians", "sur-titres", "flèches", "numéros")),
                 "gabarit : points médians, sur-titres en capitales, flèches et numéros relevés, révélations masquées comprises")
        mv = parcours.mouvement(d / "generique.html", 1440, d, "#cta")
        q = " ".join(s["mesure"] for s in parcours.mouvement_signaux(mv, G))
        attendre("fondu-glissé sur 3" in q and "survol sur 3 cartes" in q, f"mouvement (gabarit) : fondu sur chaque section et survol sur chaque carte ({q})")
        attendre(Path(mv["planche"]).is_file() and (d / "mouvement.json").is_file(), "mouvement : planche et relevé écrits")
        mv = parcours.mouvement(d / "orchestre.html", 1440, d / "o" if (d / "o").mkdir() is None else d, "#cta")
        attendre(parcours.mouvement_signaux(mv, G) == [] and mv["duree"] == 1400 and mv["reduit"] == [],
                 "mouvement (orchestré) : une entrée de 1,4 s, mouvement réduit respecté, aucune question")
        attendre(mv["action_ms"] == 0, "mouvement : l'action visible dès la première image")
        attendre(mv["survol"] == [{"cible": "action", "change": True}], "mouvement : le survol de l'action est capturé dans le même cadre, et son changement se voit")
        from PIL import Image as _Im
        attendre(_Im.open(mv["planche"]).size[0] > 5 * 360, "mouvement : cinq images d'entrée sur la planche")
        mv = parcours.mouvement(d / "boucle.html", 1440, d / "b" if (d / "b").mkdir() is None else d)
        q = " ".join(s["mesure"] for s in parcours.mouvement_signaux(mv, G))
        attendre("sans fin" in q and "mouvement réduit" in q and "invisible" in q,
                 f"mouvement : boucle sans fin, mouvement réduit ignoré, texte jamais révélé ({q})")
        vites = parcours.captures(d / "propre.html", [1440, 390], None, d / "boucle", "v2")
        from PIL import Image
        attendre(sorted(x.name for x in vites) == ["v2-1440.png", "v2-390.png"]
                 and Image.open(d / "boucle" / "v2-390.png").size == (390, 844),
                 "captures --version : premier écran seul, à 1x, nommé par version")
        with contextlib.redirect_stderr(io.StringIO()):
            attendre(parcours.main(["captures", str(d / "propre.html"), "--version", "a b"]) == 2, "captures --version : nom refusé s'il contient une espace")
        livre = parcours.captures(d / "sale.html", [1440], None, d / "livre", "pricing", True)
        attendre([x.name for x in livre] == ["pricing-1440.png"] and Image.open(livre[0]).size[1] > 900,
                 "captures --version --pleine : page entière sous le nom demandé")
        with contextlib.redirect_stderr(io.StringIO()):
            attendre(parcours.main(["captures", str(d / "propre.html"), "--pleine"]) == 2, "captures --pleine sans --version : refusé")

        caps = parcours.captures(d / "propre.html", [1440], "main", d / "caps")
        noms = {c.name for c in caps}
        attendre({"ecran-1440.png", "page-1440.png", "ecran-1440@2x.png", "foyer-1440@2x.png"} <= noms,
                 "captures : premier écran, page entière, @2x et foyer agrandi")
        attendre(Image.open(d / "caps" / "ecran-1440@2x.png").size == (2880, 1800), "captures : @2x à deux fois la fenêtre")

        refs = d / "refs"
        refs.mkdir()
        Image.new("RGB", (800, 600), (200, 30, 30)).save(refs / "r1.png")
        Image.new("RGB", (600, 900), (30, 30, 200)).save(refs / "r2.jpg")
        planche = parcours.contre_references(d / "caps" / "ecran-1440.png", refs, d / "caps")
        attendre(planche is not None and Image.open(planche).size[1] == 520 + 72, "contre-références : trois tuiles à la même hauteur")

        with contextlib.redirect_stdout(io.StringIO()):
            code_ok = parcours.main(["verifier", str(d / "propre.html"), "--action", "#action", "--foyer", "main",
                                     "--refs", str(refs), "--sortie", str(d / "v1")])
            code_ko = parcours.main(["verifier", str(d / "sale.html"), "--action", "#action", "--sortie", str(d / "v2")])
        fiche = (d / "v1" / "parcours.md").read_text(encoding="utf-8")
        attendre(code_ok == 0 and all(f"## {i}." in fiche for i in range(1, 7)), "verifier : fiche en six sections, code 0")
        attendre("**Partie ordinaire**" in fiche and "non mesuré" in fiche, "verifier : rappel des parties ordinaires, déclaré non mesuré")
        attendre(fiche.index("sans-texte-1440.png") < fiche.index("ecran-1440@2x.png") and "Avant d'ouvrir une autre capture" in fiche,
                 "verifier : l'image sans le texte vient d'abord, avant de relire la direction")
        attendre("planche.py atelier.png" in fiche and "retiree.html" in fiche, "verifier : garder un signal renvoie à l'atelier, commande donnée")
        attendre("contre-references.png" in fiche and "parcours.py verifier" in fiche,
                 "verifier : planche citée et prochaine commande écrite")
        attendre("mouvement-1440.png" in fiche and "- Mouvement :" in fiche.split("## 6.")[1],
                 "verifier : planche de mouvement citée et ligne de trace du mouvement")
        fiche = (d / "v2" / "parcours.md").read_text(encoding="utf-8")
        attendre(code_ko == 1 and "--in-frame" in fiche.split("## 2.")[0],
                 "verifier : action hors du premier écran, défaut bloquant et code 1")
        attendre("Sans référence fournie" in fiche, "verifier : sans --refs, la fiche demande de regarder des références")
        with contextlib.redirect_stderr(io.StringIO()):
            attendre(parcours.main(["verifier", str(d / "absente.html")]) == 2, "verifier : page introuvable, code 2")
        with contextlib.redirect_stdout(io.StringIO()):
            code = parcours.main(["critique", str(d / "propre.html"), "--brief", "Une page propre", "--refs", str(refs), "--sortie", str(d / "crit")])
        noms = sorted(x.name for x in (d / "crit" / "images").iterdir())
        consigne = (d / "crit" / "consigne.md").read_text(encoding="utf-8")
        attendre(code == 0 and noms == ["1-sans-texte-1440.png", "2-reduite-1440.png", "3-ecran-1440.png", "4-ecran-390.png",
                                        "5-mouvement.png", "6-contre-references.png"],
                 "critique : images seules, dans l'ordre de lecture, planches de mouvement et contre références comprises")
        attendre("« Une page propre »" in consigne and "ni l'intention" in consigne and not (d / "crit" / ".travail").exists(),
                 "critique : consigne avec la demande, sans direction ni trace ; dossier de travail retiré")
        with contextlib.redirect_stderr(io.StringIO()):
            attendre(parcours.main(["critique", str(d / "absente.html"), "--brief", "x"]) == 2, "critique : page introuvable, code 2")
        import functools, http.server, threading
        serveur = http.server.ThreadingHTTPServer(("127.0.0.1", 0), functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(d)))
        serveur.RequestHandlerClass.log_message = lambda *x: None
        threading.Thread(target=serveur.serve_forever, daemon=True).start()
        base = f"http://127.0.0.1:{serveur.server_address[1]}"
        try:
            sites = parcours.capturer_sites([f"{base}/propre.html", f"{base}/absente.html"], d, 1)
        finally:
            serveur.shutdown()
        attendre([s["statut"] for s in sites] == ["ok", "refusé (HTTP 404)"] and sites[0]["titre"] == "Propre" and (d / "1-site.png").is_file(),
                 "références : site capturé au premier écran avec son titre ; page refusée notée, sans capture")

    print(f"PARCOURS TESTS {'PASSED' if not echecs else 'FAILED'} — {n} cas")
    return 1 if echecs else 0


if __name__ == "__main__":
    sys.exit(main())
