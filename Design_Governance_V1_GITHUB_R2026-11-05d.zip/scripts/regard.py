#!/usr/bin/env python3
"""Regard : une fiche de regard par rendu HTML (commande à l'essai, `maintenance/versions.md`).

Quatre instruments, des signaux et non des verdicts :

1. Carte d'attention : où l'œil va d'abord, par largeur ; foyer déclaré (--foyer) comparé au foyer prédit.
   - Modèle visé : MSI-Net affiné sur UEyes (Foveacast, licence MIT), fourni en local avec
     --attention onnx:CHEMIN/model.onnx (entrée 1×3×240×320, RGB 0-255, letterbox 126).
   - Repli par défaut : approximation classique (contraste couleur + résidu spectral). Signal faible,
     dit comme tel dans la fiche.
2. Contraste du texte sur son fond réel : le texte est rendu transparent, la page est capturée, et
   le contraste se mesure contre les pixels les plus défavorables sous chaque ligne. Couvre les fonds
   en image, en dégradé, en voile ou en flou.
3. Captures de regard : page entière réduite (lecture d'ensemble) et page sans texte (test de support).
4. Marqueurs de vague : la liste datée de `SAVOIR/TOOLS/CONVERGENCE`, lue à son lieu actuel, dit quels marqueurs
   existent ; le script relève au premier écran de la première largeur ceux qu'il sait mesurer (pixels et styles
   calculés, table RELEVES) et nomme les autres. Un relevé aide à nommer le MODAL ; il n'interdit rien et ne
   prouve pas la singularité.

Usage :
  python3 scripts/regard.py page.html [--foyer "SELECTEUR"] [--largeurs 1440,390] [--sortie DOSSIER]
                              [--attention classique|onnx:CHEMIN] [--hauteur 900]
"""
from __future__ import annotations

import argparse
import datetime
import json
import math
import re
import sys
sys.dont_write_bytecode = True  # les imports entre outils n’écrivent rien dans le paquet
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage

CSS_GEL = "*,*::before,*::after{animation:none!important;transition:none!important;caret-color:transparent!important}"
CSS_SANS_TEXTE = ("*,*::before,*::after{color:transparent!important;-webkit-text-fill-color:transparent!important;"
                  "text-shadow:none!important;text-decoration-color:transparent!important}"
                  "svg text,svg tspan,svg textPath{fill:transparent!important;stroke:transparent!important}")

# ---------------------------------------------------------------- extraction dans la page

JS_TEXTES = r"""
() => {
  const cvs = document.createElement('canvas'); cvs.width = cvs.height = 1;
  const ctx = cvs.getContext('2d', {willReadFrequently: true});
  const rgba = (c) => { ctx.clearRect(0,0,1,1); ctx.fillStyle = '#000'; ctx.fillStyle = c; ctx.fillRect(0,0,1,1);
                        const d = ctx.getImageData(0,0,1,1).data; return [d[0], d[1], d[2], d[3]/255]; };
  const chemin = (el) => { const p = []; while (el && el.nodeType === 1 && p.length < 4) {
      let s = el.tagName.toLowerCase(); if (el.id) { s += '#' + el.id; p.unshift(s); break; }
      const c = [...el.classList].slice(0,2); if (c.length) s += '.' + c.join('.'); p.unshift(s); el = el.parentElement; }
    return p.join(' > '); };
  const opaciteEffective = (el) => { let o = 1; while (el) { o *= parseFloat(getComputedStyle(el).opacity || '1'); el = el.parentElement; } return o; };
  const out = []; const tw = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT); let n;
  while ((n = tw.nextNode())) {
    const t = n.textContent.replace(/\s+/g, ' ').trim(); if (!t) continue;
    const el = n.parentElement; if (!el) continue;
    const cs = getComputedStyle(el);
    if (cs.visibility !== 'visible') continue;
    const b = el.getBoundingClientRect(); if (b.width <= 2 || b.height <= 2) continue;   // texte réservé aux lecteurs d'écran
    const op = opaciteEffective(el); if (op < 0.05) continue;
    const r = document.createRange(); r.selectNodeContents(n);
    // conteneurs qui rognent (overflow) et rotation héritée
    const coupes = []; let tourne = false;
    for (let a = el; a && a !== document.documentElement; a = a.parentElement) {
      const ca = getComputedStyle(a);
      if (ca.overflowX !== 'visible' || ca.overflowY !== 'visible' || ca.clipPath !== 'none') coupes.push(a.getBoundingClientRect());
      if (ca.transform && ca.transform !== 'none') { const m = new DOMMatrixReadOnly(ca.transform); if (Math.abs(m.b) > 0.01 || Math.abs(m.c) > 0.01) tourne = true; }
    }
    let aireTot = 0, aireVis = 0;
    const rects = [...r.getClientRects()].filter(q => q.width > 2 && q.height > 4).map(q => {
      let x0 = q.left, y0 = q.top, x1 = q.right, y1 = q.bottom; aireTot += q.width * q.height;
      for (const c of coupes) { x0 = Math.max(x0, c.left); y0 = Math.max(y0, c.top); x1 = Math.min(x1, c.right); y1 = Math.min(y1, c.bottom); }
      const w = Math.max(0, x1 - x0), h = Math.max(0, y1 - y0); aireVis += w * h;
      return {x: x0 + scrollX, y: y0 + scrollY, w, h}; }).filter(q => q.w > 2 && q.h > 4);
    const rogne = aireTot > 0 && aireVis / aireTot < 0.5;
    if (!rects.length && !rogne) continue;
    let clip = (cs.backgroundClip === 'text' || cs.webkitBackgroundClip === 'text');
    let couleur = cs.color, remplissage = cs.webkitTextFillColor || cs.color;
    if (el instanceof SVGElement) {                     // texte SVG : la couleur vient de fill
      if (!cs.fill || cs.fill === 'none' || cs.fill.startsWith('url')) clip = true;
      else { couleur = cs.fill; remplissage = cs.fill; }
    }
    out.push({texte: t.slice(0, 70), chemin: chemin(el), couleur: rgba(couleur), remplissage: rgba(remplissage),
              taille: parseFloat(cs.fontSize), graisse: parseInt(cs.fontWeight) || 400, opacite: op, clip, rects, rogne, tourne});
  }
  return out;
}
"""

JS_ELEMENT_EN = r"""
([x, y]) => { const el = document.elementFromPoint(x, y); if (!el) return null;
  let s = el.tagName.toLowerCase(); const c = [...el.classList].slice(0,2); if (c.length) s += '.' + c.join('.');
  const t = (el.innerText || el.getAttribute('alt') || el.getAttribute('aria-label') || '').replace(/\s+/g,' ').trim().slice(0, 50);
  return {element: s, texte: t}; }
"""

JS_BOITE = r"""
(sel) => { const els = [...document.querySelectorAll(sel)]; return els.map(e => { const r = e.getBoundingClientRect();
  return {x: r.left, y: r.top, w: r.width, h: r.height}; }).filter(r => r.w > 0 && r.h > 0); }
"""

# ---------------------------------------------------------------- couleur et contraste


def lin(c):
    c = np.asarray(c, dtype=float) / 255.0
    return np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)


def luminance(rgb):
    lr = lin(rgb)
    return 0.2126 * lr[..., 0] + 0.7152 * lr[..., 1] + 0.0722 * lr[..., 2]


def ratio(l1, l2):
    hi, lo = max(l1, l2), min(l1, l2)
    return (hi + 0.05) / (lo + 0.05)


def seuil(taille, graisse):
    grand = taille >= 24 or (taille >= 18.66 and graisse >= 700)
    return 3.0 if grand else 4.5


def mesurer_contraste(textes, sans_texte: Image.Image):
    """Contraste de chaque texte contre les pixels du fond réel, capturés sans le texte."""
    arr = np.asarray(sans_texte.convert("RGB"))
    H, W, _ = arr.shape
    lum = luminance(arr)
    res = []
    for t in textes:
        if t["clip"] or t["remplissage"][3] < 0.05:
            res.append({**_id(t), "statut": "non évalué", "raison": "texte rempli par un dégradé, une image ou sans remplissage"})
            continue
        if t.get("rogne"):
            res.append({**_id(t), "statut": "non évalué", "raison": "texte rogné par son conteneur : moins de la moitié visible"})
            continue
        pix = []
        for r in t["rects"]:
            x0, y0 = max(0, int(r["x"]) + 1), max(0, int(r["y"]) + 1)
            x1, y1 = min(W, int(r["x"] + r["w"]) - 1), min(H, int(r["y"] + r["h"]) - 1)
            if x1 > x0 and y1 > y0:
                pix.append(lum[y0:y1, x0:x1].ravel())
        if not pix:
            res.append({**_id(t), "statut": "non évalué", "raison": "hors capture"})
            continue
        fond = np.concatenate(pix)
        coul = np.array(t["couleur"][:3], dtype=float)
        alpha = t["couleur"][3] * t["opacite"]
        med = float(np.median(fond))
        # texte translucide : mélange avec le fond médian
        if alpha < 0.999:
            fond_rgb = np.full(3, 255.0 * (med ** (1 / 2.2)))
            coul = alpha * coul + (1 - alpha) * fond_rgb
        lt = float(luminance(coul[None, :])[0])
        # texte tourné : sa boîte droite déborde de son fond réel, on lit aux quartiles plutôt qu'aux déciles
        bas, haut = (25, 75) if t.get("tourne") else (5, 95)
        p5, p95 = float(np.percentile(fond, bas)), float(np.percentile(fond, haut))
        pire = min(ratio(lt, p5), ratio(lt, p95))
        heterogene = (p95 - p5) > 0.08
        s = seuil(t["taille"], t["graisse"])
        res.append({**_id(t), "statut": "mesuré", "pire": round(pire, 2), "median": round(ratio(lt, med), 2),
                    "seuil": s, "sous_seuil": pire < s, "fond_heterogene": bool(heterogene), "tourne": bool(t.get("tourne")),
                    "boite": _boite(t["rects"])})
    return res


def _id(t):
    return {"texte": t["texte"], "chemin": t["chemin"], "taille": round(t["taille"], 1)}


def _boite(rects):
    x0 = min(r["x"] for r in rects); y0 = min(r["y"] for r in rects)
    x1 = max(r["x"] + r["w"] for r in rects); y1 = max(r["y"] + r["h"] for r in rects)
    return [round(x0), round(y0), round(x1 - x0), round(y1 - y0)]

# ---------------------------------------------------------------- attention


def _lab(img):
    a = lin(img * 255.0)
    M = np.array([[0.4124, 0.3576, 0.1805], [0.2126, 0.7152, 0.0722], [0.0193, 0.1192, 0.9505]])
    xyz = a @ M.T / np.array([0.95047, 1.0, 1.08883])
    f = np.where(xyz > 0.008856, np.cbrt(xyz), 7.787 * xyz + 16 / 116)
    return np.stack([116 * f[..., 1] - 16, 500 * (f[..., 0] - f[..., 1]), 200 * (f[..., 1] - f[..., 2])], -1)


def _norm(s):
    s = s - s.min()
    m = s.max()
    return s / m if m > 0 else s


def attention_classique(img: Image.Image) -> np.ndarray:
    """Approximation : contraste couleur global (Achanta 2009) + résidu spectral (Hou et Zhang 2007).
    Ne modélise ni la lecture ni l'apprentissage des interfaces : signal faible."""
    W, H = img.size
    w = 320
    h = max(1, round(H * w / W))
    petit = np.asarray(img.convert("RGB").resize((w, h), Image.BILINEAR), dtype=float) / 255.0
    lab = _lab(petit)
    ft = np.linalg.norm(ndimage.gaussian_filter(lab, sigma=(1.5, 1.5, 0)) - lab.reshape(-1, 3).mean(0), axis=-1)
    gris = petit.mean(-1)
    g64 = np.asarray(Image.fromarray((gris * 255).astype(np.uint8)).resize((64, max(1, round(64 * h / w))), Image.BILINEAR), dtype=float)
    F = np.fft.fft2(g64)
    log_amp = np.log(np.abs(F) + 1e-9)
    resid = log_amp - ndimage.uniform_filter(log_amp, size=3)
    sr = np.abs(np.fft.ifft2(np.exp(resid + 1j * np.angle(F)))) ** 2
    sr = ndimage.gaussian_filter(sr, 2.5)
    sr = np.asarray(Image.fromarray((_norm(sr) * 255).astype(np.uint8)).resize((w, h), Image.BILINEAR), dtype=float) / 255
    s = 0.6 * _norm(ft) + 0.4 * sr
    yy, xx = np.mgrid[0:h, 0:w]
    prior = np.exp(-(((xx - w * 0.45) / (0.6 * w)) ** 2 + ((yy - h * 0.4) / (0.6 * h)) ** 2))   # biais centre-haut des écrans
    s = _norm(ndimage.gaussian_filter(s * (0.7 + 0.3 * prior), sigma=w * 0.015))
    return np.asarray(Image.fromarray((s * 255).astype(np.uint8)).resize((W, H), Image.BILINEAR), dtype=float) / 255.0


def attention_onnx(img: Image.Image, chemin: str) -> np.ndarray:
    """MSI-Net affiné sur UEyes (contrat Foveacast V3) : entrée 1×3×240×320 RGB 0-255, letterbox 126."""
    import onnxruntime as ort
    W, H = img.size
    dh, dw = 240, 320
    sc = min(dh / H, dw / W)
    sh, sw = max(1, round(H * sc)), max(1, round(W * sc))
    top, left = (dh - sh) // 2, (dw - sw) // 2
    toile = np.full((dh, dw, 3), 126.0, dtype=np.float32)
    toile[top:top + sh, left:left + sw] = np.asarray(img.convert("RGB").resize((sw, sh), Image.BILINEAR), dtype=np.float32)
    x = toile.transpose(2, 0, 1)[None]
    sess = ort.InferenceSession(chemin, providers=["CPUExecutionProvider"])
    nom = sess.get_inputs()[0].name
    y = np.asarray(sess.run(None, {nom: x})[0], dtype=float)
    y = y.reshape(y.shape[-2], y.shape[-1])
    if y.shape != (dh, dw):
        y = np.asarray(Image.fromarray(_norm(y).astype(np.float32)).resize((dw, dh), Image.BILINEAR))
    y = y[top:top + sh, left:left + sw]
    y = np.asarray(Image.fromarray(_norm(y).astype(np.float32)).resize((W, H), Image.BILINEAR), dtype=float)
    return _norm(ndimage.gaussian_filter(y, 5))


def zones(sal: np.ndarray, n=4):
    """Zones d'attention : 10 % des pixels les plus saillants, regroupés ; part de la masse d'attention."""
    seuil_v = np.percentile(sal, 90)
    lab, k = ndimage.label(sal >= seuil_v)
    total = float(sal.sum()) or 1.0
    out = []
    for i in range(1, k + 1):
        m = lab == i
        part = float(sal[m].sum()) / total
        ys, xs = np.nonzero(m)
        cy, cx = ndimage.center_of_mass(sal * m)
        out.append({"part": part, "boite": [int(xs.min()), int(ys.min()), int(xs.max() - xs.min() + 1), int(ys.max() - ys.min() + 1)],
                    "centre": [int(cx), int(cy)]})
    out.sort(key=lambda z: -z["part"])
    return out[:n]


def part_dans(sal, boites):
    if not boites:
        return None
    H, W = sal.shape
    m = np.zeros_like(sal, dtype=bool)
    for b in boites:
        x0, y0 = max(0, int(b["x"])), max(0, int(b["y"]))
        x1, y1 = min(W, int(b["x"] + b["w"])), min(H, int(b["y"] + b["h"]))
        m[y0:y1, x0:x1] = True
    aire = m.mean()
    part = float(sal[m].sum() / (sal.sum() or 1))
    return {"part": part, "aire": float(aire), "levier": part / aire if aire else 0.0}


def superposer(img: Image.Image, sal: np.ndarray, zs, foyer_boites=None) -> Image.Image:
    base = img.convert("RGB")
    a = np.clip(sal, 0, 1)
    rgb = np.stack([np.ones_like(a), np.clip(1.6 - 1.6 * a, 0, 1) * 0.9, np.clip(0.6 - 1.2 * a, 0, 1)], -1) * 255
    calque = Image.fromarray(rgb.astype(np.uint8))
    masque = Image.fromarray((np.clip(a, 0, 1) ** 1.2 * 170).astype(np.uint8))
    out = base.copy()
    out.paste(calque, (0, 0), masque)
    d = ImageDraw.Draw(out)
    for i, z in enumerate(zs, 1):
        x, y, w, h = z["boite"]
        d.rectangle([x, y, x + w, y + h], outline=(20, 20, 20), width=2)
        d.rectangle([x, y, x + 22, y + 18], fill=(20, 20, 20))
        d.text((x + 6, y + 3), str(i), fill=(255, 255, 255))
    for b in foyer_boites or []:
        d.rectangle([b["x"], b["y"], b["x"] + b["w"], b["y"] + b["h"]], outline=(30, 90, 220), width=3)
    return out

# ---------------------------------------------------------------- marqueurs de vague (SAVOIR/TOOLS/CONVERGENCE)

ROUTE_MARQUEURS = "SAVOIR/TOOLS/CONVERGENCE"

# Relevé dans la page, avant le gel des animations : titres, texte courant, actions et grandes surfaces du premier
# écran, cartes sœurs, bandeaux animés, blocs préformatés, petits libellés à chasse fixe.
JS_MARQUEURS = r"""
() => {
  const vw = innerWidth, vh = innerHeight, aireEcran = vw * vh;
  const cvs = document.createElement('canvas'); cvs.width = cvs.height = 1;
  const ctx = cvs.getContext('2d', {willReadFrequently: true});
  const rgba = (c) => { ctx.clearRect(0,0,1,1); ctx.fillStyle = '#000'; ctx.fillStyle = c; ctx.fillRect(0,0,1,1);
                        const d = ctx.getImageData(0,0,1,1).data; return [d[0], d[1], d[2], d[3]/255]; };
  const chemin = (el) => { let s = el.tagName.toLowerCase(); if (el.id) return s + '#' + el.id;
    const c = [...el.classList].slice(0,2); return c.length ? s + '.' + c.join('.') : s; };
  const visible = (el) => { const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility !== 'visible' || parseFloat(cs.opacity) < 0.05) return false;
    const r = el.getBoundingClientRect(); return r.width > 1 && r.height > 1; };
  const auPremier = (r) => r.top < vh && r.bottom > 0 && r.left < vw && r.right > 0;
  const familles = (cs) => cs.fontFamily.split(',').map(f => f.trim().replace(/^["']|["']$/g, '').toLowerCase()).filter(Boolean);
  const direct = (el) => [...el.childNodes].filter(n => n.nodeType === 3).map(n => n.textContent).join(' ').replace(/\s+/g, ' ').trim();
  const desc = (el) => ({chemin: chemin(el), texte: (direct(el) || (el.innerText || '')).replace(/\s+/g, ' ').trim().slice(0, 40)});
  const tous = [...document.body.querySelectorAll('*')].filter(e => !(e instanceof SVGElement));
  const textes = tous.filter(e => direct(e) && visible(e));
  let grand = null, tg = 0;
  for (const e of textes) { if (!auPremier(e.getBoundingClientRect())) continue;
    const t = parseFloat(getComputedStyle(e).fontSize); if (t > tg) { tg = t; grand = e; } }
  const titres = [...new Set([...document.querySelectorAll('h1,h2,h3')].filter(visible).concat(grand ? [grand] : []))];
  const out = {largeur: vw, hauteur: vh};
  out.titres = titres.map(e => { const cs = getComputedStyle(e); return {...desc(e), balise: e.tagName.toLowerCase(), taille: parseFloat(cs.fontSize),
    familles: familles(cs), italique: cs.fontStyle !== 'normal', couleur: rgba(cs.color), centre: cs.textAlign === 'center',
    premier: auPremier(e.getBoundingClientRect()), clip: cs.backgroundClip === 'text' || cs.webkitBackgroundClip === 'text',
    image: cs.backgroundImage, graisse: parseInt(cs.fontWeight) || 400,
    capitales: cs.textTransform === 'uppercase' || (/\p{L}{3}/u.test(direct(e)) && direct(e) === direct(e).toUpperCase())}; });
  out.courants = textes.filter(e => e.matches('p,li,dd,td,blockquote,label')).slice(0, 60)
    .map(e => ({...desc(e), familles: familles(getComputedStyle(e))}));
  out.actions = [...document.querySelectorAll('a,button,[role=button],input[type=submit]')]
    .filter(e => visible(e) && auPremier(e.getBoundingClientRect())).slice(0, 20)
    .map(e => { const cs = getComputedStyle(e); return {...desc(e), fond: rgba(cs.backgroundColor), couleur: rgba(cs.color)}; });
  out.surfaces = [];
  for (const e of [document.documentElement, document.body, ...tous]) {
    if (e !== document.documentElement && e !== document.body && !visible(e)) continue;
    const r = e.getBoundingClientRect(), cs = getComputedStyle(e);
    const part = Math.max(0, Math.min(vw, r.right) - Math.max(0, r.left)) * Math.max(0, Math.min(vh, r.bottom) - Math.max(0, r.top)) / aireEcran;
    if (part <= 0) continue;
    const degrade = cs.backgroundImage.includes('gradient'), ombre = cs.boxShadow !== 'none';
    const flou = parseFloat((cs.filter.match(/blur\(([\d.]+)px\)/) || [0, 0])[1]);
    if (part >= 0.15 || (degrade && part >= 0.01) || ombre || flou > 0)
      out.surfaces.push({...desc(e), part, fond: rgba(cs.backgroundColor), image: cs.backgroundImage,
                         ombre: ombre ? cs.boxShadow : '', flou});
    if (out.surfaces.length >= 120) break;
  }
  // Fond de page : sur une grille de points, premier fond opaque d'un ancêtre qui couvre presque toute la largeur
  // (section ou page), sans image ; un panneau, une carte ou un appareil plus étroit n'est pas le fond.
  const fonds = {};
  for (let i = 1; i < 12; i++) for (let j = 1; j < 8; j++) {
    let e = document.elementFromPoint(vw * i / 12, vh * j / 8), c = null, image = false;
    for (; e && e !== document.documentElement; e = e.parentElement) {
      const r = e.getBoundingClientRect(), cs = getComputedStyle(e);
      if (r.width < 0.9 * vw) continue;
      if (cs.backgroundImage !== 'none') { image = true; break; }
      const f = rgba(cs.backgroundColor); if (f[3] >= 0.95) { c = f; break; }
    }
    if (image) continue;
    if (!c) { // canevas : fond de html, sinon celui de body qui s’y propage, sinon blanc
      const h = rgba(getComputedStyle(document.documentElement).backgroundColor), b = rgba(getComputedStyle(document.body).backgroundColor);
      c = h[3] >= 0.95 ? h : b[3] >= 0.95 ? b : [255, 255, 255, 1]; }
    const k = c.slice(0, 3).join(','); fonds[k] = (fonds[k] || 0) + 1;
  }
  const kf = Object.keys(fonds).sort((a, b) => fonds[b] - fonds[a]);
  out.fond = kf.length ? kf[0].split(',').map(Number) : null;
  out.cartes = [];
  const marquee = (c) => { const cs = getComputedStyle(c);
    return (parseFloat(cs.borderTopWidth) > 0 && rgba(cs.borderTopColor)[3] > 0.05) || rgba(cs.backgroundColor)[3] > 0.05 || cs.boxShadow !== 'none'; };
  for (const p of tous) {
    const enfants = [...p.children].filter(visible);
    if (enfants.length < 3) continue;
    const rs = enfants.map(c => c.getBoundingClientRect());
    const idx = enfants.map((c, i) => i).filter(i => rs[i].width > 80 && rs[i].width < 0.6 * vw
      && marquee(enfants[i]) && enfants[i].querySelector('h2,h3,h4,h5,strong,b'));
    if (idx.length < 3) continue;
    const med = (v) => v.slice().sort((a, b) => a - b)[Math.floor(v.length / 2)];
    const mw = med(idx.map(i => rs[i].width)), mh = med(idx.map(i => rs[i].height));
    const memes = idx.filter(i => Math.abs(rs[i].width - mw) <= 0.12 * mw && Math.abs(rs[i].height - mh) <= 0.12 * mh);
    if (memes.length >= 3) out.cartes.push({parent: chemin(p), n: memes.length, carte: chemin(enfants[memes[0]])});
  }
  out.bandeaux = [...document.querySelectorAll('marquee')].filter(visible).map(e => ({...desc(e), source: 'marquee'}));
  const horizontal = (t) => { const m = String(t).match(/translateX\(\s*(-?[\d.]+)/) || String(t).match(/translate(?:3d)?\(\s*(-?[\d.]+)/)
    || String(t).match(/^\s*(-?[\d.]+)(px|%)/); return !!m && parseFloat(m[1]) !== 0; };
  for (const a of (document.getAnimations ? document.getAnimations() : [])) {
    const ef = a.effect; if (!ef || !ef.target || !ef.getComputedTiming) continue;
    if (ef.getComputedTiming().iterations !== Infinity) continue;
    let kf = []; try { kf = ef.getKeyframes(); } catch (err) { continue; }
    if (!kf.some(k => horizontal(k.transform || '') || horizontal(k.translate || ''))) continue;
    if (ef.target.getBoundingClientRect().width < 0.5 * vw) continue;
    out.bandeaux.push({...desc(ef.target), source: 'animation ' + (a.animationName || '')});
  }
  out.ascii = [...document.querySelectorAll('pre')].filter(visible).map(e => { const t = e.textContent;
      const nonblanc = (t.match(/\S/g) || []).length, signes = (t.match(/[^\p{L}\p{N}\s]/gu) || []).length;
      const boites = (t.match(/[─-▟⠀-⣿]/g) || []).length;
      return {...desc(e), nonblanc, signes, boites}; })
    .filter(x => x.nonblanc >= 30 && (x.signes / x.nonblanc >= 0.5 || x.boites >= 10));
  const MONO = /mono|code|courier|consolas|menlo|monaco|terminal|fixedsys/;
  out.mono = textes.filter(e => !e.closest('pre,code,kbd,samp')).filter(e => {
    const cs = getComputedStyle(e), f = familles(cs)[0] || '', lettres = direct(e).replace(/[^\p{L}]/gu, '');
    const caps = cs.textTransform === 'uppercase' || (lettres.length >= 2 && lettres === lettres.toUpperCase());
    return MONO.test(f) && caps && lettres.length >= 2 && parseFloat(cs.fontSize) <= 15; }).slice(0, 12).map(desc);
  return out;
}
"""

# [À ADAPTER] Points de départ des relevés, à recalibrer sur des rendus réels : teinte (degrés), saturation et valeur (HSV).
TEINTES = {
    "violet": ((238, 300), (0.30, 1.0), (0.25, 1.0)),
    "brun": ((12, 42), (0.35, 1.0), (0.12, 0.50)),
    "rouille": ((8, 30), (0.55, 1.0), (0.50, 0.86)),
    "bleu-klein": ((220, 233), (0.85, 1.0), (0.45, 0.78)),
}
PART_ECRAN = {"violet": 0.05, "brun": 0.02, "rouille": 0.01, "bleu-klein": 0.02}   # part du premier écran
SERIFS = ("georgia", "times", "garamond", "baskerville", "caslon", "bodoni", "didot", "playfair", "fraunces", "lora",
          "merriweather", "cormorant", "crimson", "newsreader", "spectral", "literata", "libre caslon", "instrument serif",
          "dm serif", "pt serif", "source serif", "noto serif", "ibm plex serif", "gt sectra", "tiempos", "canela", "recoleta")
INTER = re.compile(r"^inter($| |variable|tight|display)")


def hsv(rgb) -> tuple:
    """Teinte en degrés, saturation et valeur (0-1), pour un tableau de couleurs 0-255 (dernier axe RGB)."""
    a = np.asarray(rgb, dtype=float)[..., :3] / 255.0
    mx, mn = a.max(-1), a.min(-1)
    d = mx - mn
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    with np.errstate(invalid="ignore", divide="ignore"):
        h = np.where(d == 0, 0.0,
                     np.where(mx == r, ((g - b) / d) % 6, np.where(mx == g, (b - r) / d + 2, (r - g) / d + 4))) * 60.0
        s = np.where(mx == 0, 0.0, d / mx)
    return h, s, mx


def dans_teinte(rgb, nom: str):
    (h0, h1), (s0, s1), (v0, v1) = TEINTES[nom]
    h, s, v = hsv(rgb)
    return (h >= h0) & (h <= h1) & (s >= s0) & (s <= s1) & (v >= v0) & (v <= v1)


def chromatique(c) -> bool:
    """Couleur [r, g, b, a] visible et colorée."""
    _, s, v = hsv(c[:3])
    return len(c) > 3 and c[3] >= 0.15 and float(s) >= 0.25 and float(v) >= 0.2


def couleurs_css(texte: str) -> list[list[float]]:
    """Couleurs rgb()/rgba() d'une valeur calculée (dégradé, ombre) ; alpha 1 par défaut."""
    out = []
    for m in re.findall(r"rgba?\(([^)]*)\)", texte or ""):
        v = [float(x) for x in re.split(r"[,\s/]+", m.strip()) if x]
        if len(v) >= 3:
            out.append(v[:3] + [v[3] if len(v) > 3 else 1.0])
    return out


def pixels_ecran(img: Image.Image) -> dict:
    """Parts de teintes sur le premier écran et couleur dominante (cases de 16 niveaux par canal)."""
    w = 320
    petit = np.asarray(img.convert("RGB").resize((w, max(1, round(img.size[1] * w / img.size[0]))), Image.BILINEAR))
    px = petit.reshape(-1, 3)
    _, s, v = hsv(px)
    colores = (s >= 0.25) & (v >= 0.2)
    parts = {nom: float(dans_teinte(px, nom).mean()) for nom in TEINTES}
    cases = (px // 16).astype(int)
    cle = cases[:, 0] * 256 + cases[:, 1] * 16 + cases[:, 2]
    valeurs, comptes = np.unique(cle, return_counts=True)
    dominante = valeurs[comptes.argmax()]
    teintes_colores = hsv(px[colores])[0] if colores.any() else np.array([])
    hist = np.histogram(teintes_colores, bins=36, range=(0, 360))[0] if teintes_colores.size else np.zeros(36)
    return {"parts": parts, "colores": float(colores.mean()),
            "accent_teinte": float(hist.argmax() * 10 + 5) if hist.sum() else None,
            "violet_parmi_colores": float(dans_teinte(px[colores], "violet").mean()) if colores.any() else 0.0,
            "dominante": [round(float(x)) for x in px[cle == dominante].mean(0)],
            "dominante_part": float(comptes.max() / len(cle))}


def _nom(x) -> str:
    return f"`{x['chemin']}`" + (f" « {x['texte']} »" if x.get("texte") else "")


def _couleurs_portees(js: dict, nom: str) -> list[str]:
    """Titres, actions et grands fonds du premier écran dont la couleur tombe dans la teinte."""
    preuves = []
    for t in js.get("titres", []):
        if t["premier"] and t["couleur"][3] >= 0.5 and bool(dans_teinte(t["couleur"], nom)):
            preuves.append(f"titre {_nom(t)}")
    for a in js.get("actions", []):
        if a["fond"][3] >= 0.5 and bool(dans_teinte(a["fond"], nom)):
            preuves.append(f"fond de l'action {_nom(a)}")
    for s in js.get("surfaces", []):
        if s["part"] >= 0.15 and s["fond"][3] >= 0.5 and bool(dans_teinte(s["fond"], nom)):
            preuves.append(f"fond de `{s['chemin']}` ({s['part']*100:.0f} % du premier écran)")
    return preuves[:4]


def _teinte(nom: str):
    def detecter(js, px):
        preuves = []
        part = px["parts"][nom]
        if part >= PART_ECRAN[nom]:
            preuves.append(f"{part*100:.0f} % des pixels du premier écran")
        elif nom == "violet" and px["colores"] >= 0.03 and px["violet_parmi_colores"] >= 0.30:
            preuves.append(f"{px['violet_parmi_colores']*100:.0f} % des pixels colorés du premier écran")
        return preuves + _couleurs_portees(js, nom)
    return detecter


def _inter(js, px):
    els = [x for x in js.get("titres", []) + js.get("courants", []) if x["familles"] and INTER.match(x["familles"][0])]
    return [f"Inter en tête de pile sur {', '.join(_nom(x) for x in els[:3])}"] if els else []


def _halo(js, px):
    preuves = []
    for t in js.get("titres", []):
        if t["clip"] and "gradient" in t["image"]:
            preuves.append(f"titre rempli par un dégradé : {_nom(t)}")
    for s in js.get("surfaces", []):
        colore = any(chromatique(c) for c in couleurs_css(s["image"]))
        if "gradient" in s["image"] and colore and (s["part"] >= 0.15 or ("radial" in s["image"] and s["part"] >= 0.03)):
            genre = "radial" if "radial" in s["image"] else "linéaire"
            preuves.append(f"dégradé {genre} coloré sur `{s['chemin']}` ({s['part']*100:.0f} % du premier écran)")
        for m in re.finditer(r"(rgba?\([^)]*\))\s+(-?[\d.]+)px\s+(-?[\d.]+)px\s+([\d.]+)px", s.get("ombre", "")):
            if float(m.group(4)) >= 40 and any(chromatique(c) for c in couleurs_css(m.group(1))):
                preuves.append(f"ombre colorée diffuse ({float(m.group(4)):.0f} px) sur `{s['chemin']}`")
                break
        if s.get("flou", 0) >= 30 and (chromatique(s["fond"]) or colore):
            preuves.append(f"forme colorée floutée ({s['flou']:.0f} px) : `{s['chemin']}`")
    return preuves[:5]


def _hero_cartes(js, px):
    heros = [t for t in js.get("titres", []) if t["premier"] and t["centre"] and t["taille"] >= 32]
    cartes = js.get("cartes", [])
    if not (heros and cartes):
        return []
    c = max(cartes, key=lambda x: x["n"])
    return [f"grand titre centré au premier écran : {_nom(heros[0])}",
            f"{c['n']} cartes sœurs de même taille (`{c['carte']}` dans `{c['parent']}`)"]


def _fond_creme(js, px):
    h, s, v = (float(x) for x in hsv(px["dominante"]))
    if px["dominante_part"] >= 0.30 and 20 <= h <= 60 and 0.04 <= s <= 0.30 and v >= 0.82:
        r, g, b = px["dominante"]
        return [f"couleur dominante #{r:02x}{g:02x}{b:02x} sur {px['dominante_part']*100:.0f} % du premier écran"]
    return []


def _serif(js, px):
    preuves = []
    for t in js.get("titres", []):
        if t["taille"] < 28:
            continue
        f = t["familles"]
        tete = f[0] if f else ""
        serif = tete in ("serif", "ui-serif") or any(tete.startswith(n) for n in SERIFS) or \
            ("serif" in tete and "sans" not in tete) or (f and f[-1] in ("serif", "ui-serif") and "sans" not in tete)
        if serif:
            preuves.append(f"titre en serif ({tete}) : {_nom(t)}")
        if t["italique"]:
            preuves.append(f"titre en italique : {_nom(t)}")
    return preuves[:4]


def _bandeau(js, px):
    return [f"{b['source'].strip()} : {_nom(b)}" for b in js.get("bandeaux", [])[:3]]


def _ascii(js, px):
    return [f"bloc préformaté fait de signes : `{a['chemin']}`" for a in js.get("ascii", [])[:3]]


def _mono(js, px):
    m = js.get("mono", [])
    return [f"{len(m)} libellés mono en capitales, dont {', '.join(_nom(x) for x in m[:3])}"] if len(m) >= 3 else []


DETECTEURS = {
    "violet": _teinte("violet"), "inter": _inter, "halo-degrade": _halo, "hero-cartes": _hero_cartes,
    "fond-creme": _fond_creme, "brun": _teinte("brun"), "serif-titre": _serif, "rouille": _teinte("rouille"),
    "bandeau-defilant": _bandeau, "ascii": _ascii, "bleu-klein": _teinte("bleu-klein"), "mono-capitales": _mono,
}
# Marqueur, tel que nommé par la liste datée de SAVOIR/TOOLS/CONVERGENCE → relevé du script. La liste fait foi :
# un marqueur qu'elle ne nomme plus n'est plus relevé (le test le signale), un marqueur absent d'ici est « non mesuré ».
RELEVES = {
    "violet": "violet", "police Inter": "inter", "halos et gradient décoratif": "halo-degrade",
    "hero SaaS à cartes répétées": "hero-cartes", "fond beige ou crème": "fond-creme", "brun": "brun",
    "serif de caractère ou serif italique": "serif-titre", "orange rouille": "rouille", "bandeau défilant": "bandeau-defilant",
    "ASCII": "ascii", "bleu Klein": "bleu-klein", "libellés mono en capitales": "mono-capitales",
}


def analyser_marqueurs(texte: str) -> dict:
    """Ligne [VEILLE AAAA-MM] des marqueurs de vague : « Vague N : a, b, c. », puis son échéance de revue."""
    ligne = next((l for l in texte.splitlines() if l.startswith("[VEILLE ") and "**Marqueurs de vague**" in l), "")
    marqueurs = []
    for vague, liste in re.findall(r"Vague (\d+) : ([^.]+)\.", ligne):
        for nom in (n.strip() for n in liste.split(",")):
            if nom:
                marqueurs.append({"vague": vague, "nom": nom, "id": RELEVES.get(nom)})
    ech = re.findall(r"À revoir avant (\d{4}-\d{2})", ligne)
    veille = re.findall(r"^\[VEILLE (\d{4}-\d{2})\]", ligne)
    return {"marqueurs": marqueurs, "echeance": ech[-1] if ech else None, "veille": veille[0] if veille else None}


def lire_marqueurs() -> dict | None:
    """Lit la liste à son lieu actuel (lecteur de routes) ; None si elle est introuvable : rien n'est deviné."""
    try:
        import read_route
        _, lignes, index = read_route.resolve(ROUTE_MARQUEURS)
        liste = analyser_marqueurs("\n".join(read_route.extract(lignes, index)))
    except Exception:
        return None
    return liste if liste["marqueurs"] else None


def echeance_passee(echeance: str | None, jour: datetime.date | None = None) -> bool:
    """« À revoir avant AAAA-MM » : passée dès le premier jour de ce mois."""
    if not echeance:
        return False
    a, m = (int(x) for x in echeance.split("-"))
    return (jour or datetime.date.today()) >= datetime.date(a, m, 1)


def relever_marqueurs(js: dict, px: dict, liste: dict | None, jour: datetime.date | None = None) -> dict:
    if liste is None:
        return {"route": ROUTE_MARQUEURS, "lisible": False}
    out = {"route": ROUTE_MARQUEURS, "lisible": True, "veille": liste["veille"], "echeance": liste["echeance"],
           "perimee": echeance_passee(liste["echeance"], jour), "presents": [], "absents": [], "non_mesures": []}
    for m in liste["marqueurs"]:
        if m["id"] is None:
            out["non_mesures"].append(m["nom"])
        else:
            preuves = DETECTEURS[m["id"]](js, px)
            (out["presents"].append({**m, "preuves": preuves}) if preuves else out["absents"].append(m["nom"]))
    return out

# ---------------------------------------------------------------- antécédent (DIRECTION/FIRST-OBJECT, « Réutilisation située »)

def _lab1(rgb):
    return _lab(np.asarray(rgb, dtype=float)[None, None, :] / 255.0)[0, 0]


def profil_visuel(js: dict, px: dict) -> dict:
    """Champs visibles de l'antécédent : paire typographique (titre = h1 du premier écran, sinon le plus grand texte),
    teinte dominante (fond de page mesuré, sinon couleur dominante des pixels), registre (clair/sombre, casse, graisse, accent)."""
    titres = [t for t in js.get("titres", []) if t.get("premier")] or js.get("titres", [])
    h1 = [t for t in titres if t.get("balise") == "h1"]  # le titre est le h1 ; à défaut, le plus grand texte
    t = max(h1 or titres, key=lambda x: x["taille"]) if titres else None
    corps = [c["familles"][0] for c in js.get("courants", []) if c.get("familles")]
    corps_f = max(set(corps), key=corps.count) if corps else None
    dominante = js.get("fond") or px["dominante"]  # fond de page mesuré ; à défaut, couleur dominante des pixels
    lab = _lab1(dominante)
    return {"titre": t["familles"][0] if t and t["familles"] else None, "corps": corps_f,
            "dominante": dominante, "lab": [float(x) for x in lab], "clair": bool(lab[0] >= 55),
            "capitales": bool(t and t.get("capitales")), "graisse": t.get("graisse") if t else None,
            "accent": px.get("accent_teinte") if px.get("colores", 0) >= 0.02 else None}


def comparer_antecedent(actuel: dict, ancien: dict) -> dict:
    """Repris ou différent, champ par champ ; seuils `[À ADAPTER]` (écart de couleur ΔE 10, teinte d'accent 20°, graisse 100)."""
    hexa = lambda c: "#%02x%02x%02x" % tuple(c)
    repris, diff = [], []
    paire = (actuel["titre"], actuel["corps"]), (ancien["titre"], ancien["corps"])
    beau = lambda f: " ".join(w.capitalize() for w in f.split()) if f else "?"
    nom = lambda p: f"{beau(p[0])} / {beau(p[1])}"
    if paire[0] == paire[1]:
        repris.append(f"paire typographique ({nom(paire[0])})")
    elif paire[0][0] == paire[1][0] or paire[0][1] == paire[1][1]:
        repris.append(f"paire typographique en partie ({nom(paire[0])} ; avant : {nom(paire[1])})")
    else:
        diff.append(f"paire typographique ({nom(paire[0])} ; avant : {nom(paire[1])})")
    de = float(np.linalg.norm(np.array(actuel["lab"]) - np.array(ancien["lab"])))
    (repris if de < 10 else diff).append(f"teinte dominante ({hexa(actuel['dominante'])} ; avant : {hexa(ancien['dominante'])}, écart {de:.0f})")
    reg = lambda p: f"titre {'en capitales' if p['capitales'] else 'en bas de casse'}, graisse {p['graisse']}, fond {'clair' if p['clair'] else 'sombre'}"
    meme_reg = (actuel["capitales"] == ancien["capitales"] and actuel["clair"] == ancien["clair"]
                and actuel["graisse"] is not None and ancien["graisse"] is not None and abs(actuel["graisse"] - ancien["graisse"]) <= 100)
    (repris if meme_reg else diff).append(f"registre ({reg(actuel)} ; avant : {reg(ancien)})")
    a, b = actuel["accent"], ancien["accent"]
    if a is not None and b is not None:
        ecart = min(abs(a - b), 360 - abs(a - b))
        (repris if ecart <= 20 else diff).append(f"teinte d'accent (vers {a:.0f}° ; avant : vers {b:.0f}°)")
    return {"repris": repris, "differents": diff}


def relever_page(nav, page_html: Path, L: int, h: int, sortie: Path, nom: str):
    """Styles et pixels du premier écran d'une page, sans gel préalable (pour le profil et les marqueurs)."""
    ctx = nav.new_context(viewport={"width": L, "height": h}, device_scale_factor=1)
    page = ctx.new_page()
    page.goto(page_html.resolve().as_uri(), wait_until="load")
    page.wait_for_timeout(300)
    js = page.evaluate(JS_MARQUEURS)
    page.add_style_tag(content=CSS_GEL)
    page.wait_for_timeout(200)
    px = pixels_ecran(Image.open(_capture(page, sortie / nom, full=False)))
    ctx.close()
    return js, px

# ---------------------------------------------------------------- rendu et fiche


def regarder(page_html: Path, sortie: Path, largeurs, hauteur, foyer, mode_attention, antecedent: Path | None = None):
    from playwright.sync_api import sync_playwright
    sortie.mkdir(parents=True, exist_ok=True)
    fiche = {"page": page_html.name, "attention_modele": mode_attention, "largeurs": {}}
    liste = lire_marqueurs()
    with sync_playwright() as p:
        nav = p.chromium.launch()
        for n, L in enumerate(largeurs):
            h = hauteur if L >= 700 else 844
            ctx = nav.new_context(viewport={"width": L, "height": h}, device_scale_factor=1)
            page = ctx.new_page()
            page.goto(page_html.resolve().as_uri(), wait_until="load")
            if n == 0:   # 4. marqueurs de vague : styles relevés avant le gel des animations
                page.wait_for_timeout(300)
                js_marqueurs = page.evaluate(JS_MARQUEURS)
            page.add_style_tag(content=CSS_GEL)
            page.wait_for_timeout(400)
            # 1. attention, premier écran
            ecran = Image.open(_capture(page, sortie / f"ecran-{L}.png", full=False))
            if n == 0:
                px0 = pixels_ecran(ecran)
                fiche["marqueurs"] = {"largeur": L, **relever_marqueurs(js_marqueurs, px0, liste)}
                if antecedent is not None:
                    js_a, px_a = relever_page(nav, antecedent, L, h, sortie, f"antecedent-{L}.png")
                    fiche["antecedent"] = {"page": antecedent.name, "largeur": L,
                                           **comparer_antecedent(profil_visuel(js_marqueurs, px0), profil_visuel(js_a, px_a))}
            sal = attention_onnx(ecran, mode_attention[5:]) if mode_attention.startswith("onnx:") else attention_classique(ecran)
            zs = zones(sal)
            for z in zs:
                z["sous"] = page.evaluate(JS_ELEMENT_EN, z["centre"])
            foyer_boites = page.evaluate(JS_BOITE, foyer) if foyer else []
            pf = part_dans(sal, foyer_boites)
            superposer(ecran, sal, zs, foyer_boites).save(sortie / f"attention-{L}.png")
            # 2. contraste sur le fond réel
            textes = page.evaluate(JS_TEXTES)
            entiere = Image.open(_capture(page, sortie / f"page-{L}.png", full=True))
            page.add_style_tag(content=CSS_SANS_TEXTE)
            page.wait_for_timeout(150)
            sans = Image.open(_capture(page, sortie / f"sans-texte-{L}.png", full=True))
            contr = mesurer_contraste(textes, sans)
            _annoter(entiere, contr).save(sortie / f"contraste-{L}.png")
            # 3. page réduite
            r = entiere.convert("RGB"); r.thumbnail((360, 100000)); r.save(sortie / f"reduite-{L}.png")
            fiche["largeurs"][L] = {"zones": zs, "foyer": foyer, "foyer_mesure": pf, "contraste": contr,
                                    "hauteur_page": entiere.size[1]}
            ctx.close()
        nav.close()
    (sortie / "fiche.json").write_text(json.dumps(fiche, ensure_ascii=False, indent=1), encoding="utf-8")
    (sortie / "fiche.md").write_text(rediger(fiche), encoding="utf-8")
    return fiche


def _capture(page, chemin: Path, full: bool) -> Path:
    page.screenshot(path=str(chemin), full_page=full)
    return chemin


def _annoter(img: Image.Image, contr):
    out = img.convert("RGB").copy()
    d = ImageDraw.Draw(out)
    for c in contr:
        if c.get("statut") != "mesuré" or not (c["sous_seuil"] or c["fond_heterogene"]):
            continue
        x, y, w, h = c["boite"]
        col = (220, 30, 30) if c["sous_seuil"] else (230, 150, 0)
        d.rectangle([x - 2, y - 2, x + w + 2, y + h + 2], outline=col, width=3)
    return out


def rediger(f) -> str:
    classique = not f["attention_modele"].startswith("onnx:")
    L = []
    L.append(f"# Fiche de regard : {f['page']}\n")
    L.append("Signaux, pas verdicts. L'œil de la personne tranche.\n")
    L.append("Attention : " + ("approximation classique (contraste couleur et résidu spectral), signal faible ; "
                              "brancher un modèle de saillance appris avec `--attention onnx:` pour un signal plus fiable."
                              if classique else f"modèle `{Path(f['attention_modele'][5:]).name}` (modèle de saillance appris)."))
    L.append("")
    for larg, r in f["largeurs"].items():
        L.append(f"## Largeur {larg} px\n")
        L.append("**Attention au premier écran** (zones par part de la masse d'attention) :\n")
        for i, z in enumerate(r["zones"], 1):
            s = z.get("sous") or {}
            L.append(f"{i}. {z['part']*100:.0f} % : `{s.get('element','?')}` « {s.get('texte','')} »")
        if len(r["zones"]) >= 2:
            a, b = r["zones"][0]["part"], r["zones"][1]["part"]
            if b / a > 0.75:
                L.append(f"\nSignal : **foyer disputé** (zones 1 et 2 à {a*100:.0f} % et {b*100:.0f} %).")
        fm = r["foyer_mesure"]
        if r["foyer"]:
            if fm is None:
                L.append(f"\nFoyer déclaré `{r['foyer']}` : introuvable ou hors du premier écran.")
            else:
                verdict = "le foyer déclaré attire plus que sa surface" if fm["levier"] >= 1.5 else \
                          "le foyer déclaré n'attire pas plus que sa surface" if fm["levier"] < 1.0 else "attraction modérée"
                L.append(f"\nFoyer déclaré `{r['foyer']}` : {fm['part']*100:.0f} % de l'attention pour {fm['aire']*100:.0f} % "
                         f"de l'écran (levier {fm['levier']:.1f}) ; {verdict}.")
        mes = [c for c in r["contraste"] if c.get("statut") == "mesuré"]
        sous = [c for c in mes if c["sous_seuil"]]
        hetero = [c for c in mes if c["fond_heterogene"] and not c["sous_seuil"]]
        non = [c for c in r["contraste"] if c.get("statut") != "mesuré"]
        pl = lambda n, s, p: f"{n} {s if n <= 1 else p}"
        L.append(f"\n**Contraste sur le fond réel** : {pl(len(mes), 'texte mesuré', 'textes mesurés')}, "
                 f"{len(sous)} sous le seuil, {len(hetero)} sur fond hétérogène au-dessus du seuil, "
                 f"{pl(len(non), 'non évalué', 'non évalués')}.\n")
        for c in sorted(sous, key=lambda c: c["pire"])[:8]:
            L.append(f"- Sous le seuil : « {c['texte']} » ({c['taille']} px{', tourné' if c.get('tourne') else ''}) : pire {c['pire']}:1, médian {c['median']}:1, "
                     f"seuil {c['seuil']}:1 ; `{c['chemin']}`")
        for c in sorted(hetero, key=lambda c: c["pire"])[:5]:
            L.append(f"- Fond hétérogène, tient : « {c['texte']} » : pire {c['pire']}:1 (seuil {c['seuil']}:1)")
        for c in non[:3]:
            L.append(f"- Non évalué : « {c['texte']} » ({c['raison']})")
        L.append(f"\nCaptures : `attention-{larg}.png`, `contraste-{larg}.png` (rouge : sous le seuil ; orange : fond hétérogène), "
                 f"`reduite-{larg}.png` (page entière réduite), `sans-texte-{larg}.png` (test de support).\n")
    L += rediger_marqueurs(f.get("marqueurs"))
    L += rediger_antecedent(f.get("antecedent"))
    L.append("## Limites\n")
    L.append("- Attention : prédiction moyenne d'une population, pas une mesure ; un modèle appris hérite des interfaces "
             "et de la résolution de son corpus d'entraînement. L'approximation classique ne sait pas lire.")
    L.append("- Contraste : mesuré au pire décile du fond sous chaque ligne (5e et 95e centiles ; quartiles pour le texte tourné, "
             "dont la boîte droite déborde de son fond) ; le texte rogné par son conteneur et le texte rempli par un dégradé "
             "ne sont pas évalués ; les états non rendus (survol, focus) ne sont pas couverts.")
    if f.get("antecedent"):
        L.append("- Antécédent : première police déclarée du titre (le h1 du premier écran, sinon le plus grand texte) et du "
                 "texte courant, fond de page (sinon couleur dominante des pixels), casse et graisse du titre, teinte d'accent ; "
                 "seuils `[À ADAPTER]`. Une police déclarée n'est pas forcément celle qui s'affiche ; un fond en image n'est pas lu.")
    L.append("- Marqueurs : relevés au premier écran de la première largeur, par teintes de pixels et styles calculés, "
             "avec des seuils `[À ADAPTER]` ; une police déclarée n'est pas forcément celle qui s'affiche. Un marqueur "
             "relevé n'est pas une faute, un relevé vide ne prouve pas la singularité, et les marqueurs non mesurés "
             "restent à regarder.")
    return "\n".join(L) + "\n"


def rediger_antecedent(a) -> list[str]:
    if not a:
        return []
    L = [f"## Antécédent ({a['largeur']} px, premier écran)\n", f"Comparé à `{a['page']}` : champs visibles de l'antécédent (`DIRECTION/FIRST-OBJECT`, « Réutilisation située »).\n"]
    L += [f"- Repris : {r}." for r in a["repris"]] or ["- Rien de repris parmi les champs mesurés."]
    L += [f"- Différent : {d}." for d in a["differents"]]
    L.append("\nChaque reprise dit son `KEEP-IF` dans `REUSE-CHALLENGE`, ou change. Ossature, objet de preuve et thèse "
             "se comparent dans la trace : le script ne les voit pas.\n")
    return L


def rediger_marqueurs(m) -> list[str]:
    if not m:
        return []
    L = [f"## Marqueurs de vague ({m['largeur']} px, premier écran)\n"]
    if not m["lisible"]:
        return L + [f"Liste `{m['route']}` introuvable : marqueurs non relevés (`NOT-VERIFIED`).\n"]
    date = f"[VEILLE {m['veille']}]" if m.get("veille") else "non datée"
    L.append(f"Liste {date} de `{m['route']}`, pour nommer `MODAL`, jamais pour interdire : un marqueur gardé par "
             "décision reste valide s'il tient (dose, limite, lien, exécution exacte).")
    if m["perimee"]:
        L.append(f"\n**Liste à revérifier** : son échéance de revue ({m['echeance']}) est passée ; ce relevé reste un signal, "
                 "à confronter à une veille à jour avant tout claim de tendance.")
    L.append("")
    if m["presents"]:
        for p in m["presents"]:
            L.append(f"- **{p['nom']}** (vague {p['vague']}) : " + " ; ".join(p["preuves"]) + ".")
        L.append("\nChaque marqueur relevé se nomme dans la ligne « modal, trame et parti » : écarté, ou gardé après l’atelier qui l’a éprouvé (variante qui le retire, comparée à la vue).")
    else:
        L.append("- Aucun marqueur mesurable relevé.")
    if m["absents"]:
        L.append(f"\nNon relevés : {', '.join(m['absents'])}.")
    if m["non_mesures"]:
        L.append(f"Non mesurés, à regarder : {', '.join(m['non_mesures'])}.")
    return L + [""]


def main(argv=None):
    ap = argparse.ArgumentParser(description="Fiche de regard d'un rendu HTML (signaux, pas verdicts).")
    ap.add_argument("page")
    ap.add_argument("--foyer", help="sélecteur CSS du foyer déclaré")
    ap.add_argument("--largeurs", default="1440,390")
    ap.add_argument("--hauteur", type=int, default=900)
    ap.add_argument("--sortie", default=None, help="dossier de la fiche ; par défaut regard-NOM, à côté de la page")
    ap.add_argument("--attention", default="classique", help="classique | onnx:CHEMIN/model.onnx")
    ap.add_argument("--antecedent", default=None, help="rendu HTML précédent à comparer (paire typographique, teinte dominante, registre)")
    a = ap.parse_args(argv)
    page = Path(a.page)
    sortie = Path(a.sortie) if a.sortie else page.parent / f"regard-{page.stem}"  # à côté de la page, jamais dans le paquet
    ant = Path(a.antecedent) if a.antecedent else None
    if ant is not None and not ant.is_file():
        print(f"Antécédent introuvable : {ant}", file=sys.stderr)
        return 2
    f = regarder(page, sortie, [int(x) for x in a.largeurs.split(",")], a.hauteur, a.foyer, a.attention, ant)
    print((sortie / "fiche.md").read_text(encoding="utf-8"))
    return 0


if __name__ == "__main__":
    import journal_mobilisation  # journal passif : n'écrit rien sans DG_JOURNAL
    sys.exit(journal_mobilisation.executer("regard", main, sys.argv[1:]))
