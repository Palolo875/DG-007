#!/usr/bin/env python3
"""Cas connus de `scripts/regard.py` et de `scripts/planche.py` : chaque instrument retrouve la réponse attendue.

Les marqueurs de vague sont aussi contrôlés sans navigateur : la liste datée de `SAVOIR/TOOLS/CONVERGENCE` se lit,
chaque marqueur relevé par le script y est nommé tel quel, chaque relevé a son détecteur, et l'échéance se lit.

Les pages pièges sont écrites dans un dossier temporaire ; aucune ressource externe. Les instruments demandent
Playwright, Chromium, NumPy, SciPy et Pillow : s'il en manque un, les cas sont déclarés NOT-VERIFIED, jamais
réussis ; `--require-browser` en fait un échec. Ce fichier ne valide aucun rendu : il vérifie que les instruments
disent vrai sur des cas dont la réponse est connue.
"""
from __future__ import annotations

import argparse
import importlib.util
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent

CONTRASTE = """<!doctype html><html lang="fr"><meta charset="utf-8"><title>Test contraste</title>
<style>body{margin:0;font-family:Arial,sans-serif;background:#fff}
.hero{position:relative;height:600px;background:url(photo.png) center/cover}
.t1{position:absolute;top:80px;left:60px;color:#fff;font-size:20px}
.t2{position:absolute;top:450px;left:60px;color:#fff;font-size:20px}
.grad{height:200px;background:linear-gradient(90deg,#fff,#000);display:flex;align-items:center;padding:0 40px}
.grad p{color:#000;font-size:34px;margin:0;width:100%;white-space:nowrap}
.ok{color:#222;font-size:18px;padding:20px}
.faible{color:#999;font-size:18px;padding:20px}
.sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)}
.degr{font-size:40px;font-weight:700;background:linear-gradient(90deg,red,blue);-webkit-background-clip:text;background-clip:text;color:transparent;padding:20px}
</style>
<div class="hero"><p class="t1" id="blanc-sur-ciel">Blanc sur le ciel clair</p><p class="t2" id="blanc-sur-sol">Blanc sur le sol sombre</p></div>
<div class="grad"><p id="noir-sur-degrade">Texte noir posé sur un dégradé du blanc au noir, il traverse toute la largeur du bandeau</p></div>
<p class="ok" id="ok">Texte sombre sur blanc, contraste correct.</p>
<p class="faible" id="faible">Texte gris clair sur blanc, contraste faible.</p>
<span class="sr">Réservé aux lecteurs d'écran</span>
<p class="degr">Titre en dégradé</p>
<svg width="600" height="120" style="display:block;margin:20px"><rect x="0" y="0" width="300" height="120" fill="#1e6b3a"/>
<text id="svg-blanc-sur-vert" x="20" y="60" fill="#ffffff" font-size="18" font-family="Arial">Blanc sur vert (SVG)</text>
<text id="svg-gris-sur-blanc" x="320" y="60" fill="#aaaaaa" font-size="18" font-family="Arial">Gris clair sur blanc (SVG)</text></svg>
</html>"""

ROGNE_TOURNE = """<!doctype html><html lang="fr"><head><meta charset="utf-8"><style>
body{margin:0;background:#e4f0e3;font:20px/1.2 sans-serif;padding:40px}
.tambour{position:relative;display:inline-block;width:120px;height:120px;overflow:hidden;background:#101612;color:#f1ece0;font-size:110px;line-height:1}
.tambour span{position:absolute;left:0;right:0;text-align:center}.tambour .h{top:-100px}.tambour .m{top:5px}
.tag{display:inline-block;margin:80px 0 0 80px;transform:rotate(9deg);background:#a3531f;color:#fbf6ee;padding:14px 28px;font-weight:700;font-size:48px}
.tag2{display:inline-block;margin:80px 0 0 80px;transform:rotate(9deg);background:#c98a5e;color:#fbf6ee;padding:14px 28px;font-weight:700;font-size:20px}
</style></head><body>
<div class="tambour"><span class="h" id="fantome">9</span><span class="m" id="chiffre">0</span></div>
<div><span class="tag" id="etiq-sombre">0,02 €</span></div>
<div><span class="tag2" id="etiq-claire">réponse comprise</span></div>
</body></html>"""

FOYER_NET = """<!doctype html><html lang="fr"><meta charset="utf-8"><title>Foyer net</title>
<style>body{margin:0;height:100vh;background:#f2f0ea;font-family:Arial}
.rond{position:absolute;left:58%;top:30%;width:260px;height:260px;border-radius:50%;background:#e8402f}
p{position:absolute;left:8%;top:14%;color:#555;font-size:14px;max-width:260px}</style>
<p>Une ligne d'appui discrète, en gris, pour qu'il y ait un peu de texte à côté du foyer.</p><div class="rond" id="foyer"></div></html>"""

FOYER_DISPUTE = """<!doctype html><html lang="fr"><meta charset="utf-8"><title>Foyer disputé</title>
<style>body{margin:0;height:100vh;background:#f2f0ea;font-family:Arial}
.r{position:absolute;top:32%;width:220px;height:220px;border-radius:50%;background:#e8402f}
#a{left:14%}#b{left:62%}</style>
<div class="r" id="a"></div><div class="r" id="b"></div></html>"""

MARQUEURS_GENERIQUE = """<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Flowly</title><style>
body{margin:0;font-family:Inter,system-ui,sans-serif;background:#0b0b12;color:#e8e8f0}
.hero{min-height:90vh;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:24px;background:radial-gradient(circle at 50% 0%,#5b3df5 0%,transparent 60%)}
h1{font-size:64px;margin:0 0 16px;background:linear-gradient(90deg,#fff,#a99bff);-webkit-background-clip:text;background-clip:text;color:transparent}
p{max-width:560px;color:#a0a0b8;font-size:18px}.cta{margin-top:24px;padding:14px 28px;border-radius:999px;background:#6d5cff;color:#fff;text-decoration:none}
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;padding:0 10vw 64px}.card{padding:24px;border:1px solid #23233a;border-radius:16px;background:#12121c}</style></head>
<body><section class="hero"><h1>Supercharge your workflow with AI</h1><p>Flowly helps teams ship faster.</p><a class="cta" href="#">Get started free</a>
<div class="grid"><div class="card"><h3>Fast</h3><p>Blazing fast.</p></div><div class="card"><h3>Secure</h3><p>Enterprise-grade.</p></div><div class="card"><h3>Smart</h3><p>AI insights.</p></div></div></section></body></html>"""

MARQUEURS_CALME = """<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>Atelier</title><style>
body{margin:0;font-family:Helvetica,Arial,sans-serif;background:#ffffff;color:#151515}
main{padding:80px 8vw}h1{font-size:56px;margin:0 0 24px;max-width:14ch}p{font-size:18px;max-width:52ch}
a{display:inline-block;margin-top:16px;padding:12px 20px;background:#1f6b45;color:#fff;text-decoration:none}
table{margin-top:48px;border-collapse:collapse}td{padding:8px 24px 8px 0;border-bottom:1px solid #ddd}</style></head>
<body><main><h1>Réparer un vélo en vingt minutes</h1><p>Un atelier de quartier ouvert le samedi.</p><a href="#">Réserver</a>
<table><tr><td>Crevaison</td><td>12 €</td></tr><tr><td>Freins</td><td>18 €</td></tr></table></main></body></html>"""

MARQUEURS_CREME = """<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>Fournil</title><style>
body{margin:0;font-family:Helvetica,Arial,sans-serif;background:#f3ead9;color:#4a2e1a}
main{padding:60px 8vw}h1{font-family:Georgia,'Times New Roman',serif;font-style:italic;font-size:72px;margin:0 0 24px;color:#4a2e1a}
a{display:inline-block;padding:14px 24px;background:#b4471b;color:#fff;text-decoration:none}
.bande{overflow:hidden;white-space:nowrap;background:#4a2e1a;color:#f3ead9;padding:10px 0;margin-top:40px}
.bande span{display:inline-block;width:200vw;animation:defile 20s linear infinite}@keyframes defile{from{transform:translateX(0)}to{transform:translateX(-50%)}}</style></head>
<body><main><h1>Le pain de la veille, ce matin</h1><a href="#">Commander</a></main><div class="bande"><span>Fournées du jour · Levain · Seigle · Fournées du jour · Levain · Seigle</span></div></body></html>"""

ANT_TITRE_SEUL = """<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>App</title><style>
body{margin:0;font-family:Helvetica,Arial,sans-serif;background:#ffffff;color:#151515}
main{padding:80px 8vw}h1{font-family:Georgia,'Times New Roman',serif;font-size:56px;margin:0 0 24px;max-width:14ch}</style></head>
<body><main><h1>Une alerte, au bon moment</h1><p>Une app qui se tait tant que tout va bien.</p></main></body></html>"""

ANT_TITRE_ET_TELEPHONE = """<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>App</title><style>
body{margin:0;font-family:Helvetica,Arial,sans-serif;background:#ffffff;color:#151515}
main{padding:80px 8vw;position:relative;height:740px}h1{font-family:Georgia,'Times New Roman',serif;font-size:56px;margin:0 0 24px;max-width:14ch}
.tel{position:absolute;right:8vw;top:60px;width:300px;height:600px;border-radius:40px;background:#1d2b3a;color:#fff;text-align:center}
.heure{font-family:'Courier New',monospace;font-size:96px;margin-top:60px}</style></head>
<body><main><h1>Une alerte, au bon moment</h1><p>Une app qui se tait tant que tout va bien.</p>
<div class="tel"><div class="heure">9:41</div></div></main></body></html>"""

ANT_PANNEAU_SOMBRE = """<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>App</title><style>
body{margin:0;font-family:Helvetica,Arial,sans-serif;background:#ffffff;color:#151515}
main{padding:80px 8vw}h1{font-family:Georgia,'Times New Roman',serif;font-size:56px;margin:0 0 24px;max-width:10ch}
.visuel{position:absolute;right:0;top:0;width:62vw;height:100vh;background:#1d2b3a}</style></head>
<body><main><h1>Une alerte, au bon moment</h1><p>Une app qui se tait.</p></main><div class="visuel"></div></body></html>"""

MARQUEURS_VAGUE3 = """<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>Plan</title><style>
body{margin:0;font-family:Helvetica,Arial,sans-serif;background:#fff;color:#111}
.bloc{background:#002fa7;color:#fff;padding:60px 8vw;height:420px}h1{font-size:60px;margin:0}
.lab{font-family:'JetBrains Mono',ui-monospace,monospace;text-transform:uppercase;font-size:12px;letter-spacing:.1em;margin:4px 0}
pre{font-size:12px;margin:20px 8vw}</style></head>
<body><div class="bloc"><p class="lab">Fig. 01</p><p class="lab">Coupe A-A</p><p class="lab">Échelle 1:50</p><h1>Atelier d'architecture</h1></div>
<pre>+--------+--------+
|  ////  |  ////  |
+--------+--------+
|  ####  |  ####  |
+--------+--------+</pre></body></html>"""

DEBORDE = """<!doctype html><html lang="fr"><meta charset="utf-8"><title>Déborde</title>
<style>body{margin:0}div{width:1200px;height:40px;background:#ccc}</style><div></div></html>"""


def manquants() -> list[str]:
    absents = [m for m in ("numpy", "scipy", "PIL", "playwright") if importlib.util.find_spec(m) is None]
    if not absents:
        try:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as p:
                p.chromium.launch().close()
        except Exception as exc:  # navigateur absent ou inutilisable
            absents.append(f"Chromium ({type(exc).__name__})")
    return absents


def photo(chemin: Path) -> None:
    """Une « photo » : ciel clair en haut, sol sombre en bas, avec du grain pour que le fond soit hétérogène."""
    import numpy as np
    from PIL import Image
    rng = np.random.default_rng(7)
    img = np.zeros((600, 1200, 3), dtype=np.float32)
    img[:300] = (205, 225, 242)
    img[300:] = (43, 42, 36)
    img += rng.normal(0, 6, img.shape)
    Image.fromarray(np.clip(img, 0, 255).astype("uint8")).save(chemin)


def controles_statiques(regard, attendre) -> None:
    """Liste datée et relevés : la liste fait foi, chaque relevé du script y est nommé, chaque relevé a son détecteur."""
    import datetime
    liste = regard.lire_marqueurs()
    attendre(liste is not None and len(liste["marqueurs"]) >= 12, "marqueurs : liste datée lue à son lieu actuel")
    noms = {m["nom"] for m in (liste or {"marqueurs": []})["marqueurs"]}
    perdus = sorted(set(regard.RELEVES) - noms)
    attendre(not perdus, f"marqueurs : chaque marqueur relevé est nommé tel quel par la liste ({perdus})")
    attendre(set(regard.RELEVES.values()) == set(regard.DETECTEURS), "marqueurs : un détecteur par relevé, et réciproquement")
    attendre(bool(liste) and liste["echeance"] is not None and liste["veille"] is not None, "marqueurs : date de veille et échéance lues")
    attendre(regard.echeance_passee("2027-03", datetime.date(2027, 3, 1)) and not regard.echeance_passee("2027-03", datetime.date(2027, 2, 28)),
             "marqueurs : échéance passée dès le premier jour du mois annoncé")
    vide = regard.relever_marqueurs({}, {}, None)
    attendre(vide["lisible"] is False and "NOT-VERIFIED" in "".join(regard.rediger_marqueurs({"largeur": 1440, **vide})),
             "marqueurs : liste introuvable, relevé NOT-VERIFIED, rien de deviné")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Cas connus de la commande de regard et de la planche.")
    ap.add_argument("--require-browser", action="store_true")
    ap.add_argument("--skip-browser", action="store_true")
    a = ap.parse_args(argv)
    if a.skip_browser:
        if all(importlib.util.find_spec(m) for m in ("numpy", "scipy", "PIL")):
            sys.path.insert(0, str(HERE))
            import regard  # noqa: E402
            echecs: list[str] = []

            def statique(cond: bool, msg: str) -> None:
                print(f"  [{'ok' if cond else 'ÉCHEC'}] {msg}")
                if not cond:
                    echecs.append(msg)
            controles_statiques(regard, statique)
            if echecs:
                print("REGARD TESTS FAILED — contrôles statiques des marqueurs")
                return 1
        print("REGARD TESTS NOT-VERIFIED — navigateur écarté (--skip-browser)")
        return 0
    absents = manquants()
    if absents:
        print("REGARD TESTS NOT-VERIFIED — absents : " + ", ".join(absents))
        return 1 if a.require_browser else 0

    sys.path.insert(0, str(HERE))
    import regard  # noqa: E402
    import planche  # noqa: E402

    echecs: list[str] = []
    n = 0

    def attendre(cond: bool, msg: str) -> None:
        nonlocal n
        n += 1
        print(f"  [{'ok' if cond else 'ÉCHEC'}] R{n:02d} {msg}")
        if not cond:
            echecs.append(msg)

    def par_id(contr, fragment):
        return next(c for c in contr if fragment in c["chemin"] or fragment in c["texte"])

    with tempfile.TemporaryDirectory() as tmp:
        d = Path(tmp)
        photo(d / "photo.png")
        for nom, html in (("contraste", CONTRASTE), ("rogne-tourne", ROGNE_TOURNE), ("foyer-net", FOYER_NET),
                          ("foyer-dispute", FOYER_DISPUTE), ("deborde", DEBORDE), ("generique", MARQUEURS_GENERIQUE),
                          ("calme", MARQUEURS_CALME), ("creme", MARQUEURS_CREME), ("vague3", MARQUEURS_VAGUE3)):
            (d / f"{nom}.html").write_text(html, encoding="utf-8")

        c = regard.regarder(d / "contraste.html", d / "c", [1440], 900, None, "classique")["largeurs"][1440]["contraste"]
        attendre(par_id(c, "blanc-sur-ciel")["sous_seuil"], "blanc sur ciel clair : sous le seuil")
        attendre(not par_id(c, "blanc-sur-sol")["sous_seuil"], "blanc sur sol sombre : au-dessus du seuil")
        g = par_id(c, "noir-sur-degrade")
        attendre(g["sous_seuil"] and g["median"] >= g["seuil"], "noir sur dégradé : le pire échoue alors que le médian passe")
        attendre(abs(par_id(c, "faible")["pire"] - 2.85) < 0.05, "gris #999 sur blanc : 2,85:1")
        attendre(not par_id(c, "p#ok")["sous_seuil"], "texte sombre sur blanc : au-dessus du seuil")
        attendre(all("lecteurs" not in x["texte"] for x in c), "texte réservé aux lecteurs d'écran : exclu")
        attendre(par_id(c, "Titre en dégradé")["statut"] == "non évalué", "titre rempli par un dégradé : non évalué")
        attendre(not par_id(c, "Blanc sur vert (SVG)")["sous_seuil"], "texte SVG blanc sur vert : couleur lue dans fill")
        attendre(par_id(c, "Gris clair sur blanc (SVG)")["sous_seuil"], "texte SVG gris clair sur blanc : sous le seuil")

        rt = regard.regarder(d / "rogne-tourne.html", d / "rt", [1440], 900, None, "classique")["largeurs"][1440]["contraste"]
        attendre(par_id(rt, "fantome")["statut"] == "non évalué", "chiffre fantôme rogné par son tambour : non évalué")
        attendre(not par_id(rt, "chiffre")["sous_seuil"], "chiffre visible du tambour : au-dessus du seuil")
        attendre(not par_id(rt, "etiq-sombre")["sous_seuil"], "texte tourné sur étiquette sombre : au-dessus du seuil")
        attendre(par_id(rt, "etiq-claire")["sous_seuil"], "petit texte tourné sur étiquette claire : sous le seuil")

        f = regard.regarder(d / "foyer-net.html", d / "n", [1440], 900, "#foyer", "classique")["largeurs"][1440]
        attendre(f["foyer_mesure"]["levier"] > 5, f"foyer net : levier {f['foyer_mesure']['levier']:.1f} > 5")
        z = f["zones"]
        attendre(len(z) < 2 or z[1]["part"] / z[0]["part"] < 0.75, "foyer net : pas de foyer disputé")
        s = regard.regarder(d / "foyer-dispute.html", d / "s", [1440], 900, None, "classique")["largeurs"][1440]["zones"]
        attendre(len(s) >= 2 and s[1]["part"] / s[0]["part"] > 0.75, "deux foyers égaux : foyer disputé")

        controles_statiques(regard, attendre)

        def releves(nom):
            m = regard.regarder(d / f"{nom}.html", d / f"m-{nom}", [1440], 900, None, "classique")["marqueurs"]
            return m, {p["id"] for p in m["presents"]}
        m, ids = releves("generique")
        attendre({"violet", "inter", "halo-degrade", "hero-cartes"} <= ids and not ids & {"fond-creme", "brun", "serif-titre"},
                 f"hero SaaS violet : les quatre marqueurs de la vague 1, et eux seuls de la vague 2 ({sorted(ids)})")
        m, ids = releves("calme")
        attendre(not ids, f"page sobre sur blanc, sans dégradé ni cartes : aucun marqueur ({sorted(ids)})")
        attendre(len(m["non_mesures"]) == 8, "marqueurs non mesurables : nommés, jamais déclarés absents")
        m, ids = releves("creme")
        attendre({"fond-creme", "brun", "serif-titre", "rouille", "bandeau-defilant"} <= ids and "violet" not in ids,
                 f"fournil crème : les cinq marqueurs de la vague 2 ({sorted(ids)})")
        m, ids = releves("vague3")
        attendre({"bleu-klein", "mono-capitales", "ascii"} <= ids and "fond-creme" not in ids,
                 f"bloc bleu Klein, libellés mono, ASCII : vague 3 ({sorted(ids)})")
        (d / "creme2.html").write_text(MARQUEURS_CREME.replace("Le pain de la veille, ce matin", "Une autre page, la même manière"), encoding="utf-8")
        a = regard.regarder(d / "creme2.html", d / "a1", [1440], 900, None, "classique", d / "creme.html")["antecedent"]
        attendre(any(r.startswith("paire typographique (") for r in a["repris"]) and any(r.startswith("teinte dominante") for r in a["repris"])
                 and any(r.startswith("registre") for r in a["repris"]), f"antécédent : même manière, autre texte → paire, teinte et registre repris ({a['repris']})")
        a = regard.regarder(d / "calme.html", d / "a2", [1440], 900, None, "classique", d / "creme.html")["antecedent"]
        attendre(any(x.startswith("paire typographique (") for x in a["differents"]) and any(x.startswith("teinte dominante") for x in a["differents"]),
                 f"antécédent : autre manière → paire et teinte différentes ({a['differents']})")
        for nom, html in (("ant-titre", ANT_TITRE_SEUL), ("ant-tel", ANT_TITRE_ET_TELEPHONE), ("ant-panneau", ANT_PANNEAU_SOMBRE)):
            (d / f"{nom}.html").write_text(html, encoding="utf-8")
        a = regard.regarder(d / "ant-tel.html", d / "a4", [1440], 900, None, "classique", d / "ant-titre.html")["antecedent"]
        attendre(any(r.startswith("paire typographique (") for r in a["repris"]),
                 f"antécédent : le titre est le h1, pas l'heure d'un téléphone plus grande ({a['repris']} / {a['differents']})")
        a = regard.regarder(d / "ant-panneau.html", d / "a5", [1440], 900, None, "classique", d / "ant-titre.html")["antecedent"]
        attendre(any(r.startswith("teinte dominante") for r in a["repris"]),
                 f"antécédent : la teinte est celle du fond, pas d'un panneau plus étendu ({a['repris']} / {a['differents']})")
        attendre("## Antécédent" in (d / "a2" / "fiche.md").read_text(encoding="utf-8")
                 and "## Antécédent" not in (d / "m-calme" / "fiche.md").read_text(encoding="utf-8"),
                 "antécédent : section écrite seulement quand un rendu précédent est donné")
        import contextlib as _cl
        import io as _io
        with _cl.redirect_stderr(_io.StringIO()):
            code = regard.main([str(d / "calme.html"), "--antecedent", str(d / "absent.html"), "--sortie", str(d / "a3")])
        attendre(code == 2, "antécédent introuvable : code 2, rien de deviné")
        fiche = (d / "m-generique" / "fiche.md").read_text(encoding="utf-8")
        attendre("## Marqueurs de vague" in fiche and "ou gardé après l’atelier" in fiche, "fiche : section des marqueurs et suite à donner")

        from PIL import Image
        import contextlib
        import io
        sortie = io.StringIO()
        with contextlib.redirect_stdout(sortie):
            code = planche.main([str(d / "planche.png"), str(d / "foyer-net.html"), str(d / "deborde.html"), "--colonnes", "2"])
        attendre(code == 0 and (d / "planche.png").is_file(), "planche : écrite pour deux pages")
        attendre("deborde.html : débordement horizontal à 390 px" in sortie.getvalue(), "planche : débordement signalé à 390 px")
        attendre(Image.open(d / "planche.png").size[0] > 1500, "planche : deux pages côte à côte sur une ligne")
        sortie = io.StringIO()
        with contextlib.redirect_stdout(sortie):
            code = planche.main([str(d / "bureau.png"), str(d / "foyer-net.html"), str(d / "deborde.html"), "--colonnes", "2", "--bureau-seul"])
        attendre(code == 0 and "bureau seul" in sortie.getvalue() and "390 px" not in sortie.getvalue(),
                 "planche --bureau-seul : esquisses comparées au bureau, sans capture mobile")
        attendre(Image.open(d / "bureau.png").size[0] < Image.open(d / "planche.png").size[0],
                 "planche --bureau-seul : pas de colonne mobile")

    print(f"REGARD TESTS {'PASSED' if not echecs else 'FAILED'} — {n} cas")
    return 1 if echecs else 0


if __name__ == "__main__":
    sys.exit(main())
