#!/usr/bin/env python3
"""Témoins de l'audit simulé : navigation réelle et profil de capacités cohérent.

Ces tests n'établissent ni une compréhension utilisateur ni un gain esthétique.
"""
from __future__ import annotations

import copy
import importlib.util
import json
import re
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import validate_design_governance as package
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "gouvernance" / "outils"))
import validate_run_card as cards
import validate_reading_map as reading_map
import validate_structure as structure
import read_route as routes

ROOT = Path(__file__).resolve().parents[1]


class MobilisationFacadeTests(unittest.TestCase):
    def setUp(self):
        self.texts = reading_map.load_texts()

    def assert_rejected(self, key, old, new, expected):
        texts = dict(self.texts)
        self.assertIn(old, texts[key], f"mutation impossible dans {key} : {old}")
        texts[key] = texts[key].replace(old, new, 1)
        errors = []
        with patch.object(reading_map, "load_texts", return_value=texts):
            reading_map.check_facades(errors)
        self.assertTrue(any(expected in error for error in errors), errors)

    def test_inheritance_cannot_become_non_applicability(self):
        self.assert_rejected("B", "conserve-la par héritage ou comme cas documentaire, avec sa source et sa justification.",
                             "conserve-la et justifie `N/A-JUSTIFIED`.", "LCF-51")

    def test_run_card_cannot_be_required_by_mode_alone(self):
        self.assert_rejected("G", "Son exigence dépend du niveau de trace et du mode ; une proposition en trace légère ne produit pas de RUN_CARD.",
                             "Elle est toujours exigée en STANDARD et DIRECTION.", "LCF-52")

    def test_domain_template_cannot_omit_risk_coverage(self):
        self.assert_rejected("D", "`required_controls`, `risk_coverage`, `depth_rules`", "`required_controls`, `depth_rules`", "LCF-53")

    def test_activation_cannot_disappear_from_compiled_core(self):
        self.assert_rejected("SK", "python3 scripts/read_route.py --connexions", "commande retirée", "LCF-54")

    def test_iter_cannot_capture_local_fix(self):
        self.assert_rejected('D','au-delà d’un fix ou delta local qui la conserve','y compris tout fix local','LCF-55')

    def test_quickstart_must_keep_iter_discriminant(self):
        self.assert_rejected('Q','au-delà d’un fix local qui la conserve','quel que soit le delta','LCF-55')

    def test_persistence_cannot_erase_short_lite_exception(self):
        self.assert_rejected('A','sauf la forme courte LITE définie ci-dessus','sans exception','LCF-56')

    def test_glossary_cannot_make_complete_trace_always_structured(self):
        self.assert_rejected('G','La forme courte LITE définie par `ACTION/HANDOFF` est complète sans RUN_CARD','Toute trace complète exige une RUN_CARD','LCF-56')

    def test_map_cannot_erase_short_lite_exception(self):
        self.assert_rejected('RM','sauf la forme courte LITE sans RUN_CARD définie','sans exception définie','LCF-56')

    def test_compiled_trace_keeps_short_lite_exception(self):
        self.assert_rejected('SK','La forme courte LITE conserve une trace complète sans RUN_CARD','Toute clôture exige une RUN_CARD','LCF-56')

    def test_owner_and_scope_stay_due_in_full_trace(self):
        # A11 : la ligne RUN suffit en trace légère ; OWNER et SCOPE restent dus en trace complète.
        self.assert_rejected('D', 'En trace complète, `OWNER` et `SCOPE` ne sont jamais omis', '`OWNER` et `SCOPE` sont facultatifs', 'LCF-08')

    def test_brief_rule_stays_protected_when_loaded_by_reference(self):
        self.assert_rejected('D', 'Au plus trois demandes', 'Questionnaire sans limite', 'LCF-44')

    def test_first_object_rule_stays_protected_when_loaded_by_reference(self):
        self.assert_rejected('D', 'de préférence **codé**', 'décoratif par défaut', 'LCF-47')

    def test_missing_brief_relay_cannot_pass_as_a_shorter_skill(self):
        # Le bloc BRIEF est compilé (L2-09) : sans lui ni renvoi, la skill ne porte plus la règle.
        texts = dict(self.texts)
        for key in ('D', 'SK'):
            texts[key] = texts[key].replace('`DIRECTION/EXTERNAL-START`', 'renvoi retiré')
        self.assertTrue(reading_map.lcf_44(texts))
        texts['SK'] = texts['SK'].replace('Au plus trois demandes', 'Des demandes')
        self.assertFalse(reading_map.lcf_44(texts))

    def test_signal_table_keeps_gate_consequence_of_generic_motif(self):
        self.assert_rejected('D', 'conséquence de gate : `ACTION/ANTI-SLOP`', 'conséquence de gate : aucune', 'LCF-17')

    def test_signal_table_does_not_classify(self):
        self.assert_rejected('D', '| Structure ouverte | `BIBLIOTHEQUE/READ`', '| Structure ouverte | `ACTION/RUN-STANDARD`, `BIBLIOTHEQUE/READ`', 'LCF-06')

    def test_asset_treatment_rule_stays_at_its_current_owner(self):
        self.assert_rejected('S', '**Traitement des assets moyens.**', '**Règle supprimée.**', 'LCF-49')


class NavigationTests(unittest.TestCase):
    def check(self, text: str, extra: dict[str, str] | None = None) -> list[str]:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "README.md").write_text(text, encoding="utf-8")
            for name, content in (extra or {}).items():
                (root / name).write_text(content, encoding="utf-8")
            with patch.object(package, "ROOT", root):
                errors: list[str] = []
                package.check_links(errors)
                return errors

    def test_same_document_missing_section_refused(self):
        self.assertTrue(any("fragment Markdown introuvable" in e for e in self.check("# Entrée\n[aide](#absente)\n")))

    def test_same_document_existing_section_admitted(self):
        self.assertEqual(self.check("# Entrée\n[aide](#entrée)\n"), [])

    def test_code_example_is_not_a_destination(self):
        text = "# Entrée\n```md\n## Section fictive\n```\n[aide](guide.md#section-fictive)\n"
        self.assertTrue(any("fragment Markdown introuvable" in e for e in self.check(text, {"guide.md": text})))

    def test_nested_code_example_is_not_a_destination(self):
        text='# Entrée\n````md\n```\n## Faux\n```\n````\n[aide](#faux)\n'
        self.assertTrue(any('fragment Markdown introuvable' in e for e in self.check(text)))

    def test_formatted_heading_uses_visible_text(self):
        self.assertEqual(self.check("# `État` : _d’abord_ !\n[aide](#état--dabord-)\n"), [])

    def test_duplicate_heading_suffix_admitted(self):
        self.assertEqual(self.check("# Entrée\n## Aide\n## Aide\n[deuxième](#aide-1)\n"), [])

    def test_duplicate_suffix_without_heading_refused(self):
        self.assertTrue(any("fragment Markdown introuvable" in e for e in self.check("# Aide\n[absente](#aide-1)\n")))

    def test_custom_html_anchor_admitted(self):
        self.assertEqual(self.check('# Entrée\n<a name="reprise"></a>\n[aide](#reprise)\n'), [])

    def test_encoded_fragment_admitted(self):
        self.assertEqual(self.check("# Entrée\n[aide](#entr%C3%A9e)\n"), [])

    def test_external_link_is_not_fetched(self):
        self.assertEqual(self.check("# Entrée\n[externe](https://example.invalid/#absente)\n"), [])

    def test_missing_file_still_refused(self):
        self.assertTrue(any("lien relatif cassé" in e for e in self.check("# Entrée\n[aide](absent.md#aide)\n")))


class OperationalReferenceTests(unittest.TestCase):
    def check(self, text, extra=None):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            files = {"README.md": text, **(extra or {})}
            for name, content in files.items():
                target = root / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(content, encoding="utf-8")
            errors = []
            with patch.multiple(package, ROOT=root, EXPECTED=list(files)):
                package.check_inline_references(errors)
            return errors

    def test_deleted_changelog_reference_is_rejected(self):
        self.assertTrue(any("CHANGELOG.md" in e for e in self.check("Lire `CHANGELOG.md`.")))

    def test_retired_names_without_extension_are_rejected(self):
        for name in ("QUICKSTART", "GLOSSAIRE", "ORCHESTRATION_MAP"):
            with self.subTest(name=name):
                self.assertTrue(any(name in e for e in self.check(f"Lire `{name}`.")))
                self.assertTrue(any(name in e for e in self.check(f"Lire `{name}#section`.")))

    def test_supported_changelog_alias_and_symbolic_names_are_admitted(self):
        self.assertEqual(self.check("`CHANGELOG` ; `ACTION` ; `DIRECTION` ; `PASS` ; `CI`."), [])

    def test_common_extensions_missing_and_existing_files(self):
        for suffix in ("sh", "bash", "yml", "yaml", "html", "htm", "css", "js", "mjs", "cjs", "ts", "tsx", "jsx", "toml", "txt", "markdown"):
            with self.subTest(suffix=suffix):
                name = f"outils/controle.{suffix}"
                self.assertTrue(any(name in e for e in self.check(f"Lire `{name}`.")))
                self.assertEqual(self.check(f"Lire `{name}`.", {name: ""}), [])

    def test_declared_extensionless_file_is_checked(self):
        self.assertEqual(self.check("Lire `LICENSE`.", {"LICENSE": "Licence"}), [])
        with patch.multiple(package, EXPECTED=["README.md", "LICENSE"]):
            # Tester le manifeste sans créer le fichier déclaré.
            with tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp)
                (root / "README.md").write_text("Lire `LICENSE`.")
                errors = []
                with patch.object(package, "ROOT", root):
                    package.check_inline_references(errors)
                self.assertTrue(any("LICENSE" in e for e in errors))

    def test_shell_commands_check_scripts_and_ignore_user_arguments(self):
        for command in ("bash", "sh", "bash -n", "bash -eux", "bash --"):
            with self.subTest(command=command):
                text = f"Lancer `{command} scripts/test.sh chemin/saisie.json`."
                self.assertTrue(any("scripts/test.sh" in e for e in self.check(text)))
                self.assertEqual(self.check(text, {"scripts/test.sh": ""}), [])

    def test_python_flags_keep_script_and_route_checks(self):
        self.assertTrue(any("SAVOIR/FAUX" in e for e in self.check("`python3 -u ./scripts/read_route.py SAVOIR/FAUX`.",
                                                                 {"scripts/read_route.py": ""})))

    def test_modules_inline_code_and_complex_options_are_not_script_paths(self):
        for command in ("python3 -m http.server 4173", "python3 -c 'print(1)'", "bash -c 'echo scripts/absent.sh'", "bash -s argument-utilisateur", "bash --rcfile configuration.sh"):
            with self.subTest(command=command):
                self.assertEqual(self.check(f"`{command}`."), [])

    def test_new_reference_families_keep_example_and_fence_exemptions(self):
        self.assertEqual(self.check("`exemple: QUICKSTART` ; `exemple: scripts/absent.sh`\n```sh\nbash scripts/absent.sh\n```"), [])

    def test_shell_scope_uses_other_distribution_manifest(self):
        with patch.multiple(package, IS_LOCAL=True, LISTS={"github": ["scripts/github.sh"], "local": []}):
            self.assertEqual(self.check("`bash scripts/github.sh` <!-- références:github -->"), [])
            self.assertTrue(self.check("`bash scripts/absent.sh` <!-- références:github -->"))

    def test_yaml_and_shell_file_scopes_remain_checked_in_local_export(self):
        for name in (".github/workflows/validate.yml", "scripts/build_distributions.sh"):
            with self.subTest(name=name), patch.multiple(package, IS_LOCAL=True, LISTS={"github": [name], "local": []}):
                self.assertEqual(self.check(f"GitHub : `{name}` <!-- références:github -->"), [])
                self.assertTrue(self.check(f"Lire `{name}`."))
                missing = str(Path(name).with_name("absent" + Path(name).suffix))
                self.assertTrue(self.check(f"`{missing}` <!-- références:github -->"))

    def test_moved_document_is_resolved_at_current_path(self):
        self.assertEqual(self.check("Lire `maintenance/versions.md`.", {"maintenance/versions.md": "# Versions"}), [])

    def test_relative_reference_and_unique_basename_are_supported(self):
        self.assertEqual(self.check("Lire `guides/3-maitriser.md` et `3-maitriser.md`.", {"guides/3-maitriser.md": "# Équipe"}), [])

    def test_ambiguous_basename_is_rejected(self):
        self.assertTrue(self.check("Lire `aide.md`.", {"guides/aide.md": "# A", "design/aide.md": "# B"}))

    def test_nonexistent_fragment_is_rejected(self):
        self.assertTrue(any("fragment opérationnel" in e for e in self.check("Lire `README.md#absent`.")))

    def test_existing_fragment_is_accepted(self):
        self.assertEqual(self.check("# Entrée\nLire `README.md#entrée`."), [])

    def test_operational_command_checks_its_script(self):
        self.assertTrue(any("scripts/absent.py" in e for e in self.check("Lancer `python3 scripts/absent.py chemin/run.json`.")))

    def test_user_argument_is_not_a_package_dependency(self):
        self.assertEqual(self.check("Lancer `python3 scripts/test.py chemin/run.json`.", {"scripts/test.py": ""}), [])

    def test_bad_readable_address_is_rejected(self):
        self.assertTrue(any("route opérationnelle" in e for e in self.check("Lire `savoir/section-absente`.")))

    def test_bad_route_in_command_is_rejected(self):
        self.assertTrue(any("DIRECTION/ABSENT" in e for e in self.check("Lancer `python3 scripts/read_route.py DIRECTION/ABSENT`.",
                                                                         {"scripts/read_route.py": ""})))

    def test_explicit_examples_fences_and_provenance_are_not_dependencies(self):
        self.assertEqual(self.check("`exemple: chemin/fiche.md`\n<!-- origine:CHANGELOG.md -->\n"
                                    "````md\n```\n`absent.md`\n```\n````\n"), [])

    def test_existing_directory_is_not_a_route(self):
        self.assertEqual(self.check("Les fichiers sont dans `gouvernance/schemas`.",
                                    {"gouvernance/schemas/a.json": "{}"}), [])

    def test_explicit_other_distribution_uses_its_manifest(self):
        with patch.multiple(package, IS_LOCAL=True, LISTS={"github": ["scripts/github.py"], "local": []}):
            self.assertEqual(self.check("Dans GitHub : `python3 scripts/github.py`. <!-- références:github -->"), [])

    def test_scope_cannot_hide_an_undeclared_reference(self):
        with patch.multiple(package, IS_LOCAL=True, LISTS={"github": [], "local": []}):
            self.assertTrue(self.check("`scripts/absent.py` <!-- références:github -->"))

    def test_unscoped_github_instruction_is_rejected_in_local_export(self):
        with patch.multiple(package, IS_LOCAL=True, LISTS={"github": ["scripts/github.py"], "local": []}):
            self.assertTrue(self.check("Lancer `python3 scripts/github.py`."))

    def test_missing_scope_manifest_is_rejected_without_exception(self):
        with patch.multiple(package, IS_LOCAL=True, LISTS={"local": []}):
            self.assertTrue(any("manifeste de la portée" in e for e in self.check("`scripts/github.py` <!-- références:github -->")))

    def test_reference_outside_package_is_rejected(self):
        self.assertTrue(self.check("Lire `../README.md`."))


class SourceLocationTests(unittest.TestCase):
    def check(self, missing=False, unregistered=False, unknown=False):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            document = root / "source.md"
            document.write_text("<!-- origine:" + ("INCONNU.md" if unknown else "SAVOIR.md") + " -->\n# Savoir\n", encoding="utf-8")
            mapping = {f"{p}.md": ("source.md",) for p in routes.PREFIXES}
            if missing:
                mapping["SAVOIR.md"] += ("section-perdue.md",)
            if unregistered:
                other = root / "autre.md"
                other.write_text("# Autre\n")
                mapping["SAVOIR.md"] = ("autre.md",)
            errors = []
            with patch.multiple(package, ROOT=root, EXPECTED=["source.md"]), patch.multiple(routes, ROOT=root, LIEUX=mapping):
                package.check_source_locations(errors)
            return errors

    def test_missing_source_section_is_rejected(self):
        self.assertTrue(any("section-perdue.md" in e for e in self.check(missing=True)))

    def test_unregistered_provenance_is_rejected(self):
        self.assertTrue(any("provenance sans emplacement" in e for e in self.check(unregistered=True)))

    def test_registered_source_is_accepted(self):
        self.assertEqual(self.check(), [])

    def test_unknown_provenance_is_rejected(self):
        self.assertTrue(any("provenance inconnue" in e for e in self.check(unknown=True)))


class GovernancePresentationTests(unittest.TestCase):
    def test_contextual_governance_is_allowed(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "README.md").write_text("La gouvernance n’est pas toujours obligatoire ; elle s’adapte au contexte.")
            errors = []
            with patch.object(package, "ROOT", root):
                package.check_canonicity_language(errors)
            self.assertEqual(errors, [])

    def test_unconditional_exemption_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "design").mkdir()
            (root / "design/README.md").write_text("Le module de gouvernance peut s’ajouter ; il n’est jamais requis.")
            errors = []
            with patch.object(package, "ROOT", root):
                package.check_canonicity_language(errors)
            self.assertTrue(any("sans adaptation au contexte" in e for e in errors), errors)

    def test_unconditional_obligation_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "README.md").write_text("La gouvernance est toujours obligatoire.")
            errors = []
            with patch.object(package, "ROOT", root):
                package.check_canonicity_language(errors)
            self.assertTrue(any("sans adaptation au contexte" in e for e in errors), errors)


class CapabilityTests(unittest.TestCase):
    def setUp(self):
        self.document = cards.load_json(ROOT / "gouvernance/schemas/fixtures/valid_direction_exploratory_untransformed.json")
        self.schema = cards.load_json(ROOT / "gouvernance/schemas/run_card.schema.json")
        self.profile = {"available": ["inspection vectorielle"], "unavailable": ["navigateur/capture"],
                        "not_required": ["connexion bancaire"], "basis": [
                            {"capability": "inspection vectorielle", "kind": "tool_result", "detail": "Rasterisation du SVG et inspection du rendu."}]}

    def validate(self, profile):
        document = copy.deepcopy(self.document)
        document["run_card"]["capability_profile"] = profile
        cards.validate_card(document, self.schema)

    def test_disjoint_categories_admitted(self):
        self.validate(self.profile)

    def test_available_and_unavailable_refused(self):
        self.profile["unavailable"].append("inspection vectorielle")
        with self.assertRaisesRegex(cards.ValidationError, "plusieurs catégories"):
            self.validate(self.profile)

    def test_available_and_not_required_refused(self):
        self.profile["not_required"].append("inspection vectorielle")
        with self.assertRaisesRegex(cards.ValidationError, "plusieurs catégories"):
            self.validate(self.profile)

    def test_unavailable_and_not_required_refused(self):
        self.profile["not_required"].append("navigateur/capture")
        with self.assertRaisesRegex(cards.ValidationError, "plusieurs catégories"):
            self.validate(self.profile)

    def test_surrounding_spaces_do_not_hide_conflict(self):
        self.profile["unavailable"].append(" inspection vectorielle ")
        with self.assertRaisesRegex(cards.ValidationError, "plusieurs catégories"):
            self.validate(self.profile)

    def test_empty_availability_is_not_success_or_failure(self):
        self.validate({"available": [], "unavailable": ["navigateur/capture"], "not_required": [], "basis": []})


class StrictHostTests(unittest.TestCase):
    def test_demo_families_for_artifact_and_trace_without_network(self):
        schema = cards.load_json(ROOT / 'gouvernance/schemas/run_card.schema.json')
        baseline = cards.load_json(ROOT / 'gouvernance/schemas/run_card.example.json')
        baseline['run_card']['artifact']['locator'] = 'https://production.audit-project.test/page'
        baseline['run_card']['proof']['provenance']['artifact_locator'] = baseline['run_card']['artifact']['locator']
        baseline['run_card']['trace_locator'] = 'trace-audit-42'
        pair = baseline['run_card']['closure']['b1b']['pair']  # captures non locales : hors contrôle d'existence (C47)
        pair['before_locator'], pair['after_locator'] = ('https://production.audit-project.test/v1.png',
                                                         'https://production.audit-project.test/v1b.png')
        cards.validate_card(baseline, schema, strict=True)
        for field in ('artifact', 'trace'):
            for host, rejected in [('example.com', True), ('EXAMPLE.COM', True), ('www.example.com', True),
                                   ('example.com.', True), ('demo.example.invalid', True), ('other.invalid.', True),
                                   ('x.example.org.', True), ('www.example.net', True),
                                   ('example.org.evil.test', False), ('myexample.com', False),
                                   ('production.audit-project.test', False)]:
                with self.subTest(field=field, host=host):
                    document = copy.deepcopy(baseline)
                    locator = 'https://' + host + '/page'
                    if field == 'artifact':
                        document['run_card']['artifact']['locator'] = locator
                        document['run_card']['proof']['provenance']['artifact_locator'] = locator
                    else:
                        document['run_card']['trace_locator'] = locator
                    if rejected:
                        with self.assertRaisesRegex(cards.ValidationError, 'URL de démonstration interdite'):
                            cards.validate_card(document, schema, strict=True)
                    else:
                        cards.validate_card(document, schema, strict=True)


class CoreResourceActivationTests(unittest.TestCase):
    def test_compiled_resource_relays_cannot_disappear(self):
        skill = structure.SKILL_DIR / 'SKILL.md'
        original = skill.read_text()
        for locator in ('SAVOIR/TOOLS/CONVERGENCE', 'SAVOIR/TOOLS/MOYENS'):
            with self.subTest(locator=locator), tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp); (root / 'SKILL.md').write_text(original.replace('`' + locator + '`', 'relai retiré'))
                errors = []
                with patch.object(structure, 'SKILL_DIR', root):
                    structure.check_core_floor(errors)
                self.assertEqual(len(errors), 1, errors)
                self.assertIn('activation conditionnelle', errors[0])

    def test_dated_details_remain_reachable(self):
        for locator, expected in [('SAVOIR/TOOLS/CONVERGENCE', 'Signaux à confirmer'), ('SAVOIR/TOOLS/MOYENS', 'Typographie')]:
            with self.subTest(locator=locator):
                _, lines, index = routes.resolve(locator)
                self.assertIn(expected, '\n'.join(routes.extract(lines, index)))

    def test_writing_route_is_reachable_with_its_contract(self):
        # Écriture : route PILOT à contrat réduit, servie par son adresse lisible.
        _, lines, index = routes.resolve('SAVOIR/CRAFT/CFT-06')
        served = '\n'.join(routes.extract(lines, index))
        for fragment in ('PILOT', 'Contre-indication', 'Limite', 'ADOPTED'):
            self.assertIn(fragment, served)
        self.assertEqual(routes.adresse('savoir/qualite-creative#ecriture'), 'SAVOIR/CRAFT/CFT-06')

    def test_package_names_no_third_party_skill(self):
        # Le système présente son propre contenu : aucune autre skill de design n'y est nommée ni citée comme source.
        manifest = json.loads((ROOT / 'scripts' / 'package_manifest.json').read_text(encoding='utf-8'))
        named = re.compile('ta' + r'ste[ -]?skill|' + 'leon' + 'xlnx', re.I)  # assemblé : ce fichier ne contient pas le nom
        for rel in manifest['github']:
            path = ROOT / rel
            if path.suffix in {'.md', '.py', '.json', '.html', '.txt', '.svg', '.yml'} and path.is_file():
                with self.subTest(file=rel):
                    self.assertIsNone(named.search(path.read_text(encoding='utf-8')))

    def test_setting_values_and_image_search_pilots_are_served_with_their_limits(self):
        # Valeurs de réglage `[À ADAPTER]` (grand texte, durées) et procédure d'images libres : servies par leur route, limites et source datée présentes.
        for locator, expected in [('SAVOIR/TYPE', ('Réglage d’un grand texte', 'À ADAPTER', 'non des mesures', 'Contre-indications')),
                                  ('SAVOIR/CONTEXT', ('Durées et courbes, points de départ', 'À ADAPTER', 'non des mesures', 'Contre-indications')),
                                  ('SAVOIR/SOURCE', ('Chercher le monde du sujet dans des collections ouvertes', 'Honnêteté', 'Droits', 'avis juridique', 'PILOT'))]:
            with self.subTest(locator=locator):
                _, lines, index = routes.resolve(locator)
                served = '\n'.join(routes.extract(lines, index))
                for fragment in expected:
                    self.assertIn(fragment, served)

    def test_colour_relations_pilot_is_served_by_cft_05_with_its_limits(self):
        # Relations de couleur : sous-section de CFT-05 en PILOT ; la roue reste un vocabulaire, jamais une recette.
        _, lines, index = routes.resolve('SAVOIR/CRAFT/CFT-05')
        served = '\n'.join(routes.extract(lines, index))
        for fragment in ('Relations de couleur', 'PILOT', 'La valeur d’abord', 'OKLCH', 'niveaux de gris', 'Fonds voisins',
                         'décrivent une palette ; elles n’en justifient pas une', 'Contre-indications', 'ADOPTED'):
            self.assertIn(fragment, served)

    def test_subject_inventory_pilot_and_substance_signal_are_served_by_their_routes(self):
        # Inventaire du sujet : sous-section de CFT-01 en PILOT, source datée ; substance : signal d'enquête de CFT-00, sans score.
        for locator, expected in [('SAVOIR/CRAFT/CFT-01', ('Inventaire du sujet et phrase d’idée', 'Test du concurrent', 'PILOT', 'Contre-indication', 'ADOPTED')),
                                  ('SAVOIR/CRAFT/CFT-00', ('Substance', 'sans seuil ni score', 'La retenue n’est pas le vide',
                                                           'qu’est-ce qui bouge sur cette surface', 'Aucun nombre d’éléments animés'))]:
            with self.subTest(locator=locator):
                _, lines, index = routes.resolve(locator)
                served = '\n'.join(routes.extract(lines, index))
                for fragment in expected:
                    self.assertIn(fragment, served)


class ReachabilityTests(unittest.TestCase):
    """Garde 19 (ATT-01) : une règle qu'aucune route ne sert et que le noyau ne porte pas est refusée."""

    def unreachable(self, text: str) -> list[int]:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "source.md"
            path.write_text(text, encoding="utf-8")
            return structure.unreachable_lines(path)

    def test_rule_outside_any_route_is_refused(self):
        text = ("# Titre\n\n<!-- origine:DIRECTION.md -->\n## Section libre\n\nUne règle que rien ne sert.\n\n"
                "## DIRECTION/START — classer\n\nTexte servi.\n")
        self.assertEqual(self.unreachable(text), [6])

    def test_orientation_zone_and_non_normative_origin_are_admitted(self):
        text = ("<!-- origine:DIRECTION.md -->\n<!-- orientation:début -->\n## Pour une personne\n\nOrientation.\n"
                "<!-- orientation:fin -->\n\n<!-- origine:READING_MAP.md -->\n## Carte\n\nVue dérivée.\n")
        self.assertEqual(self.unreachable(text), [])

    def test_compiled_core_block_is_reachable(self):
        text = ("<!-- origine:DIRECTION.md -->\n## Rôle\n\n<!-- noyau:début ROLE -->\nTexte compilé dans le noyau.\n"
                "<!-- noyau:fin ROLE -->\n\nTexte qui ne l'est pas.\n")
        self.assertEqual(self.unreachable(text), [8])

    def test_current_corpus_has_no_unreachable_rule(self):
        errors = []
        structure.check_reachability(errors)
        self.assertEqual(errors, [])


class FacadeSensitivityTests(unittest.TestCase):
    """L7-12 : chaque condition de façade tombe quand on lui retire son texte, ou quand on y ajoute le défaut qu'elle interdit."""

    # Conditions d'interdiction, vraies sur un texte vide par construction : leur mutation est un ajout ciblé.
    PROHIBITIONS = {"LCF-12", "LCF-13", "LCF-21", "LCF-22"}

    def setUp(self):
        self.texts = reading_map.load_texts()

    def failing(self, texts):
        errors = []
        with patch.object(reading_map, "load_texts", return_value=texts):
            reading_map.check_facades(errors)
        return {re.match(r"(LCF-[0-9A-Z]+)", e).group(1) for e in errors if re.match(r"LCF-", e)}

    def test_each_condition_falls_when_its_text_is_removed(self):
        source = (Path(reading_map.__file__)).read_text(encoding="utf-8")
        ids = set(re.findall(r"""\(["'](LCF-[0-9A-Z]+)["'],""", source))
        self.assertEqual(self.failing(dict(self.texts)), set())
        fallen = set()
        for key in self.texts:
            texts = dict(self.texts)
            texts[key] = ""
            fallen |= self.failing(texts)
        self.assertEqual(ids - fallen, self.PROHIBITIONS)

    def assert_added_defect_fails(self, key, addition, lcf_id):
        texts = dict(self.texts)
        texts[key] += "\n" + addition + "\n"
        self.assertIn(lcf_id, self.failing(texts))

    def test_reservation_without_conditions_fails(self):
        self.assert_added_defect_fails("EX", "```text\nVERDICT: ACCEPTED-WITH-RESERVATION\n```", "LCF-12")

    def test_not_observed_as_verdict_fails(self):
        self.assert_added_defect_fails("EX", "```text\nNOT-OBSERVED: rendu\n```", "LCF-13")

    def test_efficacy_claim_without_not_verified_fails(self):
        texts = dict(self.texts)
        texts["README"] = texts["README"].replace("NOT-VERIFIED", "vérifiée")
        self.assertIn("LCF-21", self.failing(texts))

    def test_decision_change_without_not_observed_fails(self):
        self.assert_added_defect_fails("A", "La conséquence `DECISION-CHANGE` vaut `N/A-JUSTIFIED` par défaut.", "LCF-22")


class SignalTableTests(unittest.TestCase):
    """Garde 21 (SIG-01) : la table des signaux du noyau est la seule table signal → route."""

    def test_current_corpus_has_one_signal_table(self):
        self.assertEqual(structure.signal_tables(), [])

    def test_second_signal_table_is_refused(self):
        with tempfile.TemporaryDirectory() as tmp:
            extra = Path(tmp) / "extra.md"
            extra.write_text("# X\n\n| Situation | Routes ciblées |\n|---|---|\n| Couleur | `SAVOIR/CRAFT` |\n", encoding="utf-8")
            with patch.object(structure.rr, "sources_normatives", return_value=structure.rr.sources_normatives() + [extra]):
                errors = []
                structure.check_signal_tables(errors)
        self.assertEqual(len(errors), 1, errors)
        self.assertIn("[SIG-01]", errors[0])


class FloorTests(unittest.TestCase):
    """Garde 20 (REQ-01) : chaque obligation [REQUIS] a son plancher dans le noyau ou dans le tronc des modes visés."""

    def test_current_corpus_has_a_floor_for_each_obligation(self):
        errors = []
        structure.check_floors(errors)
        self.assertEqual(errors, [])

    def test_unregistered_obligation_is_refused(self):
        planchers = dict(structure.PLANCHERS)
        planchers.pop("blast radius partagé, token ou primitive")
        errors = []
        structure.check_floors(errors, planchers)
        self.assertTrue(any("obligation sans plancher inscrit" in e and "systeme-de-design.md" in e for e in errors), errors)

    def test_floor_outside_core_or_trunk_is_refused(self):
        planchers = dict(structure.PLANCHERS)
        planchers["composant, état, surface `DIRECTION` ou Gate C"] = ("noyau", "COMP-VOCABULAIRE")  # bloc différé
        planchers["blast radius partagé, token ou primitive"] = ("tronc", "SAVOIR/SYSTEM", ("STANDARD",))
        errors = []
        structure.check_floors(errors, planchers)
        self.assertTrue(any("COMP-VOCABULAIRE n'est pas compilé" in e for e in errors), errors)
        self.assertTrue(any("SAVOIR/SYSTEM absent du tronc STANDARD" in e for e in errors), errors)

    def test_stale_entry_is_refused(self):
        planchers = dict(structure.PLANCHERS)
        planchers["scope disparu"] = ("noyau", "ANCRE")
        errors = []
        structure.check_floors(errors, planchers)
        self.assertTrue(any("obligation introuvable" in e for e in errors), errors)

    def test_legend_in_backticks_is_not_an_obligation(self):
        self.assertNotIn("scope", structure.obligations())


class ReviewFindingsTests(unittest.TestCase):
    """Témoins des défauts reproduits par la revue du système (carnet de revue, branche refonte)."""

    def test_skill_header_rejects_unquoted_non_string_scalars(self):
        # SC-03 : un scalaire non cité lu comme nul, booléen, nombre ou date n'est pas une description textuelle.
        for raw in ("null", "~", "true", "no", "123", "1.5", "0x1F", ".inf", "2026-10-14", "12:30"):
            with self.subTest(raw=raw):
                _, problems = structure.skill_header(f"---\nname: design-governance-practice\ndescription: {raw}\n---\n")
                self.assertTrue(any("nul, booléen, nombre ou date" in p for p in problems), problems)
        for raw in ('"null"', "v1.0", "1er octobre", "Produire un design situé"):
            with self.subTest(raw=raw):
                values, problems = structure.skill_header(f"---\nname: design-governance-practice\ndescription: {raw}\n---\n")
                self.assertEqual(problems, [])
                self.assertTrue(values["description"])

    def test_skill_header_follows_agent_skills_format(self):
        # Format ouvert Agent Skills : nom en minuscules et tirets, champs connus, longueurs bornées.
        cases = [("name: Design_Gov\ndescription: x", "hors du format Agent Skills"),
                 ("name: design-governance-practice\ndescription: x\nauteur: moi", "champ auteur inconnu"),
                 ("name: design-governance-practice\ndescription: " + "a" * 1100, "description dépasse 1024"),
                 ("name: design-governance-practice\ndescription: x\ncompatibility: " + "b" * 600, "compatibility dépasse 500")]
        for header, expected in cases:
            with self.subTest(expected=expected), tempfile.TemporaryDirectory() as tmp:
                (Path(tmp) / "SKILL.md").write_text(f"---\n{header}\n---\n", encoding="utf-8")
                errors = []
                with patch.object(structure, "SKILL_DIR", Path(tmp)):
                    structure.check_skill_header(errors)
                self.assertTrue(any(expected in e for e in errors), errors)

    def test_skill_header_accepts_agent_skills_metadata(self):
        # Format Agent Skills : metadata est une table de textes, en style bloc ou en ligne.
        accepted = ("metadata:\n  author: example-org\n  version: \"1.0\"", "metadata: {author: example-org, version: \"1.0\"}",
                    "license: Apache-2.0")
        for field in accepted:
            with self.subTest(field=field):
                _, problems = structure.skill_header(f"---\nname: design-governance-practice\ndescription: x\n{field}\n---\n")
                self.assertEqual(problems, [])
        _, problems = structure.skill_header("---\nname: design-governance-practice\ndescription: x\nmetadata:\n  version: 1.0\n---\n")
        self.assertTrue(any("metadata.version" in p for p in problems), problems)

    def generator(self, root: Path):
        shutil.copytree(ROOT / "supports", root / "supports", ignore=shutil.ignore_patterns("__pycache__"))
        (root / "scripts").mkdir()
        shutil.copy(ROOT / "scripts" / "package_manifest.json", root / "scripts" / "package_manifest.json")
        spec = importlib.util.spec_from_file_location("dg_supports_test", root / "supports" / "generer.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def test_support_relations_must_follow_the_drawing(self):
        # SV-01 : le dessin a une topologie fixe ; une relation modifiée dans le JSON ne peut pas diverger en silence.
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); module = self.generator(root)
            source = root / "supports" / "systeme.json"
            data = json.loads(source.read_text(encoding="utf-8"))
            data["relations"][0]["to"] = "maintenance"
            source.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "dessin fixe"):
                module.render_outputs()

    def test_support_version_comes_from_the_manifest(self):
        # SV-03 : toutes les cartes affichent la version du manifeste ; aucune carte n'en déclare une autre.
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            manifest = json.loads((ROOT / "scripts" / "package_manifest.json").read_text(encoding="utf-8"))
            self.generator(root)
            manifest["version"] = "9.9.9"
            (root / "scripts" / "package_manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            spec = importlib.util.spec_from_file_location("dg_supports_test_v", root / "supports" / "generer.py")
            module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
            outputs = module.render_outputs()
            svgs = [text for name, text in outputs.items() if name.endswith(".svg")]
            self.assertEqual(len(svgs), 6)
            for text in svgs:
                self.assertIn("V9.9.9 expérimentale", text)
                self.assertNotIn("V1.0.0", text)
        self.assertNotIn("version", json.loads((ROOT / "supports" / "systeme.json").read_text(encoding="utf-8")))

    def test_equivalent_text_has_no_double_punctuation(self):
        # SV-02 : un titre déjà ponctué ne reçoit pas un second point.
        for name in ("systeme.md", "parcours.md", "boucle.md"):
            with self.subTest(name=name):
                self.assertNotIn(".**.", (ROOT / "supports" / name).read_text(encoding="utf-8"))


if __name__ == "__main__":
    result = unittest.TextTestRunner(stream=sys.stdout).run(unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__]))
    print(f"AUDIT REGRESSIONS {'PASSED' if result.wasSuccessful() else 'FAILED'} — {result.testsRun} cas")
    sys.exit(0 if result.wasSuccessful() else 1)
