#!/usr/bin/env python3
"""Planche de comparaison : plusieurs premiers écrans côte à côte, en bureau et en mobile.

Sert le levier « Diverger sur image » (`DIRECTION/DIVERGENCE`) : la modale en référence, puis les esquisses,
même contenu, rendues aux mêmes largeurs. La planche ne juge rien ; elle rend le choix possible sur image.

Usage :
  python3 scripts/planche.py planche.png modale.html a.html b.html c.html
  python3 scripts/planche.py planche.png modale.html a.html --etiquettes "Modale,A · relevé" --colonnes 2
  python3 scripts/planche.py planche.png modale.html a.html b.html c.html --bureau-seul

Chaque page est capturée au premier écran (1440 × 900 puis 390 × 844 par défaut), animations gelées ; avec
--bureau-seul, au bureau seulement : les esquisses se comparent au bureau, et la recomposition mobile se construit
ensuite sur la direction gardée. Un débordement horizontal est signalé sur la sortie standard.
Nécessite Playwright, Chromium et Pillow.
"""
from __future__ import annotations

import argparse
import sys
sys.dont_write_bytecode = True  # les imports entre outils n’écrivent rien dans le paquet
import tempfile
from pathlib import Path

GEL = "*,*::before,*::after{animation:none!important;transition:none!important;caret-color:transparent!important}"


def capturer(pages: list[Path], dossier: Path, bureau: tuple[int, int], mobile: tuple[int, int] | None) -> list[str]:
    from playwright.sync_api import sync_playwright
    notes = []
    formats = (("bureau", bureau),) + ((("mobile", mobile),) if mobile else ())
    with sync_playwright() as p:
        nav = p.chromium.launch()
        for i, page in enumerate(pages):
            for nom, (w, h) in formats:
                pg = nav.new_page(viewport={"width": w, "height": h})
                pg.goto(page.resolve().as_uri())
                pg.add_style_tag(content=GEL)
                pg.wait_for_timeout(400)
                pg.screenshot(path=str(dossier / f"{i}-{nom}.png"))
                largeur = pg.evaluate("document.documentElement.scrollWidth")
                if largeur > w:
                    notes.append(f"{page.name} : débordement horizontal à {w} px ({largeur} px)")
                pg.close()
        nav.close()
    return notes


def police(taille: int):
    from PIL import ImageFont
    for chemin in ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/Library/Fonts/Arial.ttf",
                   "C:/Windows/Fonts/arial.ttf", "/System/Library/Fonts/Supplemental/Arial.ttf"):
        try:
            return ImageFont.truetype(chemin, taille)
        except OSError:
            continue
    return ImageFont.load_default()


def assembler(n: int, etiquettes: list[str], dossier: Path, sortie: Path, colonnes: int,
              bureau: tuple[int, int], mobile: tuple[int, int] | None) -> None:
    from PIL import Image, ImageDraw
    D = (bureau[0] // 2, bureau[1] // 2)
    M = (mobile[0] // 2, mobile[1] // 2) if mobile else (0, 0)
    G, T = 24, 40
    cw, ch = D[0] + (16 + M[0] if mobile else 0), T + max(D[1], M[1])
    lignes = (n + colonnes - 1) // colonnes
    W, H = G + colonnes * (cw + G), G + lignes * (ch + G)
    im = Image.new("RGB", (W, H), "#f2f2ef")
    dr = ImageDraw.Draw(im)
    f = police(22)
    for i in range(n):
        x, y = G + (i % colonnes) * (cw + G), G + (i // colonnes) * (ch + G)
        dr.text((x, y + 4), etiquettes[i], fill="#111", font=f)
        d = Image.open(dossier / f"{i}-bureau.png").resize(D, Image.LANCZOS)
        im.paste(d, (x, y + T))
        cadres = [((x, y + T), D)]
        if mobile:
            m = Image.open(dossier / f"{i}-mobile.png").resize(M, Image.LANCZOS)
            im.paste(m, (x + D[0] + 16, y + T))
            cadres.append(((x + D[0] + 16, y + T), M))
        for (a, b), (w, h) in cadres:
            dr.rectangle([a - 1, b - 1, a + w, b + h], outline="#9a9a95")
    im.save(sortie)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Planche de premiers écrans, bureau et mobile (ou bureau seul), côte à côte.")
    ap.add_argument("sortie", help="image PNG à écrire")
    ap.add_argument("pages", nargs="+", help="pages HTML ; la première sert de référence (la modale)")
    ap.add_argument("--etiquettes", help="libellés séparés par des virgules, dans l'ordre des pages")
    ap.add_argument("--colonnes", type=int, default=2)
    ap.add_argument("--bureau", default="1440x900", help="largeur x hauteur du premier écran bureau")
    ap.add_argument("--mobile", default="390x844", help="largeur x hauteur du premier écran mobile")
    ap.add_argument("--bureau-seul", action="store_true",
                    help="comparer les esquisses au bureau seulement ; le mobile se construit sur la direction gardée")
    a = ap.parse_args(argv)
    pages = [Path(p) for p in a.pages]
    absentes = [str(p) for p in pages if not p.is_file()]
    if absentes:
        print("Pages absentes : " + ", ".join(absentes), file=sys.stderr)
        return 2
    etiquettes = [e.strip() for e in a.etiquettes.split(",")] if a.etiquettes else \
        ["Référence (modale) · " + pages[0].stem] + [p.stem for p in pages[1:]]
    if len(etiquettes) != len(pages):
        print("Autant d'étiquettes que de pages, s'il vous plaît.", file=sys.stderr)
        return 2
    bureau = tuple(int(v) for v in a.bureau.split("x"))
    mobile = None if a.bureau_seul else tuple(int(v) for v in a.mobile.split("x"))
    with tempfile.TemporaryDirectory() as tmp:
        notes = capturer(pages, Path(tmp), bureau, mobile)
        assembler(len(pages), etiquettes, Path(tmp), Path(a.sortie), a.colonnes, bureau, mobile)
    largeurs = f"{bureau[0]} et {mobile[0]} px" if mobile else f"{bureau[0]} px, bureau seul"
    print(f"Planche écrite : {a.sortie} ({len(pages)} pages, {largeurs}).")
    for n in notes:
        print("Signal : " + n)
    print("La planche ne juge rien : le choix se fait à la vue, et la trace dit pourquoi.")
    return 0


if __name__ == "__main__":
    import journal_mobilisation  # journal passif : n'écrit rien sans DG_JOURNAL
    sys.exit(journal_mobilisation.executer("planche", main, sys.argv[1:]))
